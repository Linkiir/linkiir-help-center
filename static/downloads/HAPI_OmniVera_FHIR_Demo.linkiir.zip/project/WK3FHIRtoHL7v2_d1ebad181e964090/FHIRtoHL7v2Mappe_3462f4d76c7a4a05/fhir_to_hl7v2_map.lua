-- ===========================================================================
-- fhir_to_hl7v2_map - FHIR R4 Patient -> HL7 v2 ADT^A08 mapping
--
-- This is the MAPPING MODULE. It holds only the field-by-field translation
-- from a FHIR Patient resource to an HL7 v2 message, so the mapping can be
-- reviewed and changed on its own, without touching the node's glue (main.lua).
--
-- To change what maps where, edit toADT() below. To change how the message
-- flows through the node, edit main.lua instead.
--
-- It emits an ADT^A08 (update) with MSH, EVN and PID, which is enough to carry
-- a patient's identity, demographics and address back out as HL7 v2.
-- ===========================================================================

local M = {}

-- FHIR administrative-gender code -> HL7 administrative sex (PID-8).
local SEX = { male = 'M', female = 'F', other = 'O', unknown = 'U' }

-- Value or empty string, so an absent FHIR field becomes an empty HL7 field
-- rather than the string "nil".
local function s(Value)
   if Value == nil then return '' end
   return tostring(Value)
end

-- Pull the first identifier value, treating it as the MRN.
local function mrnOf(Patient)
   local Ids = Patient.identifier
   if type(Ids) == 'table' and Ids[1] then return s(Ids[1].value) end
   return ''
end

-- FHIR birthDate is YYYY-MM-DD; HL7 wants YYYYMMDD.
local function hl7Date(Date)
   return (s(Date):gsub('%-', ''))
end

-- Map one FHIR Patient to an HL7 v2 ADT^A08 message (CR-separated segments).
function M.toADT(Patient)
   local Name = (type(Patient.name) == 'table' and Patient.name[1]) or {}
   local family = s(Name.family)
   local given = (type(Name.given) == 'table' and s(Name.given[1])) or ''

   local Addr = (type(Patient.address) == 'table' and Patient.address[1]) or {}
   local line = (type(Addr.line) == 'table' and s(Addr.line[1])) or ''
   local city, state, zip = s(Addr.city), s(Addr.state), s(Addr.postalCode)

   local Telecom = (type(Patient.telecom) == 'table' and Patient.telecom[1]) or {}
   local phone = s(Telecom.value)

   local mrn = mrnOf(Patient)
   local sex = SEX[s(Patient.gender)] or 'U'
   local dob = hl7Date(Patient.birthDate)
   local ts = os.date('%Y%m%d%H%M%S')
   local ctrl = ts .. string.format('%05d', math.random(0, 99999))

   local Segments = {
      string.format('MSH|^~\\&|LINKIIR|LINKIIR GRID|RECEIVER|FACILITY|%s||ADT^A08^ADT_A01|%s|P|2.5.1', ts, ctrl),
      string.format('EVN|A08|%s', ts),
      string.format('PID|1||%s^^^LINKIIR^MR||%s^%s||%s|%s|||%s^^%s^%s^%s^USA||%s',
         mrn, family, given, dob, sex, line, city, state, zip, phone),
   }

   return table.concat(Segments, '\r')
end

return M
