-- ---------------------------------------------------------------------------
-- Print HL7v2 Destination - Destination Custom (WK3)
--
-- The end of the FHIR -> HL7 v2 demo: it receives the transformed HL7 v2
-- message and prints it to the node log, so the result of the mapping is
-- visible without any external system.
--
-- HL7 segments are CR-separated, which collapses to one line in most log
-- viewers, so each segment is logged on its own line for readability.
-- ---------------------------------------------------------------------------
function main(Data)
   local Message = tostring(Data or '')
   if Message == '' then
      linkiir.log.warn('Print HL7v2: received an empty message.')
      return
   end

   linkiir.log.info('Print HL7v2: received a transformed HL7 v2 message ('
      .. #Message .. ' bytes):')

   -- Split on CR/LF and print each segment, so MSH, EVN and PID each show up.
   local n = 0
   for Segment in (Message:gsub('\r\n', '\r'):gsub('\n', '\r') .. '\r'):gmatch('([^\r]*)\r') do
      if Segment ~= '' then
         n = n + 1
         linkiir.log.info('  ' .. Segment)
      end
   end
   linkiir.log.info('Print HL7v2: printed ' .. n .. ' segment(s).')
end
