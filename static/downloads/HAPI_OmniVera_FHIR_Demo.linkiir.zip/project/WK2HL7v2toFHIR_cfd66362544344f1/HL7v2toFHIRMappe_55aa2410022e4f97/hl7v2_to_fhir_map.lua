-- ===========================================================================
-- hl7v2_to_fhir_map - HL7 v2 (ADT) -> FHIR R4 Patient mapping
--
-- This is the MAPPING MODULE. It holds only the field-by-field translation
-- from an HL7 v2 ADT message to a FHIR Patient resource, so the mapping can be
-- reviewed and changed on its own, without touching the node's glue (main.lua).
--
-- To change what maps where, edit toPatient() below. To change how the message
-- flows through the node (logging, forwarding), edit main.lua instead.
--
-- The ADT^A01 the Data Simulator emits carries a PID segment shaped like:
--   PID|1||<MRN>^^^LINKIIR^MR||<FAMILY>^<GIVEN>^A||<DOB>|<SEX>|||<STREET>^^<CITY>^<STATE>^<ZIP>^USA||<PHONE>|...
-- ===========================================================================

local M = {}

-- Split "a|b|c" on a delimiter into a 1-based array. Kept tiny and explicit -
-- HL7 v2 parsing is just repeated delimiter splits at three levels (segments
-- by CR, fields by |, components by ^).
local function split(Text, Delimiter)
   local Parts, Pattern = {}, '([^' .. Delimiter .. ']*)' .. Delimiter
   for Piece in (tostring(Text) .. Delimiter):gmatch(Pattern) do
      Parts[#Parts + 1] = Piece
   end
   return Parts
end

-- The value of an HL7 field, or nil when it is absent or blank, so an unset
-- field is omitted from the resource rather than written as "".
local function present(Value)
   if Value == nil or Value == '' then return nil end
   return Value
end

-- HL7 administrative sex (PID-8) -> FHIR administrative-gender code.
local GENDER = { M = 'male', F = 'female', O = 'other', U = 'unknown' }

-- Parse the raw HL7 message into { [segmentName] = { fields... } }, keeping the
-- first occurrence of each segment. Enough for a single-patient ADT; a message
-- with repeating segments would need a list per name.
local function segments(Raw)
   local Found = {}
   -- Segments may be separated by \r, \n or \r\n depending on the transport.
   for Line in (tostring(Raw):gsub('\r\n', '\r'):gsub('\n', '\r') .. '\r'):gmatch('([^\r]*)\r') do
      if Line ~= '' then
         local Name = Line:sub(1, 3)
         if not Found[Name] then Found[Name] = split(Line, '|') end
      end
   end
   return Found
end

-- Map one HL7 v2 ADT message to a FHIR R4 Patient table (ready to serialize).
-- Returns (Patient, nil) on success or (nil, errorMessage) when there is no PID.
function M.toPatient(Raw)
   local Seg = segments(Raw)
   local PID = Seg.PID
   if not PID then
      return nil, 'no PID segment found in the HL7 message'
   end

   -- HL7 fields are 1-based counting the segment name as field [1]; so PID-3 is
   -- PID[4], PID-5 is PID[6], and so on.
   local mrn     = present(split(PID[4] or '', '%^')[1])
   local nameF   = split(PID[6] or '', '%^')
   local family  = present(nameF[1])
   local given   = present(nameF[2])
   local dob     = present(PID[8])
   local sexCode = present(PID[9])
   local addr    = split(PID[12] or '', '%^')
   local phone   = present(PID[14])

   local Patient = { resourceType = 'Patient' }

   -- A narrative satisfies the FHIR dom-6 constraint, so a validating server
   -- reports no warnings on an otherwise-minimal Patient.
   Patient.text = {
      status = 'generated',
      div = '<div xmlns="http://www.w3.org/1999/xhtml">'
         .. (given or '') .. ' ' .. (family or '') .. (mrn and (', MRN ' .. mrn) or '')
         .. '</div>',
   }

   if mrn then
      Patient.identifier = { { system = 'http://hospital.example.org/mrn', value = mrn } }
   end

   Patient.active = true

   if family or given then
      local Name = { use = 'official' }
      if family then Name.family = family end
      if given then Name.given = { given } end
      Patient.name = { Name }
   end

   if sexCode then Patient.gender = GENDER[sexCode:upper()] or 'unknown' end

   -- HL7 DOB is YYYYMMDD; FHIR wants YYYY-MM-DD.
   if dob and #dob >= 8 then
      Patient.birthDate = dob:sub(1, 4) .. '-' .. dob:sub(5, 6) .. '-' .. dob:sub(7, 8)
   end

   if phone then
      Patient.telecom = { { system = 'phone', value = phone, use = 'home' } }
   end

   -- HL7 address is street^^city^state^zip^country.
   local line, city, state, zip = present(addr[1]), present(addr[3]), present(addr[4]), present(addr[5])
   if line or city or state or zip then
      local Address = { use = 'home', type = 'both' }
      if line then Address.line = { line } end
      if city then Address.city = city end
      if state then Address.state = state end
      if zip then Address.postalCode = zip end
      Patient.address = { Address }
   end

   return Patient, nil
end

return M
