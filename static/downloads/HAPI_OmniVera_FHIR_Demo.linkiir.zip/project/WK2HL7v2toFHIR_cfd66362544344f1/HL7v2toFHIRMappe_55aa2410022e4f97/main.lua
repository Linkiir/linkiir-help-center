-- ---------------------------------------------------------------------------
-- HL7v2 to FHIR Mapper - Transform Custom (WK2)
--
-- Receives an HL7 v2 ADT message, maps it to a FHIR R4 Patient, and forwards
-- the Patient as JSON to the FHIR Validator.
--
-- The mapping itself lives in the sibling module hl7v2_to_fhir_map.lua, so it
-- can be reviewed and updated on its own. This file is only the node glue:
-- receive, call the mapper, log, forward.
-- ---------------------------------------------------------------------------
-- The runtime already puts this node's own directory on package.path, so a
-- sibling module is required by name with no package.path setup.
local Map = require 'hl7v2_to_fhir_map'

function main(Data)
   local Patient, Err = Map.toPatient(Data)
   if not Patient then
      linkiir.log.error('HL7v2->FHIR: could not map the message: ' .. tostring(Err))
      return
   end

   local Json = linkiir.json.serialize(Patient)

   local mrn = Patient.identifier and Patient.identifier[1] and Patient.identifier[1].value or '(none)'
   local city = Patient.address and Patient.address[1] and Patient.address[1].city or '(none)'
   linkiir.log.info('HL7v2->FHIR: mapped ADT to FHIR Patient (MRN ' .. mrn
      .. ', city ' .. city .. '), forwarding to the validator.')

   linkiir.flow.push{ data = Json }
end
