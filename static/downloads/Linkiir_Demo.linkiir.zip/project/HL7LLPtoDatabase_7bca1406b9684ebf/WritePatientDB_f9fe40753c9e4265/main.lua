-- Write Patient DB: extract patient demographics from ADT messages
-- and upsert into the SQLite patient database.

-- Ensure the demo data directory exists (SQLite cannot create parent dirs).
linkiir.sys.fs.mkdir('demo')

local DB = linkiir.store.open{driver = linkiir.store.SQLITE, name = 'demo/patient.db'}

DB:execute{sql = [[
   CREATE TABLE IF NOT EXISTS Patient (
      Id        TEXT PRIMARY KEY,
      FirstName TEXT,
      LastName  TEXT,
      Gender    TEXT
   )
]]}

function main(Data)
   local Msg = linkiir.data.extract{
      schema = 'adt_schema.json', data = Data, type = 'hl7'
   }

   local id        = tostring(Msg.PID[3][1][1])
   local firstName = tostring(Msg.PID[5][1][2])
   local lastName  = tostring(Msg.PID[5][1][1][1])
   local gender    = tostring(Msg.PID[8])

   DB:execute{sql = [[
      INSERT OR REPLACE INTO Patient (Id, FirstName, LastName, Gender)
      VALUES (]] .. DB:quote(id) .. [[, ]]
      .. DB:quote(firstName) .. [[, ]]
      .. DB:quote(lastName) .. [[, ]]
      .. DB:quote(gender) .. [[)
   ]]}
end
