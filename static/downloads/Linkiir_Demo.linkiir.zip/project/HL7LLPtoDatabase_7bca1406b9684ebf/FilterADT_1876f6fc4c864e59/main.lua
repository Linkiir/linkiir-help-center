-- Filter ADT: only pass ADT (Admit/Discharge/Transfer) messages downstream.
-- All other message types are silently discarded.

function main(Data)
   -- Parse the incoming HL7 message
   local Msg, MsgType = linkiir.data.extract{
      schema = 'adt_schema.json', data = Data, type = 'hl7'
   }

   -- Only process ADT messages
   if MsgType ~= 'ADT' then return end

   -- Build clean output and map all fields
   local Out = linkiir.data.create{
      schema = 'adt_schema.json', name = MsgType, type = 'hl7'
   }
   Out:map(Msg)

   -- Push ADT message to the database writer
   linkiir.flow.push{data = Out:text()}
end
