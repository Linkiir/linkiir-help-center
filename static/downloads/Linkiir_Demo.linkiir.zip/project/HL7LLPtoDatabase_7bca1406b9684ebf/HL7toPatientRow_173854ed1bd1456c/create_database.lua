-- Makes the demo database the first time this node starts, so the Save
-- Patient node has a table to write to. A Database node never creates tables
-- by itself: on a real interface you create them once, from its Configure
-- dialog. The Patient Lookup API runs the same statement, so either workflow
-- can start first. In Run Test the connection is simulated (live defaults to
-- false there), so testing the map never touches the database.

linkiir.sys.fs.mkdir('demo')

local db = linkiir.store.open{driver = linkiir.store.SQLITE, name = 'demo/patient.db'}
db:execute{sql = [[
   CREATE TABLE IF NOT EXISTS Patient (
      Id        TEXT NOT NULL PRIMARY KEY,
      FirstName TEXT,
      LastName  TEXT,
      BirthDate TEXT,
      Gender    TEXT,
      City      TEXT,
      State     TEXT,
      LastEvent TEXT,
      UpdatedAt TEXT
   )
]]}
db:close()
