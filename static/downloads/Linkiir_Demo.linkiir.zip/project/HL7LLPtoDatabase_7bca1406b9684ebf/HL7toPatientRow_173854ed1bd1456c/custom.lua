-- Your own Lua functions, which the data maps call: a row or a resource set to
-- Lua in the Map view calls the function it names here. The Map view adds an
-- empty function at the end of this file for a name that isn't here yet, and
-- never changes anything else in it. They are global, so PreMap and PostMap
-- can call them too.

local hl7 = require 'mapping.helpers.hl7v2'
local convert = require 'mapping.helpers.convert'
local fhir = require 'mapping.helpers.fhir'
