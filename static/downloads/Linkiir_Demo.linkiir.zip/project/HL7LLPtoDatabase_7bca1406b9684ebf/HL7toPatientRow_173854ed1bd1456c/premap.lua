-- Your own code before mapping: once a data map is found for a message,
-- mapping/init.lua calls PreMap just before the map runs. The Map view never
-- changes this file. To share something with PostMap, keep it in custom.lua.

-- MsgIn is the message as it was read (as the source schema describes it) and
-- MsgType its type. Change MsgIn here, or return another message to map in its
-- place.
function PreMap(MsgIn, MsgType)
end
