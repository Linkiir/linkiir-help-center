-- Functions the data maps use to convert values between formats.
-- Do not edit by hand: Data Map updates replace this file.
-- checksum: 9a666b7b

local hl7 = require 'mapping.helpers.hl7v2'
local fhir = require 'mapping.helpers.fhir'

local convert = {}

local function warn(text)
  linkiir.log.warn('mapping: ' .. text)
end

-- nil for '' - fhir.obj leaves out fields with no value.
local function nonblank(s)
  if s == '' then return nil end
  return s
end

-- HL7 DT/DTM -> FHIR date: YYYY, YYYY-MM or YYYY-MM-DD.
local function to_date(s)
  local y, m, d = s:match('^(%d%d%d%d)(%d?%d?)(%d?%d?)')
  if not y then return nil end
  if #m < 2 then return y end
  if #d < 2 then return y .. '-' .. m end
  return y .. '-' .. m .. '-' .. d
end

-- The value as it is (a whole field gives its first component).
function convert.copy(rep)
  return nonblank(hl7.part(rep))
end

-- HL7 DT/DTM -> FHIR date.
function convert.date(rep)
  local s = hl7.part(rep)
  if s == '' then return nil end
  return to_date(s) or warn('not an HL7 date: ' .. s)
end

-- HL7 DTM -> FHIR dateTime. FHIR needs a zone with a time; when the message
-- has none, options.timezone (default Z) is used.
function convert.datetime(rep, options)
  local s = hl7.part(rep)
  if s == '' then return nil end
  local body, tz = s:match('^([%d%.]+)([+-]%d%d%d%d)$')
  if not body then body = s end
  local y, mo, dd, hh, mi, ss, frac = body:match('^(%d%d%d%d)(%d?%d?)(%d?%d?)(%d?%d?)(%d?%d?)(%d?%d?)(%.?%d*)$')
  if not y then return warn('not an HL7 date/time: ' .. s) end
  if #hh < 2 then return to_date(body) end
  local zone = tz and (tz:sub(1, 3) .. ':' .. tz:sub(4)) or (options and options.timezone) or 'Z'
  if zone == '' then zone = 'Z' end
  if #mi < 2 then mi = '00' end
  if #ss < 2 then ss = '00' end
  if frac == '.' then frac = '' end
  return y .. '-' .. mo .. '-' .. dd .. 'T' .. hh .. ':' .. mi .. ':' .. ss .. frac .. zone
end

-- Text -> number.
function convert.number(rep)
  local s = hl7.part(rep)
  if s == '' then return nil end
  local n = tonumber(s)
  if not n then return warn('not a number: ' .. s) end
  return n
end

-- Y/N, T/F, 1/0 -> true/false.
function convert.boolean(rep)
  local s = hl7.part(rep):upper()
  if s == 'Y' or s == 'T' or s == 'TRUE' or s == '1' then return true end
  if s == 'N' or s == 'F' or s == 'FALSE' or s == '0' then return false end
  if s == '' then return nil end
  return warn('not a yes/no value: ' .. s)
end

local GENDER = { M = 'male', F = 'female', O = 'other', A = 'other', U = 'unknown', N = 'unknown' }

-- HL7 table 0001 -> FHIR administrative-gender (options.map replaces the codes).
function convert.gender(rep, options)
  local s = hl7.part(rep)
  if s == '' then return nil end
  local map = options and options.map or GENDER
  local v = map[s] or map[s:upper()]
  if v == nil then return warn('no gender code for ' .. s) end
  return v
end

-- A code through options.map (options.default when it has no entry); with
-- options.system the result is a Coding.
function convert.lookup(rep, options)
  local s = hl7.part(rep)
  if s == '' then return nil end
  local v = (options.map or {})[s]
  if v == nil then v = options.default end
  if v == nil then return warn('no lookup entry for ' .. s) end
  if options.system then return fhir.obj('system', options.system, 'code', v) end
  return v
end

-- Where each part sits in the v2 types the identifier and name functions
-- read. XCN (a person with an ID, e.g. PV1-7) carries the ID first and the
-- name one place later than XPN.
local LAYOUTS = {
  CX = { value = 1, authority = 4, id_type = 5 },
  XPN = { family = 1, given = 2, middle = 3, suffix = 4, prefix = 5, use = 7 },
  XCN = { value = 1, authority = 9, id_type = 13, family = 2, given = 3, middle = 4, suffix = 5, prefix = 6, use = 10 },
}

local function layout(options, default)
  return LAYOUTS[options and options.layout or default] or LAYOUTS[default]
end

-- CX (or XCN) -> Identifier. The system defaults to the assigning
-- authority's OID.
function convert.identifier(rep, options)
  options = options or {}
  local L = layout(options, 'CX')
  local value = hl7.part(rep, L.value)
  if value == '' then return nil end
  local system = options.system
  if not system then
    local oid, kind = hl7.part(rep, L.authority, 2), hl7.part(rep, L.authority, 3)
    if oid ~= '' and kind:upper() == 'ISO' then system = 'urn:oid:' .. oid end
  end
  local code = hl7.part(rep, L.id_type)
  local idType = code ~= '' and fhir.obj('coding', {
    fhir.obj('system', 'http://terminology.hl7.org/CodeSystem/v2-0203', 'code', code),
  }) or nil
  return fhir.obj('use', nonblank(options.use), 'type', idType, 'system', nonblank(system), 'value', value)
end

local NAME_USE = { L = 'official', D = 'usual', A = 'usual', M = 'maiden', N = 'nickname', C = 'old', S = 'anonymous', T = 'temp' }

-- XPN (or XCN) -> HumanName.
function convert.human_name(rep, options)
  local L = layout(options, 'XPN')
  local family = nonblank(hl7.part(rep, L.family))
  local given = {}
  for _, i in ipairs({ L.given, L.middle }) do
    local g = hl7.part(rep, i)
    if g ~= '' then given[#given + 1] = g end
  end
  if not family and #given == 0 then return nil end
  return fhir.obj(
    'use', NAME_USE[hl7.part(rep, L.use)],
    'family', family,
    'given', given,
    'prefix', { nonblank(hl7.part(rep, L.prefix)) },
    'suffix', { nonblank(hl7.part(rep, L.suffix)) })
end

local ADDRESS_USE = { H = 'home', B = 'work', O = 'work', C = 'temp', BA = 'old' }

-- XAD -> Address.
function convert.address(rep)
  local line = {}
  for _, i in ipairs({ 1, 2 }) do
    local l = hl7.part(rep, i)
    if l ~= '' then line[#line + 1] = l end
  end
  local kind = hl7.part(rep, 7)
  -- An address with only a use or type is no address.
  if #line == 0 and hl7.part(rep, 3) .. hl7.part(rep, 4) .. hl7.part(rep, 5) .. hl7.part(rep, 6) == '' then return nil end
  return fhir.obj(
    'use', ADDRESS_USE[kind],
    'type', kind == 'M' and 'postal' or nil,
    'line', line,
    'city', hl7.part(rep, 3),
    'state', hl7.part(rep, 4),
    'postalCode', hl7.part(rep, 5),
    'country', hl7.part(rep, 6))
end

local TELECOM_USE = { PRN = 'home', ORN = 'home', VHN = 'home', WPN = 'work', ASN = 'work', EMR = 'temp' }
local TELECOM_SYSTEM = { PH = 'phone', CP = 'phone', FX = 'fax', BP = 'pager', MD = 'other', INTERNET = 'email', ['X.400'] = 'email' }

-- XTN -> ContactPoint. options.system forces the system.
function convert.telecom(rep, options)
  local equip, email = hl7.part(rep, 3), hl7.part(rep, 4)
  local system = options and options.system or TELECOM_SYSTEM[equip:upper()]
  if not system then system = (email ~= '' and hl7.part(rep, 1) == '') and 'email' or 'phone' end
  local value
  if system == 'email' then
    value = email ~= '' and email or hl7.part(rep, 1)
  else
    value = hl7.part(rep, 1)
    if value == '' then
      local area, num, ext = hl7.part(rep, 6), hl7.part(rep, 7), hl7.part(rep, 8)
      if num ~= '' then
        value = (area ~= '' and ('(' .. area .. ') ') or '') .. num .. (ext ~= '' and (' x' .. ext) or '')
      end
    end
  end
  if value == '' then return nil end
  local use = equip:upper() == 'CP' and 'mobile' or TELECOM_USE[hl7.part(rep, 2)]
  return fhir.obj('system', system, 'value', value, 'use', use)
end

local CODE_SYSTEMS = {
  LN = 'http://loinc.org',
  SCT = 'http://snomed.info/sct',
  SNM = 'http://snomed.info/sct',
  I10 = 'http://hl7.org/fhir/sid/icd-10-cm',
  I10C = 'http://hl7.org/fhir/sid/icd-10-cm',
  ICD10CM = 'http://hl7.org/fhir/sid/icd-10-cm',
  I9 = 'http://hl7.org/fhir/sid/icd-9-cm',
  I9C = 'http://hl7.org/fhir/sid/icd-9-cm',
  RXNORM = 'http://www.nlm.nih.gov/research/umls/rxnorm',
  RXN = 'http://www.nlm.nih.gov/research/umls/rxnorm',
  UCUM = 'http://unitsofmeasure.org',
  CPT = 'http://www.ama-assn.org/go/cpt',
  C4 = 'http://www.ama-assn.org/go/cpt',
  NDC = 'http://hl7.org/fhir/sid/ndc',
  CVX = 'http://hl7.org/fhir/sid/cvx',
}

-- The FHIR system URL for a v2 coding system name (LN, SCT, HL70001, ...).
local function code_system(name)
  local id = name:match('^HL7(%d%d%d%d)$')
  return CODE_SYSTEMS[name:upper()] or (id and 'http://terminology.hl7.org/CodeSystem/v2-' .. id)
end

-- CE/CWE -> Coding. options.system replaces the coding system component.
function convert.coding(rep, options)
  local code = hl7.part(rep, 1)
  if code == '' then return nil end
  local system = nonblank(options and options.system or '') or code_system(hl7.part(rep, 3))
  return fhir.obj('system', system, 'code', code, 'display', hl7.part(rep, 2))
end

-- CE/CWE -> CodeableConcept.
function convert.codeable_concept(rep, options)
  local text = hl7.part(rep, 9)
  return fhir.obj('coding', { convert.coding(rep, options) }, 'text', nonblank(text) or hl7.part(rep, 2))
end

-- --- X12 ---------------------------------------------------------------------------
-- These read a whole X12 segment, as x12.first gives one for a segment's
-- path ('2010BA/NM1').

-- Element e (component c) of a segment; '' when absent.
local function element(seg, e, c)
  local el = seg and seg:child(e)
  if not el then return '' end
  if el:count() == 0 then return el:value() or '' end
  local comp = el:child(c or 1)
  return comp and comp:value() or ''
end

-- NM1 -> HumanName: last name (NM1-3), first and middle (NM1-4, NM1-5),
-- prefix (NM1-6) and suffix (NM1-7). An organization (NM1-2 = 2) gives its
-- name as text.
function convert.x12_name(seg)
  local family = nonblank(element(seg, 3))
  local given = {}
  for _, i in ipairs({ 4, 5 }) do
    local g = element(seg, i)
    if g ~= '' then given[#given + 1] = g end
  end
  if not family and #given == 0 then return nil end
  if element(seg, 2) == '2' then return fhir.obj('text', family) end
  return fhir.obj(
    'family', family,
    'given', given,
    'prefix', { nonblank(element(seg, 6)) },
    'suffix', { nonblank(element(seg, 7)) })
end

-- What an X12 identification qualifier (NM1-8, REF-1) says the ID is: its
-- v2 identifier type, and the system FHIR knows it by.
local X12_ID_TYPES = { MI = 'MB', XX = 'NPI', ['24'] = 'TAX', EI = 'TAX', ['34'] = 'SS', SY = 'SS', ['1W'] = 'MB' }
local X12_ID_SYSTEMS = {
  XX = 'http://hl7.org/fhir/sid/us-npi',
  ['34'] = 'http://hl7.org/fhir/sid/us-ssn',
  SY = 'http://hl7.org/fhir/sid/us-ssn',
}

-- NM1 (its ID, NM1-9, and qualifier, NM1-8) or REF (REF-2 and REF-1) ->
-- Identifier. options.system replaces the system the qualifier implies.
function convert.x12_identifier(seg, options)
  if not seg then return nil end
  local qual, value
  if seg:name() == 'NM1' then
    qual, value = element(seg, 8), element(seg, 9)
  else
    qual, value = element(seg, 1), element(seg, 2)
  end
  if value == '' then return nil end
  local kind = X12_ID_TYPES[qual]
  local idType = kind and fhir.obj('coding', {
    fhir.obj('system', 'http://terminology.hl7.org/CodeSystem/v2-0203', 'code', kind),
  }) or nil
  local system = nonblank(options and options.system or '') or X12_ID_SYSTEMS[qual]
  return fhir.obj('type', idType, 'system', system, 'value', value)
end

-- N3 or N4 -> Address, reading both from their loop: lines (N3-1, N3-2),
-- city, state, postal code and country (N4-1 to N4-4).
function convert.x12_address(seg)
  local loop = seg and seg:parent()
  if not loop then return nil end
  local n3, n4
  for i = 1, loop:count() do
    local child = loop:child(i)
    if child:name() == 'N3' and not n3 then n3 = child end
    if child:name() == 'N4' and not n4 then n4 = child end
  end
  local line = {}
  for _, i in ipairs({ 1, 2 }) do
    local l = element(n3, i)
    if l ~= '' then line[#line + 1] = l end
  end
  local city, state, postal = element(n4, 1), element(n4, 2), element(n4, 3)
  if #line == 0 and city .. state .. postal == '' then return nil end
  return fhir.obj('line', line, 'city', city, 'state', state, 'postalCode', postal, 'country', element(n4, 4))
end

-- Runs a rule's own Lua, skipped when the source field is empty. It gets
-- the field's parsed node, then the message, its type and (for a resource
-- made per segment) that segment, and returns the FHIR value.
function convert.custom(fn, field, ...)
  if field == nil then return nil end
  return (fn(field, ...))
end

return convert
