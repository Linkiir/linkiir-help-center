-- Functions the data maps use to read and write HL7 v2 messages.
-- Do not edit by hand: Data Map updates replace this file.
--
-- The maps work on the parsed message itself: hl7.first(PID[5]) is the
-- first repetition of PID-5 that holds something, hl7.part(rep, 2) the text
-- of its second component, and hl7.put(pidOut, 5, rep) copies it into the
-- output. X12 values (x12.first) read the same way.
--
-- The message is read as its schema says: a field the schema has not
-- repeat holds its components itself (it is its own only repetition), and
-- the segments of the structure's groups sit in group nodes
-- (PATIENT_RESULT > PATIENT > PID). These functions find segments wherever
-- they are, so a map reads and builds the same either way.
-- checksum: 7b064e73

local hl7 = {}

local X12 = 102   -- node:protocol() of an X12 message (HL7 v2 is 101)
local MESSAGE, GROUP, SEGMENT, FIELD = 1, 2, 3, 4   -- node:type()

-- Field `f`, component `c` and subcomponent `s` of a path: '5', '5.2', '5.2.1'.
local function parts(path)
  local f, c, s = tostring(path):match('^(%d+)%.?(%d*)%.?(%d*)$')
  if not f then error('not a field path: ' .. tostring(path), 3) end
  return tonumber(f), tonumber(c), tonumber(s)
end

-- --- Reading -----------------------------------------------------------------

-- A leaf node's text: HL7 escapes decoded ('' for HL7's null, ""), or for
-- X12 the value without the padding ISA's elements carry.
local function value_of(node)
  local v = node and node:value() or ''
  if node and node:protocol() == X12 then
    local seg = node:parent()
    if seg and seg:name() ~= 'ISA' then seg = seg:parent() end
    return (seg and seg:name() == 'ISA') and (v:gsub(' +$', '')) or v
  end
  if v == '' or v == '""' then return '' end
  return linkiir.data.unescape(v, node)
end

-- Whether a node holds anything.
local function holds(node)
  if node:count() == 0 then return value_of(node) ~= '' end
  for i = 1, node:count() do
    if holds(node:child(i)) then return true end
  end
  return false
end

-- Whether a field holds repetitions; one the schema has not repeat holds
-- its components itself.
local function repeated(field)
  return field:count() > 0 and field:child(1):type() == FIELD
end

-- The repetitions of a field: its own, or the field itself when it doesn't
-- repeat.
local function repetitions(field)
  if not repeated(field) then return { field } end
  local list = {}
  for r = 1, field:count() do list[r] = field:child(r) end
  return list
end

-- The part of segment `seg` at `path`, in repetition `r` - nil when the
-- message has none. Without `r`, a field path gives the whole field and a
-- component path reads the first repetition.
function hl7.get(seg, path, r)
  local f, c, s = parts(path)
  local node = seg and seg[f]
  if node and (c or r) then node = repetitions(node)[r or 1] end
  if node and c then node = node[c] end
  if node and s then node = node[s] end
  return node
end

-- How many repetitions a field has (0 when the message has none).
function hl7.count(field)
  if not field then return 0 end
  if repeated(field) then return field:count() end
  return field:count() > 0 and 1 or 0
end

-- The repetitions of field `f` that hold something - or of their component
-- `comp` (subcomponent `sub`).
local function filled(f, comp, sub)
  local list = {}
  if not f then return list end
  if f:count() == 0 then   -- MSH-1 and MSH-2 have no parts
    if holds(f) then list[1] = f end
    return list
  end
  for _, node in ipairs(repetitions(f)) do
    if comp then node = node:child(comp) end
    if node and sub then
      if node:count() > 0 then node = node:child(sub) elseif sub > 1 then node = nil end
    end
    if node and holds(node) then list[#list + 1] = node end
  end
  return list
end

-- The first repetition of a field that holds something, or nil:
-- hl7.first(PID[7]), hl7.first(PID[3], 1) for its first component.
function hl7.first(f, comp, sub)
  return filled(f, comp, sub)[1]
end

-- Each repetition that holds something, numbered from 1:
-- for r, rep in hl7.each(PID[3]) do ... end
function hl7.each(f, comp, sub)
  return ipairs(filled(f, comp, sub))
end

-- The text of a node's first component, escapes decoded; '' when it has none.
function hl7.text(node)
  while node and node:count() > 0 do node = node:child(1) end
  return value_of(node)
end

-- The text of component i, subcomponent j (both 1 by default) of a value:
-- a repetition (hl7.first's), a component (its subcomponents), an X12
-- element (its components) or text. '' when there is none.
function hl7.part(v, i, j)
  i, j = i or 1, j or 1
  if v == nil then return '' end
  if type(v) ~= 'userdata' then
    if type(v) ~= 'table' then return (i == 1 and j == 1) and tostring(v) or '' end
    local c = v[i]
    if type(c) == 'table' then c = c[j] elseif j > 1 then c = nil end
    return (c == nil or c == '""') and '' or tostring(c)
  end
  local c = v:count() == 0 and (i == 1 and v or nil) or v:child(i)
  if c and c:count() > 0 then c = c:child(j) elseif j > 1 then c = nil end
  return c and value_of(c) or ''
end

-- The names Custom Lua written for earlier versions of these helpers uses.
hl7.leaf, hl7.first_node, hl7.each_node = hl7.part, hl7.first, hl7.each

-- --- Writing -----------------------------------------------------------------

-- The child at `i` of an output node, made when missing.
local function child(node, i)
  if not node[i] then node[i] = '' end
  return node[i]
end

-- What a node is: 2 a field, 3 a repetition (or a field that doesn't
-- repeat, which holds its components as one does), 4 a component, 5 a
-- subcomponent.
local function depth(node)
  local t = node:type()
  if t == FIELD then
    if node:parent():type() == FIELD or not repeated(node) and node:count() > 0 then return 3 end
    return 2
  end
  return t - 1
end

-- Repetition `r` of the output field `field`, made when missing; nil when
-- the field doesn't repeat and `r` is past its one.
local function repetition(field, r)
  if field:count() == 0 then field[1] = '' end   -- made as the schema has it: a repetition or a component
  if not repeated(field) then return r == 1 and field or nil end
  return child(field, r)
end

-- The message a node is in.
local function message(node)
  while node:parent() do node = node:parent() end
  return node
end

-- A message's delimiters: field, component, repetition, escape, subcomponent.
local function delimiters(msg)
  local msh = msg.MSH
  return msh and (msh[1]:value() .. msh[2]:value()) or '|^~\\&'
end

-- An input node as text for the output segment `seg`: as it is, unless the
-- two messages have different delimiters - then rebuilt with the output's.
local function text_for(node, seg)
  local from, to = delimiters(message(node)), delimiters(message(seg))
  if from == to then return node:S() end
  local function build(n, d)
    if n:count() == 0 then return linkiir.data.escape(value_of(n), seg) end
    local sep = ({ [2] = to:sub(3, 3), [3] = to:sub(2, 2), [4] = to:sub(5, 5) })[d]
    local list = {}
    for i = 1, n:count() do list[i] = build(n:child(i), d + 1) end
    return table.concat(list, sep)
  end
  return build(node, depth(node))
end

-- The text of a node's first subcomponent, for the output segment `seg`.
local function first_leaf(node, seg)
  while node:count() > 0 do node = node:child(1) end
  return text_for(node, seg)
end

-- What `value` writes at depth `at` of the output segment `seg` (3 a
-- repetition, 4 a component, 5 a subcomponent): HL7 text for the node
-- there, or the texts of its parts (a part of a repetition may itself be a
-- list, its subcomponents). nil when it holds nothing.
local function written(value, at, seg)
  if type(value) == 'userdata' and value:protocol() ~= X12 then
    local from = depth(value)
    if from == 2 and at > 3 then value, from = value[1], 3 end   -- a field into a component: its first repetition
    if from == 2 or from == at or from == 5 or at == 5 then
      local text = at == 5 and first_leaf(value, seg) or text_for(value, seg)
      if text == '' or text == '""' then return nil end
      return text
    end
    local list = {}
    for i = 1, value:count() do list[i] = first_leaf(value:child(i), seg) end
    return table.concat(list) ~= '' and list or nil
  end
  if type(value) == 'userdata' then   -- an X12 element: its components
    local list = {}
    for i = 1, math.max(value:count(), 1) do list[i] = hl7.part(value, i) end
    value = list
  end
  if type(value) ~= 'table' then
    local text = value ~= nil and tostring(value) or ''
    if text == '' then return nil end
    return linkiir.data.escape(text, seg)
  end
  -- A list of components, each text or a list of subcomponents.
  local list, any = {}, false
  for i, comp in ipairs(value) do
    local subs = type(comp) == 'table' and comp or { comp }
    local out = {}
    for k, sub in ipairs(subs) do
      local text = (sub == nil or sub == '""') and '' or tostring(sub)
      any = any or text ~= ''
      out[k] = linkiir.data.escape(text, seg)
    end
    list[i] = at == 3 and out or out[1] or ''
  end
  if not any then return nil end
  if at == 5 then return type(list[1]) == 'table' and list[1][1] or list[1] end
  return list
end

-- Writes `value` at `path` of the output segment `seg` ('5', '5.1' or
-- '5.1.2'), in repetition `r` (1 by default). The value is:
--   * a part of an HL7 v2 input, copied as it is - a wider part into a
--     narrower place gives its parts one level down (a field into a
--     component: its components as subcomponents), a narrower one one up;
--   * text, written as it is;
--   * a list of components ({ 'ADT', 'A01', 'ADT_A01' }), each text or a
--     list of subcomponents.
-- An empty value, or HL7's null (""), writes nothing. Returns whether it
-- wrote. MSH-1 and MSH-2 are never written, nor a repetition past the first
-- of a field that doesn't repeat.
function hl7.put(seg, path, value, r)
  local f, c, s = parts(path)
  r = r or 1
  if seg:name() == 'MSH' and f <= 2 then return false end
  local what = written(value, s and 5 or c and 4 or 3, seg)
  if what == nil then return false end
  if not c and r == 1 and type(what) == 'string' then
    seg[f] = what
    return true
  end
  local rep = repetition(child(seg, f), r)
  if not rep then return false end
  local node   -- the output node written, made as needed
  if not c then
    if rep:parent():type() == FIELD then
      local field = rep:parent()
      field[r] = ''
      node = field[r]
    else
      seg[f] = ''
      node = seg[f]
    end
  elseif not s then
    rep[c] = ''
    node = rep[c]
  else
    child(rep, c)[s] = what
    return true
  end
  if type(what) == 'string' then
    node:set(what)
  else
    for i, part in ipairs(what) do
      if type(part) == 'table' then
        node[i] = ''
        for k, sub in ipairs(part) do node[i][k] = sub end
      else
        node[i] = part
      end
    end
  end
  return true
end

-- Copies every field of the input segment `segIn` into the output segment
-- `seg` - for MSH from MSH-3 on. Returns whether there was one to copy.
function hl7.copy_segment(seg, segIn)
  if type(segIn) ~= 'userdata' then return false end
  local delimiters = seg:name() == 'MSH' and { seg[1]:value(), seg[2]:value() }
  seg:map(segIn)
  if delimiters then seg[1], seg[2] = delimiters[1], delimiters[2] end
  return true
end

-- Rejects the message when a required rule wrote nothing (a 'Message
-- rejected:' error, which On Error can skip).
function hl7.required(wrote, from, to)
  if not wrote then error('Message rejected: ' .. from .. ' gave no value for ' .. to .. ', which requires one', 0) end
end

-- Runs a rule's Custom Lua on the input `field`; nothing when it is missing.
function hl7.custom(fn, field, ...)
  if field == nil then return nil end
  return (fn(field, ...))
end

-- --- Segments ----------------------------------------------------------------

-- The segments of a message in order, those in its groups included.
local function segments_of(msg)
  local list = {}
  local function walk(node)
    for i = 1, node:count() do
      local c = node:child(i)
      if c:type() == GROUP then walk(c) else list[#list + 1] = c end
    end
  end
  walk(msg)
  return list
end

-- Whether a message's segments sit in group nodes: one built, or read, with
-- a structure that has groups.
local function in_groups(msg)
  for i = 1, msg:count() do
    if msg:child(i):type() == GROUP then return true end
  end
  return false
end

-- Where each segment these functions hand out sits in its message, so a map
-- can ask for the segments of its own group (hl7.near, hl7.within, hl7.child):
-- a segment node can't say which of the message's segments it is, so the
-- place (its number in segments_of) is kept here, by node.
local PLACE = setmetatable({}, { __mode = 'k' })   -- segment -> { msg = , i = }
local PLACED = setmetatable({}, { __mode = 'k' })  -- message -> the places handed out in it

local function place(msg, i, seg)
  local at = { msg = msg, i = i, name = seg:name() }
  PLACE[seg] = at
  local list = PLACED[msg]
  if not list then list = setmetatable({}, { __mode = 'v' }); PLACED[msg] = list end
  list[#list + 1] = at
  return seg
end

-- A segment was added to `msg` at `i`: the places at or after it move down one.
local function shifted(msg, i)
  for _, at in pairs(PLACED[msg] or {}) do
    if at.i >= i then at.i = at.i + 1 end
  end
end

-- Every `name` segment of a message, in order: for i, OBX in hl7.segments(msgIn, 'OBX')
function hl7.segments(msg, name)
  local list = {}
  for i, seg in ipairs(segments_of(msg)) do
    if seg:name() == name then list[#list + 1] = place(msg, i, seg) end
  end
  return ipairs(list)
end

-- The first `name` segment of a message, in a group or not; nil when it has
-- none: local PID = hl7.first_segment(msgIn, 'PID') or {}
function hl7.first_segment(msg, name)
  for i, seg in ipairs(segments_of(msg)) do
    if seg:name() == name then return place(msg, i, seg) end
  end
  return nil
end

local grouping   -- hl7.grouped's: forgets a message's groups when it changes

-- Whether `parent`'s `name` children may repeat there: read by name, a
-- segment or group that repeats gives its occurrences, the first being
-- itself.
local function repeats(parent, name)
  local first = parent[name]
  local one = first and first[1]
  return one ~= nil and one:type() == first:type() and one:name() == name
end

-- The first `name` segment in a group or message, in its groups too.
local function first_named(node, name)
  for i = 1, node:count() do
    local c = node:child(i)
    if c:type() == SEGMENT and c:name() == name then return c end
    if c:type() == GROUP then
      local found = first_named(c, name)
      if found then return found end
    end
  end
  return nil
end

-- Another `name` segment after the output's `name` segment `seg`: next to
-- it when its group lets it repeat, else the one in a new occurrence of the
-- nearest group around it that repeats (a second OBX goes in another
-- OBSERVATION), going up no more than `up` groups. Where none does, next to
-- it all the same.
local function another(seg, name, up)
  local node = seg
  for _ = 0, up or math.huge do
    local parent = node:parent()
    if not parent then break end
    if repeats(parent, node:name()) then
      local added = parent:add(node:name(), node)
      return added:type() == SEGMENT and added or first_named(added, name)
    end
    if parent:type() == MESSAGE then break end
    node = parent
  end
  return seg:parent():add(name, seg)
end

-- The n-th `name` segment of the output (n is 1 by default), added after the
-- segments `order` puts before it when the output has none.
function hl7.segment(msgOut, order, name, n)
  n = n or 1
  if in_groups(msgOut) then
    -- Built with groups, the output has a place for each segment of its
    -- structure: the first of a name, then another as its groups allow.
    local seen, last = 0, nil
    for _, seg in ipairs(segments_of(msgOut)) do
      if seg:name() == name and (seen == 0 or not seg:isNull()) then
        seen, last = seen + 1, seg
        if seen == n then return seg end
      end
    end
    grouping(msgOut)
    if last then return another(last, name) end
    return msgOut:add(name)   -- one the structure doesn't have
  end
  local rank = {}
  for i, seg in ipairs(order) do rank[seg] = rank[seg] or i end
  local seen, after, current = 0, 0, 0
  for i = 1, msgOut:count() do
    local seg = msgOut:child(i)
    local holds = not seg:isNull()
    if seg:name() == name and (seen == 0 or holds) then
      seen = seen + 1
      if seen == n then return place(msgOut, i, seg) end
    end
    current = rank[seg:name()] or current
    if holds and current <= (rank[name] or math.huge) then after = i end
  end
  -- Another occurrence of a repeating group it starts (a second OBR) goes
  -- after the whole of the one before, segments made under it included.
  local before = seen > 0 and hl7.last_of_group(msgOut, name)
  if before and before > after then after = before end
  local seg = msgOut:add(name, after > 0 and msgOut:child(after) or nil)
  local i = after + 1
  if after == 0 then   -- placed where the structure puts it: find it
    for k = 1, msgOut:count() do
      local s = msgOut:child(k)
      if s:name() == name and s:isNull() then i = k break end
    end
  end
  shifted(msgOut, i)
  grouping(msgOut)
  return place(msgOut, i, seg)
end

-- --- Groups ------------------------------------------------------------------
-- An HL7 v2 message is a list of segments; its structure groups them (an
-- ORU R01's ORDER_OBSERVATION is an ORC, an OBR, its NTEs and OBSERVATION
-- groups, each an OBX and its NTEs). The runtime reads a message into group
-- nodes when it fits its schema's structure; one that doesn't is left a
-- list. So the groups of a message read are found here, from the structure
-- the generated map gives (source.json's), whichever way it was read:
--   { 'MSH', 'SFT*', { 'PATIENT_RESULT+', { 'PATIENT?', 'PID', ... }, ... } }
-- a segment by name, a group as a table whose first item is its name, each
-- marked ? (optional), * (optional, repeats) or + (repeats). The segments
-- are read against it as HL7 v2 is: each goes in the group the structure
-- has next for it, and one that starts a repeating group again opens
-- another occurrence of it. A segment the structure doesn't have stays in
-- the group it came in. A message the map builds with groups is built in
-- its group nodes (hl7.segment, hl7.child).

local COMPILED = setmetatable({}, { __mode = 'k' })  -- structure -> its compiled groups
local STRUCTURE = setmetatable({}, { __mode = 'k' }) -- message -> compiled structure
local PARSED = setmetatable({}, { __mode = 'k' })    -- message -> its groups, read

local function marked(s)
  local name, mark = tostring(s):match('^([%w_]+)([%?%*%+]?)$')
  return name, mark == '*' or mark == '+', mark == '?' or mark == '*'
end

local function compile(def, root)
  local g = { kids = {}, first = {}, name = '' }
  local from = 1
  if not root then
    g.name, g.rep, g.opt = marked(def[1])
    from = 2
  end
  for k = from, #def do
    local d = def[k]
    if type(d) == 'table' then
      local sub = compile(d)
      g.kids[#g.kids + 1] = { group = sub, rep = sub.rep, opt = sub.opt }
    else
      local name, rep, opt = marked(d)
      g.kids[#g.kids + 1] = { seg = name, rep = rep, opt = opt }
    end
  end
  -- What can start it: its segments up to the first one it must have.
  for _, kid in ipairs(g.kids) do
    if kid.seg then g.first[kid.seg] = true else for n in pairs(kid.group.first) do g.first[n] = true end end
    if not kid.opt then break end
  end
  return g
end

-- The groups of the segments `segs`: of[i] is the occurrence segment i is
-- in, each { group, parent, segs = { i, ... }, kids = { occurrence, ... } }.
local function parse(segs, g)
  local root = { group = g, segs = {}, kids = {} }
  local stack = { { occ = root, pos = 1 } }
  local of = {}
  local function open(f, group)
    local occ = { group = group, parent = f.occ, segs = {}, kids = {} }
    f.occ.kids[#f.occ.kids + 1] = occ
    return { occ = occ, pos = 1 }
  end
  local function put(depth, name, i)
    local f = stack[depth]
    local kids = f.occ.group.kids
    for k = f.pos, #kids do
      local kid = kids[k]
      if kid.seg == name or (kid.group and kid.group.first[name]) then
        for d = #stack, depth + 1, -1 do stack[d] = nil end
        f.pos = kid.rep and k or k + 1
        if kid.seg then
          of[i] = f.occ
          f.occ.segs[#f.occ.segs + 1] = i
          return true
        end
        stack[depth + 1] = open(f, kid.group)
        return put(depth + 1, name, i)
      end
    end
    return false
  end
  for i = 1, #segs do
    local name = segs[i]:name()
    local done = false
    for depth = #stack, 1, -1 do
      if put(depth, name, i) then done = true break end
      local f = stack[depth]
      if depth > 1 and f.occ.group.rep and f.occ.group.first[name] then
        -- It starts this repeating group again: another occurrence.
        for d = #stack, depth, -1 do stack[d] = nil end
        stack[depth] = open(stack[depth - 1], f.occ.group)
        done = put(depth, name, i)
        break
      end
    end
    if not done then
      local f = stack[#stack]
      of[i] = f.occ
      f.occ.segs[#f.occ.segs + 1] = i
    end
  end
  return { of = of, root = root, count = #segs }
end

-- Reads `msg` against `structure` (the generated map's), so the segments of
-- a group can be found. A message whose type the map has no structure for is
-- read as a plain list of segments, as before.
function hl7.grouped(msg, structure)
  if structure then
    local g = COMPILED[structure]
    if not g then g = compile(structure, true); COMPILED[structure] = g end
    STRUCTURE[msg] = g
    PARSED[msg] = nil
  end
  return msg
end

grouping = function(msg) PARSED[msg] = nil end

-- A message's groups (nil without a structure) and its segments, in order.
local function groups(msg)
  local segs = segments_of(msg)
  local g = STRUCTURE[msg]
  if not g then return nil, segs end
  local p = PARSED[msg]
  if not p or p.count ~= #segs then p = parse(segs, g); PARSED[msg] = p end
  return p, segs
end

-- The last segment of the group occurrence the last `name` segment of `msg`
-- starts - when its structure has `name` start a repeating group (an OBR, an
-- ORDER_OBSERVATION) - else nil.
function hl7.last_of_group(msg, name)
  local p, segs = groups(msg)
  if not p then return nil end
  local at
  for i = #segs, 1, -1 do
    if segs[i]:name() == name then at = i break end
  end
  local occ = at and p.of[at]
  if not occ or not occ.group.rep or not occ.group.first[name] then return nil end
  local last = at
  local function walk(o)
    for _, i in ipairs(o.segs) do if i > last then last = i end end
    for _, kid in ipairs(o.kids) do walk(kid) end
  end
  walk(occ)
  return last
end

-- Where segment `seg` is: its message's groups, its place and the message's
-- segments, when known.
local function where(seg)
  local at = PLACE[seg]
  if not at then return nil end
  local p, segs = groups(at.msg)
  if p and at.i <= #segs and segs[at.i]:name() == at.name then return p, at, segs end
  return nil, at, segs
end

-- The groups to go through, from `group`, to reach a `name` segment: {} for
-- one of its own, { 'OBSERVATION' } for one in a group of it; the first the
-- structure has. nil when it has none.
local function path_to(group, name)
  for _, kid in ipairs(group.kids) do
    if kid.seg == name then return {} end
  end
  for _, kid in ipairs(group.kids) do
    if kid.group then
      local rest = path_to(kid.group, name)
      if rest then
        local path = { kid.group.name }
        for _, g in ipairs(rest) do path[#path + 1] = g end
        return path
      end
    end
  end
  return nil
end

-- The `name` segments `path` leads to from occurrence `occ`, in order.
local function found_in(segs, occ, path, name, depth, out)
  depth = depth or 1
  out = out or {}
  if depth > #path then
    for _, i in ipairs(occ.segs) do
      if segs[i]:name() == name then out[#out + 1] = i end
    end
  else
    for _, kid in ipairs(occ.kids) do
      if kid.group.name == path[depth] then found_in(segs, kid, path, name, depth + 1, out) end
    end
  end
  table.sort(out)
  return out
end

-- The occurrence holding `name` segments for segment `seg`'s group, and the
-- way down to them: its own group, else the nearest one around it whose
-- structure has them.
local function scope_of(p, at, name)
  local occ = p.of[at.i]
  while occ do
    local path = path_to(occ.group, name)
    if path then return occ, path end
    occ = occ.parent
  end
  return nil
end

-- The `name` segments of segment `parent`'s group, in order: for an OBR, its
-- OBXs (the OBSERVATION groups after it, up to the next OBR). Read without a
-- structure, the `name` segments after `parent` up to the next segment
-- named like it.
function hl7.within(msg, parent, name)
  local list = {}
  local p, at, segs = where(parent)
  if p then
    local occ, path = scope_of(p, at, name)
    if occ then
      for _, i in ipairs(found_in(segs, occ, path, name)) do list[#list + 1] = place(msg, i, segs[i]) end
    end
    return ipairs(list)
  end
  if not at then return hl7.segments(msg, name) end
  for i = at.i + 1, #segs do
    local seg = segs[i]
    if seg:name() == at.name then break end
    if seg:name() == name then list[#list + 1] = place(msg, i, seg) end
  end
  return ipairs(list)
end

-- The first `name` segment in occurrence `occ`: its own, or in a group of it
-- - only the groups that don't repeat, unless `deep`; never in `skip`.
local function first_in(segs, occ, name, deep, skip)
  local best
  for _, i in ipairs(occ.segs) do
    if segs[i]:name() == name then best = i break end
  end
  for _, kid in ipairs(occ.kids) do
    if kid ~= skip and (deep or not kid.group.rep) and (skip == nil or kid.group ~= skip.group or deep == 'all') then
      local i = first_in(segs, kid, name, deep)
      if i and (not best or i < best) then best = i end
    end
  end
  return best
end

-- The `name` segment that goes with segment `seg`: in its own group (an
-- OBR's first OBX, an OBX's NTE), else the nearest group around it (an OBX's
-- OBR, its patient's PID) - never one in another occurrence of a repeating
-- group it is in (another result's NTE). nil when there is none; read
-- without a structure, the message's first, as hl7.first_segment.
function hl7.near(msg, seg, name)
  local p, at, segs = where(seg)
  if not p then return hl7.first_segment(msg, name) end
  local occ = p.of[at.i]
  local i = first_in(segs, occ, name, 'all')
  local from = occ
  occ = occ.parent
  while not i and occ do
    -- Its own segments and the groups that don't repeat, then the rest
    -- but other occurrences of the group it came from.
    i = first_in(segs, occ, name, false, from) or first_in(segs, occ, name, true, from)
    from = occ
    occ = occ.parent
  end
  return i and place(msg, i, segs[i]) or nil
end

-- The groups to go through from the output group (or message) `node` to
-- its `name` segments: {} for its own, { 'OBSERVATION' } for those in a
-- group of it; the first way it has. nil when it has none.
local function way_to(node, name)
  for i = 1, node:count() do
    local c = node:child(i)
    if c:type() == SEGMENT and c:name() == name then return {} end
  end
  for i = 1, node:count() do
    local c = node:child(i)
    if c:type() == GROUP then
      local rest = way_to(c, name)
      if rest then
        table.insert(rest, 1, c:name())
        return rest
      end
    end
  end
  return nil
end

-- The `name` segments `way` leads to from the output node `node`, in order.
local function along(node, way, name, k, out)
  k, out = k or 1, out or {}
  for i = 1, node:count() do
    local c = node:child(i)
    if k > #way then
      if c:type() == SEGMENT and c:name() == name then out[#out + 1] = c end
    elseif c:type() == GROUP and c:name() == way[k] then
      along(c, way, name, k + 1, out)
    end
  end
  return out
end

-- The n-th `name` segment of output segment `parent`'s group, added where
-- the structure puts it in that group when it has fewer: an OBX made per
-- result of an OBR goes after that OBR's NTEs and earlier OBXs.
function hl7.child(parent, name, n)
  n = n or 1
  local msg = message(parent)
  if in_groups(msg) then
    -- Its own group, else the nearest one around it, that has a place for
    -- `name` segments.
    local scope, way = parent:parent()
    while scope do
      way = way_to(scope, name)
      if way then break end
      scope = scope:parent()
    end
    if not scope then return parent:parent():add(name, parent) end   -- one the structure doesn't have
    local have = along(scope, way, name)
    if have[n] then return have[n] end
    return another(have[#have], name, #way)
  end
  local p, at, segs = where(parent)
  if not at then error('hl7.child: ' .. tostring(name) .. ' has no parent segment the map made', 2) end
  msg = at.msg
  local occ, path
  if p then occ, path = scope_of(p, at, name) end
  if occ then
    local have = found_in(segs, occ, path, name)
    if have[n] then return place(msg, have[n], segs[have[n]]) end
    -- After the last segment of the group the structure has at or before it.
    local rank = {}
    for k, kid in ipairs(occ.group.kids) do
      local key = kid.seg or kid.group
      if rank[key] == nil then rank[key] = k end
    end
    local mine = path[1] and nil or rank[name]
    if path[1] then
      for k, kid in ipairs(occ.group.kids) do
        if kid.group and kid.group.name == path[1] then mine = k break end
      end
    end
    local after
    local function consider(i, r)
      if r and mine and r <= mine and (not after or i > after) then after = i end
    end
    for _, i in ipairs(occ.segs) do consider(i, rank[segs[i]:name()]) end
    local function all_in(o, out)
      for _, i in ipairs(o.segs) do out[#out + 1] = i end
      for _, kid in ipairs(o.kids) do all_in(kid, out) end
      return out
    end
    for _, kid in ipairs(occ.kids) do
      for _, i in ipairs(all_in(kid, {})) do consider(i, rank[kid.group]) end
    end
    if not after then after = at.i end
    local seg = msg:add(name, msg:child(after))
    shifted(msg, after + 1)
    grouping(msg)
    return place(msg, after + 1, seg)
  end
  -- No structure: the n-th `name` after it, up to the next like it.
  local seen, last = 0, at.i
  for i = at.i + 1, msg:count() do
    local s = msg:child(i)
    if s:name() == at.name then break end
    last = i
    if s:name() == name then
      seen = seen + 1
      if seen == n then return place(msg, i, s) end
    end
  end
  local seg = msg:add(name, msg:child(last))
  shifted(msg, last + 1)
  return place(msg, last + 1, seg)
end

-- MSH-9 as written, for the error about a message source.json doesn't know.
function hl7.messageType(msg)
  local ok, s = pcall(function() return msg.MSH[9]:S() end)
  return ok and s ~= '' and s or 'the message'
end

-- --- Values ------------------------------------------------------------------

local function warn(text)
  linkiir.log.warn('mapping: ' .. text)
end

-- A value's text: a node's first component, or the text a reader gave.
local function text_of(v)
  return type(v) == 'userdata' and hl7.text(v) or hl7.part(v)
end

-- A date/time cut to its date: YYYYMMDD (or less, as precise as it came).
function hl7.date(v)
  local s = text_of(v)
  if s == '' then return nil end
  return s:match('^%d%d%d%d%d?%d?%d?%d?') or warn('not an HL7 date: ' .. s)
end

-- A code through the table `codes`, `default` when it has no entry.
function hl7.lookup(v, codes, default)
  local s = text_of(v)
  if s == '' then return nil end
  local v = codes[s]
  if v == nil then v = default end
  if v == nil then warn('no lookup entry for ' .. s) end
  return v
end

-- The seconds in a unit of shift; months and years move the calendar.
local UNITS = { s = 1, min = 60, h = 3600, d = 86400, w = 604800 }
local FORMATS = { YYYYMMDD = '%Y%m%d', YYYYMMDDHHMM = '%Y%m%d%H%M', YYYYMMDDHHMMSS = '%Y%m%d%H%M%S' }

-- The time now, moved by `shift`: '-1d', '+2h', '+30min', '+1mo', '-1y'.
local function shifted(shift)
  local t = os.time()
  if shift == nil or shift == '' then return t end
  local sign, n, unit = tostring(shift):gsub('%s', ''):lower():match('^([+-]?)(%d+)(%a+)$')
  n = tonumber(n)
  if n and sign == '-' then n = -n end
  if n and (unit == 'mo' or unit == 'y') then
    local d = os.date('*t', t)
    if unit == 'y' then d.year = d.year + n else d.month = d.month + n end
    return os.time(d)
  end
  if not (n and UNITS[unit]) then
    error("can't shift the time by '" .. tostring(shift) .. "' - write it as -1d, +2h, +30min, +1mo or -1y", 0)
  end
  return t + n * UNITS[unit]
end

-- The local zone's offset from UTC at time t: +HHMM.
local function zone(t)
  local here, utc = os.date('*t', t), os.date('!*t', t)
  utc.isdst = here.isdst
  local offset = os.difftime(os.time(here), os.time(utc))
  local sign = offset < 0 and '-' or '+'
  offset = math.abs(offset)
  return string.format('%s%02d%02d', sign, math.floor(offset / 3600), math.floor(offset % 3600 / 60))
end

-- The time the message is mapped, as `format` says (YYYYMMDDHHMMSS by
-- default; YYYYMMDDHHMMSS+ZZZZ adds the local zone), moved by `shift`.
function hl7.now(format, shift)
  local t = shifted(shift)
  if format == 'YYYYMMDDHHMMSS+ZZZZ' then return os.date('%Y%m%d%H%M%S', t) .. zone(t) end
  return os.date(FORMATS[format] or FORMATS.YYYYMMDDHHMMSS, t)
end

-- A new message control ID: 20 random hex digits.
function hl7.control_id()
  return linkiir.sys.guid(128):sub(1, 20):upper()
end

-- A new random (version 4) UUID.
function hl7.uuid()
  local hex = linkiir.sys.guid(128):sub(1, 32):lower()
  local variant = string.format('%x', 8 + tonumber(hex:sub(17, 17), 16) % 4)
  return hex:sub(1, 8) .. '-' .. hex:sub(9, 12) .. '-4' .. hex:sub(14, 16) .. '-'
    .. variant .. hex:sub(18, 20) .. '-' .. hex:sub(21, 32)
end

return hl7
