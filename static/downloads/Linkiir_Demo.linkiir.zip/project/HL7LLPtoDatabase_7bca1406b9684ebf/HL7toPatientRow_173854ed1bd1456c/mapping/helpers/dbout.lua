-- Functions the data maps use to build database rows and put values in their columns' form.
-- Do not edit by hand: Data Map updates replace this file.
--
-- The rows are built on linkiir.store.tables trees of destination.json's tables,
-- so each value is checked against its column's type as it is set, and come
-- out as JSON, an object of rows by table:
--   {"patients":[{"id":"7","first_name":"Eve"}],"allergies":[{...},{...}]}
-- A column no rule fills is left out of its row; one set to NULL is null.
-- checksum: 62bd8626

local dbout = {}

local function warn(text)
  linkiir.log.warn('mapping: ' .. text)
end

-- SQL NULL, as a rule writes it.
dbout.NULL = linkiir.store.NULL

-- --- The output --------------------------------------------------------------------

-- The tables of each output, in the order they are written.
local ORDER = setmetatable({}, { __mode = 'k' })

local ESCAPES = {
  ['"'] = '\\"', ['\\'] = '\\\\', ['\b'] = '\\b', ['\f'] = '\\f', ['\n'] = '\\n', ['\r'] = '\\r', ['\t'] = '\\t',
}

local function json_string(s)
  return '"' .. s:gsub('[%c"\\]', function(c)
    return ESCAPES[c] or string.format('\\u%04x', c:byte())
  end) .. '"'
end

-- The output as JSON: each table's rows, each row's columns as they were set.
function dbout.json(out)
  local tables = {}
  for _, name in ipairs(ORDER[out] or {}) do
    local tbl, rows = out[name], {}
    for r = 1, #tbl do
      local row, cols = tbl[r], {}
      for c = 1, row:count() do
        local col = row:child(c)
        cols[#cols + 1] = json_string(col:nodeName()) .. ':' .. (col:isNull() and 'null' or json_string(col:value()))
      end
      rows[#rows + 1] = '{' .. table.concat(cols, ',') .. '}'
    end
    tables[#tables + 1] = json_string(name) .. ':[' .. table.concat(rows, ',') .. ']'
  end
  return '{' .. table.concat(tables, ',') .. '}'
end

local OUT = { __index = { S = function(self) return dbout.json(self) end } }

-- A new output of the tables `names` of `schema` (destination.json), none with
-- rows yet: out.patients is the patients table, out:S() the JSON.
function dbout.new(schema, names)
  local out = setmetatable({}, OUT)
  ORDER[out] = {}
  for _, name in ipairs(names) do
    out[name] = linkiir.store.tables{ schema = schema, name = name }
    table.insert(ORDER[out], name)
  end
  return out
end

-- A new row of table `name`, to fill: dbout.put(row, 'first_name', 'Eve').
function dbout.row(out, name)
  local tbl = out[name]
  tbl[#tbl + 1] = {}
  return tbl[#tbl]
end

-- Sets column `column` of `row` to `value` - checked against the column's
-- type - and says whether it did: nil leaves the column out.
function dbout.put(row, column, value)
  if value == nil then return false end
  if value ~= linkiir.store.NULL then value = tostring(value) end
  row[column] = value
  return true
end

-- Column `column` of the row this one is made under (`under`), as text: its
-- key, so this row can point to it - results.order_id from orders.id. nil
-- when the outer row has none (set its key first: from the input, a row
-- number or a new UUID).
function dbout.parent(outer, column)
  local v = outer and outer[column]
  if v == nil then return nil end
  if type(v) == 'userdata' then
    if v:isNull() then return nil end
    v = v:S()
  end
  v = tostring(v)
  return v ~= '' and v or nil
end

-- Rejects the message when a required rule wrote nothing (a 'Message
-- rejected:' error, which On Error can skip).
function dbout.required(wrote, from, to)
  if not wrote then error('Message rejected: ' .. from .. ' gave no value for ' .. to .. ', which requires one', 0) end
end

-- --- Values ----------------------------------------------------------------------
-- Each reads what the map's source gives - text, an HL7 v2 or X12
-- repetition (its first component), or a parsed element (its value) - and
-- gives the text a column takes.

-- The text of component i (1 by default) of what a rule's source gives:
-- text, a list of components (each text or a list of parts), or a part of
-- an HL7 v2 or X12 message (hl7.first, x12.first) - an HL7 repetition's
-- components, a component's subcomponents, an X12 element's components.
local function part(v, i)
  i = i or 1
  if type(v) ~= 'userdata' then
    local c = type(v) == 'table' and v[i] or (i == 1 and v or nil)
    if type(c) == 'table' then c = c[1] end
    return (c == nil or c == '""') and '' or tostring(c)
  end
  local c = v:count() == 0 and (i == 1 and v or nil) or v:child(i)
  while c and c:count() > 0 do c = c:child(1) end
  local s = c and c:value() or ''
  if v:protocol() == 101 then return (s == '' or s == '""') and '' or linkiir.data.unescape(s, c) end
  local seg = c and c:parent()
  while seg and seg:type() ~= 3 do seg = seg:parent() end   -- X12: ISA's elements are padded
  return (seg and seg:name() == 'ISA') and (s:gsub(' +$', '')) or s
end


-- A source value as text; nil for nothing.
local function text(v)
  local s
  local kind = type(v)
  if v == nil then
    return nil
  elseif kind == 'string' then
    s = v
  elseif kind == 'number' then
    s = (v == math.floor(v) and math.abs(v) < 2 ^ 53) and string.format('%d', v) or string.format('%.17g', v)
  elseif kind == 'boolean' then
    s = tostring(v)
  elseif kind == 'table' then
    s = part(v)
  elseif v:protocol() == 101 or v:protocol() == 102 then   -- HL7 v2 or X12
    s = part(v)
  else
    if v:count() > 0 then return warn('a value is read from an element of its own, and ' .. v:name() .. ' is a structure') end
    s = v:value()
  end
  if s == nil or s == '' or s == '""' then return nil end
  return tostring(s)
end
dbout.text = text

-- The value as it is.
function dbout.copy(v)
  return text(v)
end

-- The parts of a date or date and time, written with dashes or without:
-- 19800412, 20240115103000.5-0500, 1980-04-12, 2024-01-15T10:30:00Z.
local function parts(s)
  local y, mo, d, rest = s:match('^(%d%d%d%d)%-(%d%d)%-(%d%d)(.*)$')
  if not y then y, mo, d, rest = s:match('^(%d%d%d%d)(%d%d)(%d%d)(.*)$') end
  if not y then return nil end
  local t = { y = y, mo = mo, d = d }
  rest = rest:gsub('^[T ]', '')
  if rest == '' then return t end
  local hh, mi, ss, frac, zone = rest:match('^(%d%d):?(%d?%d?):?(%d?%d?)(%.?%d*)%s*(.*)$')
  if not hh then return nil end
  t.hh, t.mi, t.ss = hh, mi ~= '' and mi or '00', ss ~= '' and ss or '00'
  t.frac = frac ~= '.' and frac or ''
  if zone == 'Z' or zone == 'z' then
    t.zone = '+00:00'
  elseif zone ~= '' then
    local sign, zh, zm = zone:match('^([+-])(%d%d):?(%d%d)$')
    if not sign then return nil end
    t.zone = sign .. zh .. ':' .. zm
  end
  return t
end

-- A date or date and time -> a DATE (YYYY-MM-DD).
function dbout.date(v)
  local s = text(v)
  if not s then return nil end
  local t = parts(s)
  if not t then return warn('not a full date: ' .. s) end
  return t.y .. '-' .. t.mo .. '-' .. t.d
end

-- The local zone's offset from UTC now: +HH:MM.
local function local_zone(t)
  local here, utc = os.date('*t', t), os.date('!*t', t)
  utc.isdst = here.isdst
  local offset = os.difftime(os.time(here), os.time(utc))
  local sign = offset < 0 and '-' or '+'
  offset = math.abs(offset)
  return string.format('%s%02d:%02d', sign, math.floor(offset / 3600), math.floor(offset % 3600 / 60))
end

-- A date and time -> a TIMESTAMP (YYYY-MM-DD HH:MM:SS). With options.zone
-- (a column holding a zone) the zone goes with it - the value's, else
-- options.timezone, else the grid's own; without, the time is kept as
-- written and its zone dropped.
function dbout.datetime(v, options)
  options = options or {}
  local s = text(v)
  if not s then return nil end
  local t = parts(s)
  if not t then return warn('not a date and time: ' .. s) end
  local out = t.y .. '-' .. t.mo .. '-' .. t.d .. ' ' .. (t.hh or '00') .. ':' .. (t.mi or '00') .. ':'
    .. (t.ss or '00') .. (t.frac or '')
  if not options.zone then return out end
  local zone = t.zone or options.timezone
  if zone == nil or zone == '' then zone = local_zone(os.time()) end
  return out .. zone
end

-- A time, or a date and time's time -> HH:MM:SS.
function dbout.time(v)
  local s = text(v)
  if not s then return nil end
  local hh, mi, ss = s:match('^(%d%d):?(%d%d):?(%d?%d?)$')
  if not hh then
    local t = parts(s)
    if t and t.hh then hh, mi, ss = t.hh, t.mi, t.ss end
  end
  if not hh then return warn('not a time: ' .. s) end
  return hh .. ':' .. mi .. ':' .. (ss ~= '' and ss or '00')
end

-- Text that reads as a number.
function dbout.number(v)
  local s = text(v)
  if not s then return nil end
  s = s:match('^%s*(.-)%s*$')
  if not tonumber(s) then return warn('not a number: ' .. s) end
  return s
end

-- Y/N, T/F, 1/0, true/false -> true/false.
function dbout.boolean(v)
  local s = text(v)
  if not s then return nil end
  s = s:upper()
  if s == 'Y' or s == 'T' or s == 'TRUE' or s == '1' or s == 'YES' then return 'true' end
  if s == 'N' or s == 'F' or s == 'FALSE' or s == '0' or s == 'NO' then return 'false' end
  return warn('not a yes/no value: ' .. s)
end

-- A code through options.map (options.default when it has no entry).
function dbout.lookup(v, options)
  local s = text(v)
  if not s then return nil end
  local out = ((options or {}).map or {})[s]
  if out == nil then out = (options or {}).default end
  if out == nil then return warn('no lookup entry for ' .. s) end
  return out
end

-- How long each unit of a shift is ('-1d', '+2h', '+30min'); months and
-- years (mo, y) move the calendar instead, as their length varies.
local SHIFT_UNITS = { s = 1, min = 60, h = 3600, d = 86400, w = 604800 }

-- The time now, moved by `shift`: '-1d', '+2h', '+30min', '+1mo', '-1y'.
local function shifted(shift)
  local t = os.time()
  if shift == nil or shift == '' then return t end
  local sign, n, unit = tostring(shift):gsub('%s', ''):lower():match('^([+-]?)(%d+)(%a+)$')
  n = tonumber(n)
  if n and sign == '-' then n = -n end
  if n and (unit == 'mo' or unit == 'y') then
    local d = os.date('*t', t)
    if unit == 'y' then d.year = d.year + n else d.month = d.month + n end
    return os.time(d)
  end
  if not (n and SHIFT_UNITS[unit]) then
    error("can't shift the time by '" .. tostring(shift) .. "' - write it as -1d, +2h, +30min, +1mo or -1y", 0)
  end
  return t + n * SHIFT_UNITS[unit]
end

local NOW = { date = '%Y-%m-%d', time = '%H:%M:%S', timestamp = '%Y-%m-%d %H:%M:%S' }

-- The time the message is mapped, moved by options.shift: a TIMESTAMP
-- (2024-01-15 10:30:00), or as options.format says - a date, a time, or a
-- timestamp with its zone (timestamptz).
function dbout.now(options)
  options = options or {}
  local t = shifted(options.shift)
  if options.format == 'timestamptz' then return os.date(NOW.timestamp, t) .. local_zone(t) end
  return os.date(NOW[options.format] or NOW.timestamp, t)
end

-- A new random RFC 4122 (version 4) UUID.
function dbout.uuid()
  local hex = linkiir.sys.guid(128):sub(1, 32):lower()
  local variant = string.format('%x', 8 + tonumber(hex:sub(17, 17), 16) % 4)
  return hex:sub(1, 8) .. '-' .. hex:sub(9, 12) .. '-4' .. hex:sub(14, 16) .. '-'
    .. variant .. hex:sub(18, 20) .. '-' .. hex:sub(21, 32)
end

-- Runs a rule's own Lua, skipped when the source is empty. It gets the
-- source as the map reads it, then the message, its type and (for a row
-- made per item) that item, and returns the value.
function dbout.custom(fn, field, ...)
  if field == nil then return nil end
  return (fn(field, ...))
end

return dbout
