-- The code for the ADT to Patient row data map.
-- Do not edit by hand: the graphical map rewrites this file.
-- generated-from: mapping/maps/adt_patient.map.lua
-- part-of: mapping/datamap.lua
-- checksum: 13cb15e7
local hl7 = require 'mapping.helpers.hl7v2'
local dbout = require 'mapping.helpers.dbout'

local mapper = {}

local PATIENT_GENDER = { default = 'Unknown', map = { F = 'Female', M = 'Male' } }

function mapper.mapPatient(msgIn, row)
  local PID = hl7.first_segment(msgIn, 'PID') or {}
  local MSH = hl7.first_segment(msgIn, 'MSH') or {}
  dbout.required(dbout.put(row, 'Id', dbout.copy(hl7.first(PID[3], 1))), 'PID-3.1', 'Patient.Id')
  dbout.put(row, 'FirstName', dbout.copy(hl7.first(PID[5], 2)))
  dbout.put(row, 'LastName', dbout.copy(hl7.first(PID[5], 1)))
  dbout.put(row, 'BirthDate', dbout.date(hl7.first(PID[7])))
  dbout.put(row, 'Gender', dbout.lookup(hl7.first(PID[8]), PATIENT_GENDER))
  dbout.put(row, 'City', dbout.copy(hl7.first(PID[11], 3)))
  dbout.put(row, 'State', dbout.copy(hl7.first(PID[11], 4)))
  dbout.put(row, 'LastEvent', dbout.copy(hl7.first(MSH[9], 2)))
  dbout.put(row, 'UpdatedAt', dbout.now())
end

-- One message in, database rows out: one row of Patient.
-- They go on as JSON, an object of rows by table (msgOut:S()).
function mapper.map(msgIn, msgType)
  local msgOut = dbout.new('destination.json', { 'Patient' })
  mapper.mapPatient(msgIn, dbout.row(msgOut, 'Patient'))
  return msgOut
end

return mapper
