-- The rules for one data map.
-- Change it in the Map view or by hand: the Map view rewrites this file and drops comments inside the table.
return {
  message = 'Patient',
  rules = {
    { from = 'PID-3.1', to = 'Patient.Id', empty = 'reject' },
    { from = 'PID-5.2', to = 'Patient.FirstName' },
    { from = 'PID-5.1', to = 'Patient.LastName' },
    { from = 'PID-7', to = 'Patient.BirthDate', fn = 'date' },
    {
      from = 'PID-8',
      to = 'Patient.Gender',
      fn = 'lookup',
      options = { default = 'Unknown', map = { F = 'Female', M = 'Male' } },
    },
    { from = 'PID-11.3', to = 'Patient.City' },
    { from = 'PID-11.4', to = 'Patient.State' },
    { from = 'MSH-9.2', to = 'Patient.LastEvent' },
    { to = 'Patient.UpdatedAt', fn = 'now' },
  },
  tables = { { table = 'Patient' } },
}
