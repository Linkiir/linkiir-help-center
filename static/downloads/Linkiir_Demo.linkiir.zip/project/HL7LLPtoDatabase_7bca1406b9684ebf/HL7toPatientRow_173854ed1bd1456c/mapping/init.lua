-- Sends each message to the data map that handles it.
-- Do not edit by hand: the graphical map rewrites this file.
-- Your own code goes in premap.lua, postmap.lua and custom.lua.
-- generated-from: mapping/datamap.lua
-- checksum: 121c874e
local hl7 = require 'mapping.helpers.hl7v2'
local adtPatient = require 'mapping.maps.adt_patient'
require 'custom' -- the functions the maps call
require 'premap' -- PreMap
require 'postmap' -- PostMap

local mapper = {}

-- A message the node can't take fails as 'Message rejected: ...': one that
-- can't be read, that no data map takes, or that lacks a value a map
-- requires. Under On Error = Skip the message, main.lua skips these; any
-- other error, such as one in your own code, stops the node.
local function reject(text)
  error('Message rejected: ' .. text, 0)
end

-- A message that can't be read is rejected - unless the schema itself can't
-- be loaded, which is the node's problem, not the message's.
local function unreadable(err)
  err = tostring(err)
  if err:find("schema '", 1, true) or err:find(' schema;', 1, true) then error(err, 0) end
  reject(err)
end

-- A message read as source.json describes it, and its type.
function mapper.read(data)
  local ok, msgIn, msgType = pcall(linkiir.data.extract, { schema = 'source.json', data = data })
  if not ok then unreadable(msgIn) end
  return msgIn, msgType
end

-- The map for each message in source.json.
local maps = {
  ADT_A01 = adtPatient,
  ADT_A04 = adtPatient,
  ADT_A08 = adtPatient,
}

-- Whether a data map handles msgType.
function mapper.takes(msgType)
  return maps[msgType] ~= nil
end

-- One message in, whatever its map builds out (nil when it builds nothing),
-- between the user's PreMap and PostMap.
function mapper.map(msgIn, msgType)
  if msgType == 'unknown' then
    reject(hl7.messageType(msgIn) .. ' matches none of the messages in the source schema')
  end
  local map = maps[msgType]
  if not map then
    reject(msgType .. ' is in the source schema, but no data map takes it')
  end
  msgIn = PreMap(msgIn, msgType) or msgIn
  local msgOut = map.map(msgIn, msgType)
  return PostMap(msgOut, msgIn, msgType) or msgOut
end

return mapper
