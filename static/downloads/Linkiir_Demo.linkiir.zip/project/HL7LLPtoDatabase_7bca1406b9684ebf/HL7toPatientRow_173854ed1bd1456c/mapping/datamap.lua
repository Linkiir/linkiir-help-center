-- Lists this node's data maps and the formats it converts between.
-- Change it in the Map view or by hand: the Map view rewrites this file and drops comments inside the table.
return {
  format = 'linkiir.datamap/5',
  source = { type = 'hl7v2', version = '2.6', schema = 'source.json' },
  destination = { type = 'db', schema = 'destination.json' },
  maps = {
    {
      name = 'ADT to Patient row',
      file = 'mapping/maps/adt_patient.map.lua',
      messages = { 'ADT_A01', 'ADT_A04', 'ADT_A08' },
    },
  },
}
