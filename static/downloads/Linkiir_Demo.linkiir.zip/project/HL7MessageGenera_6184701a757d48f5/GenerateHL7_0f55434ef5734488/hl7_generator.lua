-- hl7_generator.lua: generates random HL7 ADT messages for the Linkiir Demo.
-- Used by the "HL7 Message Generator" workflow.

local gen = {}

-- Seed the PRNG per VM. Without this, LuaJIT's default seed makes every restart
-- of this node regenerate the identical "random" patients, so the destination
-- database stops growing and the demo looks stuck. linkiir.sys.guid() is random
-- per call, so its leading hex digits give a seed that differs on every start.
math.randomseed(tonumber(linkiir.sys.guid(128):sub(1, 8), 16))
math.random()  -- discard the first draw, which correlates with the seed

-- Data pools for realistic randomization
gen.LastNames    = {'Smith', 'Johnson', 'Williams', 'Brown', 'Davis', 'Miller', 'Wilson', 'Moore', 'Taylor', 'Anderson'}
gen.MaleNames    = {'James', 'Robert', 'John', 'Michael', 'David', 'William'}
gen.FemaleNames  = {'Mary', 'Patricia', 'Jennifer', 'Linda', 'Sarah', 'Elizabeth'}
gen.Race         = {'AI', 'EU', 'AA', 'AS', 'OT'}
gen.Street       = {'Oak Avenue', 'Main Street', 'Elm Drive', 'Cedar Lane', 'Park Road'}
gen.Relation     = {'Spouse', 'Parent', 'Sibling', 'Child', 'Guardian'}
gen.Event        = {'A01', 'A03', 'A04', 'A05', 'A06', 'A07', 'A08'}
gen.Facility     = {'Linkiir Health', 'Grid Medical', 'Metro Hospital'}
gen.Application  = {'LinkiirEMR', 'GridLab', 'MetroADT'}
gen.Locations    = {{'Chicago', 'IL'}, {'Toronto', 'ON'}, {'New York', 'NY'}, {'Austin', 'TX'}}

-- Utility: pick a random element from a table
function gen.choose(t)
   return t[math.random(#t)]
end

-- Utility: random number zero-padded to width
local function padRand(max, width)
   local r = tostring(math.random(1, max))
   while #r < width do r = '0' .. r end
   return r
end

-- Generate an HL7-style timestamp (YYYYMMDDHHmmss)
function gen.timestamp()
   local t = os.date('*t')
   return string.format('%04d%s%s%s%s%s',
      t.year, padRand(12, 2), padRand(28, 2),
      padRand(23, 2), padRand(59, 2), padRand(59, 2))
end

-- Generate a date of birth (19XX range)
function gen.birthDate()
   return '19' .. padRand(99, 2) .. padRand(12, 2) .. padRand(28, 2)
end

-- Generate a random account number
function gen.acctNo()
   return math.random(10, 99) .. '-' .. math.random(100, 999) .. '-' .. math.random(100, 999)
end

-- Generate a random SSN-like number
function gen.ssn()
   return padRand(999, 3) .. '-' .. padRand(999, 3) .. '-' .. padRand(9999, 4)
end

-- Pick random name and gender
function gen.nameAndGender()
   if math.random(2) == 1 then
      return gen.choose(gen.MaleNames), 'M'
   else
      return gen.choose(gen.FemaleNames), 'F'
   end
end

-- Fill MSH segment with random data
function gen.fillMSH(MSH)
   MSH[3][1] = gen.choose(gen.Application)
   MSH[4][1] = gen.choose(gen.Facility)
   MSH[5][1] = 'Linkiir Demo'
   MSH[6][1] = gen.choose(gen.Facility)
   MSH[7][1] = gen.timestamp()
   MSH[9] = 'ADT^' .. gen.choose(gen.Event)
   MSH[10] = linkiir.sys.guid(256)
   MSH[11][1] = 'P'
   MSH[12][1] = '2.6'
end

-- Fill EVN segment
function gen.fillEVN(EVN)
   EVN[2][1] = gen.timestamp()
   EVN[6][1] = gen.timestamp()
end

-- Fill PID segment with random patient data
-- Uses composite strings (^-delimited) to avoid sub-component assignment issues.
function gen.fillPID(PID)
   local firstName, gender = gen.nameAndGender()
   local lastName = gen.choose(gen.LastNames)
   local loc = gen.choose(gen.Locations)

   PID[3][1][1] = math.random(9999999)
   -- Name: XPN = LastName^FirstName (as composite string at component level)
   PID[5][1] = lastName .. '^' .. firstName
   PID[7][1] = gen.birthDate()
   PID[8] = gender
   PID[10][1][1] = gen.choose(gen.Race)
   -- Address: XAD = Street^^City^State^Zip (as composite string)
   PID[11][1] = math.random(100, 999) .. ' ' .. gen.choose(gen.Street)
      .. '^^' .. loc[1] .. '^' .. loc[2] .. '^' .. padRand(99999, 5)
   PID[18][1] = gen.acctNo()
   PID[19] = gen.ssn()
end

-- Fill PV1 segment
function gen.fillPV1(PV1)
   PV1[2] = 'I'
   -- Referring Doctor: XCN = ID^Last^First^Middle
   PV1[8][1] = '^' .. gen.choose(gen.LastNames) .. '^' .. gen.choose(gen.MaleNames) .. '^M'
   PV1[19][1] = math.random(9999999)
   PV1[44][1] = gen.timestamp()
end

-- Fill NK1 segment (next-of-kin)
function gen.fillNK1(NK1)
   NK1[1] = '1'
   NK1[2][1] = gen.choose(gen.LastNames) .. '^' .. gen.choose(gen.FemaleNames)
   NK1[3][1] = gen.choose(gen.Relation)
end

-- Add OBX observation (weight and height combined in one segment)
function gen.fillOBX(OBX)
   OBX[3] = 'WT^WEIGHT'
   OBX[5][1][1] = tostring(math.random(100) + 30)
   OBX[6][1] = 'pounds'
end

-- Generate a complete random ADT message and return it as a string
function gen.randomADT()
   local Out = linkiir.data.create{schema = 'adt_schema.json', name = 'ADT', type = 'hl7'}
   gen.fillMSH(Out.MSH)
   gen.fillEVN(Out.EVN)
   gen.fillPID(Out.PID)
   gen.fillPV1(Out.PV1)
   gen.fillNK1(Out.NK1)
   gen.fillOBX(Out.OBX)
   return Out:text()
end

return gen
