-- Generate HL7: makes one random ADT message each time the timer fires.

local People = {
   {'James', 'M'}, {'Robert', 'M'}, {'Michael', 'M'}, {'David', 'M'},
   {'Mary', 'F'}, {'Linda', 'F'}, {'Sarah', 'F'}, {'Emily', 'F'},
}
local LastNames = {'Smith', 'Johnson', 'Williams', 'Brown', 'Davis', 'Miller', 'Wilson', 'Taylor'}
local Cities    = {{'Chicago', 'IL'}, {'Austin', 'TX'}, {'Boston', 'MA'}, {'Denver', 'CO'}}
local Streets   = {'Oak Avenue', 'Main Street', 'Elm Drive', 'Cedar Lane'}

-- A01 admit, A04 register, A08 update. Step 3 saves these and skips A03.
local Events = {'A01', 'A04', 'A08', 'A03'}

-- A different seed on every start, so each run makes new patients.
math.randomseed(tonumber(linkiir.sys.guid(128):sub(1, 8), 16))

local function pick(list)
   return list[math.random(#list)]
end

function main()
   local person = pick(People)
   local city = pick(Cities)
   local now = os.date('%Y%m%d%H%M%S')

   local Msg = linkiir.data.create{schema = 'adt_schema.json', name = 'ADT', type = 'hl7'}

   Msg.MSH[3]  = 'Linkiir EMR'                  -- sending application
   Msg.MSH[4]  = 'Linkiir Health'               -- sending facility
   Msg.MSH[7]  = now
   Msg.MSH[9]  = 'ADT^' .. pick(Events)
   Msg.MSH[10] = linkiir.sys.guid(128)          -- message control id
   Msg.MSH[11] = 'P'
   Msg.MSH[12] = '2.6'

   Msg.EVN[2] = now

   Msg.PID[3][1][1] = math.random(100000, 999999)                -- patient id
   Msg.PID[5][1]    = pick(LastNames) .. '^' .. person[1]        -- last^first
   Msg.PID[7]       = string.format('19%02d%02d%02d',            -- birth date
                         math.random(40, 99), math.random(12), math.random(28))
   Msg.PID[8]       = person[2]                                  -- gender
   Msg.PID[11][1]   = math.random(100, 999) .. ' ' .. pick(Streets)
                      .. '^^' .. city[1] .. '^' .. city[2]       -- street^^city^state

   Msg.PV1[2] = 'I'                                              -- inpatient

   linkiir.flow.push{data = Msg:text()}
end
