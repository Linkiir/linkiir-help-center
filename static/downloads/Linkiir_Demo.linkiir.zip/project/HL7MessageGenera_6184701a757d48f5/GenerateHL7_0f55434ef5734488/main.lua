-- Generate HL7: creates a random ADT message on each timer interval
-- and pushes it to the file destination.

local gen = require 'hl7_generator'

function main()
   linkiir.flow.push{data = gen.randomADT()}
end
