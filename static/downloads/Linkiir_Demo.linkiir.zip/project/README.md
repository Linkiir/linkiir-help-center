# Linkiir Demo

Four small workflows that show HL7 message processing, database integration and
a web API using the native Linkiir scripting API. Everything runs locally - no
external systems are required.

## What the workflows demonstrate

**HL7 Message Generator** - a timer source builds a random HL7 ADT message every
10 seconds and a file destination writes it to `demo/messages/`. Start this one
first if you want traffic to look at.

**HL7 File to LLP** - a file source picks up HL7 files from `demo/messages/`, a
transform script maps the fields and stamps the sending application and
facility, and an LLP destination forwards the message to a remote host.

**HL7 LLP to Database** - an LLP source listens for inbound HL7, a transform
passes only ADT events, and a script extracts the patient demographics from the
PID segment and upserts them into a SQLite database at `demo/patient.db`.

**Patient Lookup API** - an HTTP endpoint that queries that same database.
Open it with no parameters for a usage page, or add `?LastName=Smith` to get
matching patient records back as JSON.

Together the last three form a round trip: the generator produces messages, the
file workflow sends them over LLP, the database workflow stores them, and the
API reads them back.

## What is created automatically on first run

- `demo/` - the demo data directory.
- `demo/patient.db` - the SQLite database, plus its `Patient` table.
- `demo/messages/` - the file exchange directory used as both the generator's
  output and the file workflow's input.

These paths are relative to the working directory of the Linkiir runtime
process. Nothing needs to be created by hand, and an empty `demo/messages/` is
not an error - the file source simply polls and finds nothing until messages
arrive.

## What you may want to change

**Sample messages (optional).** Three sample HL7 ADT messages ship with the
project, in the `sample_messages` folder inside the **Read HL7 Files** node
directory. Copy them into `demo/messages/` if you want the file workflow to have
something to process before you start the generator.

**LLP host and port.** The **Send LLP** node is configured to send to
`localhost:5145`, which is where the **Receive LLP** node listens - so out of the
box the two demo workflows talk to each other. Point **Send LLP** at your own
host and port to send elsewhere, and change **Receive LLP**'s listen port if
5145 is already in use on your grid.

**Route path.** The **Patient API** node answers on the `lookup` path. Change it
if that collides with another endpoint on your grid.

**Polling intervals.** Both the generator and the file source run every 10
seconds. Raise the interval if you want a quieter demo.
