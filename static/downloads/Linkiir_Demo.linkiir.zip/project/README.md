# Linkiir Demo

Four small workflows that pass HL7 messages from end to end: generate them,
send them over LLP, save the patients in a SQLite database with a Data Map and
a Database node, and read them back through a web API. Everything runs
locally - no external systems are required.

Start them all with **Start All**. They can start in any order.

## The workflows

**Step 1: HL7 Message Generator** - every 10 seconds a script makes a random
HL7 ADT message (an admit, registration, update or discharge), and a File node
writes it to `demo/messages/`.

**Step 2: HL7 File to LLP** - a File node picks up the files in
`demo/messages/`, a short script stamps the sending application and facility,
and an LLP node sends each message to Step 3.

**Step 3: HL7 LLP to Database** - an LLP node receives the messages, the
**HL7 to Patient Row** Data Map turns each one into a row for the `Patient`
table, and the **Save Patient** Database node upserts the row into
`demo/patient.db`. The map takes admits (A01), registrations (A04) and updates
(A08); it skips discharges (A03).

**Step 4: Patient Lookup API** - a web page and JSON API over the same
database. Open `lookup` for the search page, or add `?LastName=Smith` to get
matching patients back as JSON.

## What is created on first run

- `demo/messages/` - where Step 1 writes and Step 2 reads.
- `demo/patient.db` - the SQLite database and its `Patient` table. Step 3's Data
  Map node (`create_database.lua`) and Step 4 both create it if it is missing,
  so either can start first.

These paths are relative to the Linkiir runtime's working directory. Nothing
needs to be created by hand.

## What you may want to change

**LLP port.** **Send LLP** sends to `localhost:5145`, where **Receive LLP**
listens. Change both if 5145 is in use on your grid.

**Route path.** **Patient API** answers on `lookup`. Change it if that collides
with another endpoint on your grid.

**Intervals.** **Generate HL7** and **Read HL7 Files** both run every 10
seconds. Raise them for a quieter demo.

**Sample messages.** The **HL7 to Patient Row** node has three samples (admit,
update, discharge) to try the map with **Run Test**. The **Read HL7 Files**
node's `sample_messages` folder holds three more you can copy into
`demo/messages/`.
