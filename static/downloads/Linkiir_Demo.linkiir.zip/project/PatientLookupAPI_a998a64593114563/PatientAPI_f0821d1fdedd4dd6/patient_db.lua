-- patient_db.lua: Database connection and query functions for Patient records.

local M = {}

-- Ensure the demo data directory exists (SQLite cannot create parent dirs).
linkiir.sys.fs.mkdir('demo')

local DB = linkiir.store.open{driver = linkiir.store.SQLITE, name = 'demo/patient.db'}

DB:execute{sql = [[
   CREATE TABLE IF NOT EXISTS Patient (
      Id        TEXT PRIMARY KEY,
      FirstName TEXT,
      LastName  TEXT,
      Gender    TEXT
   )
]]}

function M.search(lastName)
   local results = {}
   local rows = DB:query{sql = 'SELECT * FROM Patient WHERE LastName = ' .. DB:quote(lastName)}
   for i = 1, #rows do
      results[#results + 1] = {
         Id        = rows[i].Id:nodeValue(),
         FirstName = rows[i].FirstName:nodeValue(),
         LastName  = rows[i].LastName:nodeValue(),
         Gender    = rows[i].Gender:nodeValue()
      }
   end
   return results
end

function M.all()
   local results = {}
   local rows = DB:query{sql = 'SELECT * FROM Patient ORDER BY LastName, FirstName LIMIT 100'}
   for i = 1, #rows do
      results[#results + 1] = {
         Id        = rows[i].Id:nodeValue(),
         FirstName = rows[i].FirstName:nodeValue(),
         LastName  = rows[i].LastName:nodeValue(),
         Gender    = rows[i].Gender:nodeValue()
      }
   end
   return results
end

function M.reset()
   DB:execute{sql = 'DELETE FROM Patient'}
   return true
end

return M
