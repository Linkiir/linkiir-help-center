-- patient_db.lua: reads the Patient table that Step 3 writes.

local M = {}

-- The same table Step 3 creates, made here too so this workflow can start first.
linkiir.sys.fs.mkdir('demo')

local DB = linkiir.store.open{driver = linkiir.store.SQLITE, name = 'demo/patient.db'}
DB:execute{sql = [[
   CREATE TABLE IF NOT EXISTS Patient (
      Id        TEXT NOT NULL PRIMARY KEY,
      FirstName TEXT,
      LastName  TEXT,
      BirthDate TEXT,
      Gender    TEXT,
      City      TEXT,
      State     TEXT,
      LastEvent TEXT,
      UpdatedAt TEXT
   )
]]}

local Columns = {'Id', 'FirstName', 'LastName', 'BirthDate', 'Gender', 'City', 'State', 'LastEvent', 'UpdatedAt'}

-- Turns query rows into plain Lua tables, ready to send as JSON.
local function toList(rows)
   local list = {}
   if not rows then return list end   -- query gives nil when nothing matches
   for i = 1, #rows do
      local patient = {}
      for _, column in ipairs(Columns) do
         patient[column] = rows[i][column]:value()
      end
      list[i] = patient
   end
   return list
end

function M.search(lastName)
   return toList(DB:query{sql = 'SELECT * FROM Patient WHERE LastName = ' .. DB:quote(lastName) .. ' ORDER BY FirstName'})
end

function M.all()
   return toList(DB:query{sql = 'SELECT * FROM Patient ORDER BY UpdatedAt DESC LIMIT 100'})
end

function M.reset()
   DB:execute{sql = 'DELETE FROM Patient'}
end

return M
