-- Patient Lookup API: a web page and a small JSON API over the patient
-- database that Step 3 fills.
--   lookup                  the search page
--   lookup?LastName=Smith   patients with that last name, as JSON
--   lookup?all=1            the 100 most recently updated patients, as JSON
--   lookup?reset=1          deletes every patient

local db   = require 'patient_db'
local page = require 'patient_page'

local function sendJson(value)
   linkiir.link.web.respond{body = linkiir.json.serialize(value), contentType = 'application/json'}
end

function main(Data)
   local params = linkiir.link.web.request{data = Data}.params or {}

   if params.LastName then
      sendJson(db.search(params.LastName))
   elseif params.all then
      sendJson(db.all())
   elseif params.reset then
      db.reset()
      sendJson({success = true})
   else
      linkiir.link.web.respond{body = page.html, contentType = 'text/html'}
   end
end
