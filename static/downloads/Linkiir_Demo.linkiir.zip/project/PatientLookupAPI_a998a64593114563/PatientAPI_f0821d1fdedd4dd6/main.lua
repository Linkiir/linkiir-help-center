-- Patient Lookup API
-- Interactive web page + JSON API for querying patient records.

local db   = require 'patient_db'
local page = require 'patient_page'

function main(Data)
   local req = linkiir.link.web.request{data = Data}

   -- JSON API: search by last name
   if req.params and req.params.LastName then
      linkiir.link.web.respond{
         body        = linkiir.json.serialize(db.search(req.params.LastName)),
         contentType = 'application/json'
      }
      return
   end

   -- JSON API: reset database (clear all patient records)
   if req.params and req.params.reset then
      db.reset()
      linkiir.link.web.respond{
         body        = linkiir.json.serialize({success = true, message = 'All patient records deleted'}),
         contentType = 'application/json'
      }
      return
   end

   -- JSON API: all patients
   if req.params and req.params.all then
      linkiir.link.web.respond{
         body        = linkiir.json.serialize(db.all()),
         contentType = 'application/json'
      }
      return
   end

   -- Serve the interactive page
   linkiir.link.web.respond{body = page.html, contentType = 'text/html'}
end
