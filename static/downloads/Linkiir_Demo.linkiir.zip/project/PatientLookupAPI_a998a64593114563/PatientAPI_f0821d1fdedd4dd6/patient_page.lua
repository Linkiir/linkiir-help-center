-- patient_page.lua: HTML page template for the Patient Lookup UI.
-- Supports dark/light mode toggle with localStorage persistence.

local M = {}

M.html = [[<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Patient Lookup | Linkiir Grid</title>
<style>
  :root, [data-theme="dark"] {
    --lk-bg: #0a0a0a;
    --lk-surface: #111;
    --lk-card: #1a1a1a;
    --lk-border: #2a2a2a;
    --lk-text: #e8e8e8;
    --lk-muted: #888;
    --lk-accent: #fff;
    --lk-blue: #4d9fff;
    --lk-green: #34d399;
    --lk-pink: #ec4899;
    --lk-radius: 8px;
    --lk-hover: rgba(77,159,255,0.04);
  }
  [data-theme="light"] {
    --lk-bg: #f8f9fb;
    --lk-surface: #fff;
    --lk-card: #fff;
    --lk-border: #e2e5ea;
    --lk-text: #1a1a2e;
    --lk-muted: #6b7280;
    --lk-accent: #111;
    --lk-blue: #2563eb;
    --lk-green: #059669;
    --lk-pink: #db2777;
    --lk-hover: rgba(37,99,235,0.03);
  }
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: -apple-system, BlinkMacSystemFont, 'Inter', 'Segoe UI', sans-serif;
    background: var(--lk-bg);
    color: var(--lk-text);
    line-height: 1.6;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    transition: background 0.3s, color 0.3s;
  }
  header {
    background: var(--lk-bg);
    border-bottom: 1px solid var(--lk-border);
    padding: 1rem 2rem;
    display: flex;
    align-items: center;
    gap: 1rem;
  }
  .logo { font-size: 1.1rem; font-weight: 700; letter-spacing: -0.02em; color: var(--lk-accent); }
  .logo span { color: var(--lk-muted); font-weight: 400; margin-left: 0.25rem; }
  header nav { margin-left: auto; display: flex; align-items: center; gap: 1.25rem; }
  header nav a { color: var(--lk-muted); text-decoration: none; font-size: 0.85rem; transition: color 0.2s; }
  header nav a:hover { color: var(--lk-accent); }
  .theme-toggle {
    background: var(--lk-card); border: 1px solid var(--lk-border); border-radius: 20px;
    padding: 0.3rem 0.6rem; cursor: pointer; font-size: 0.85rem; line-height: 1;
    transition: background 0.3s, border-color 0.3s;
  }
  .theme-toggle:hover { border-color: var(--lk-blue); }
  main { flex: 1; max-width: 900px; width: 100%; margin: 0 auto; padding: 2.5rem 2rem; }
  h1 { font-size: 1.75rem; font-weight: 700; letter-spacing: -0.03em; margin-bottom: 0.25rem; }
  .subtitle { color: var(--lk-muted); font-size: 0.9rem; margin-bottom: 2rem; }
  .search-bar { display: flex; gap: 0.5rem; margin-bottom: 1.5rem; flex-wrap: wrap; }
  .search-bar input {
    flex: 1; min-width: 200px; background: var(--lk-card); border: 1px solid var(--lk-border);
    border-radius: var(--lk-radius); padding: 0.7rem 1rem; color: var(--lk-text);
    font-size: 0.9rem; outline: none; transition: border-color 0.2s;
  }
  .search-bar input:focus { border-color: var(--lk-blue); }
  .search-bar input::placeholder { color: var(--lk-muted); }
  .search-bar button {
    background: var(--lk-blue); color: #fff; border: none; border-radius: var(--lk-radius);
    padding: 0.7rem 1.25rem; font-size: 0.85rem; font-weight: 600; cursor: pointer; transition: opacity 0.2s;
  }
  .search-bar button:hover { opacity: 0.85; }
  .btn-secondary { background: var(--lk-card) !important; color: var(--lk-text) !important; border: 1px solid var(--lk-border) !important; }
  .btn-danger { background: #dc2626 !important; color: #fff !important; border: none !important; }
  .btn-danger:hover { background: #b91c1c !important; }
  .warning-box {
    background: rgba(234,179,8,0.08); border: 1px solid rgba(234,179,8,0.3);
    border-radius: var(--lk-radius); padding: 0.75rem 1rem; margin-top: 1.5rem;
    font-size: 0.8rem; color: var(--lk-muted);
  }
  .warning-box strong { color: #eab308; }
  .table-wrap { background: var(--lk-card); border: 1px solid var(--lk-border); border-radius: var(--lk-radius); overflow: hidden; }
  table { width: 100%; border-collapse: collapse; }
  thead { background: var(--lk-surface); }
  th { text-align: left; padding: 0.75rem 1rem; font-size: 0.75rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; color: var(--lk-muted); border-bottom: 1px solid var(--lk-border); }
  td { padding: 0.7rem 1rem; font-size: 0.875rem; border-bottom: 1px solid var(--lk-border); }
  tr:last-child td { border-bottom: none; }
  tr:hover td { background: var(--lk-hover); }
  .badge { display: inline-block; padding: 0.15rem 0.5rem; border-radius: 4px; font-size: 0.7rem; font-weight: 600; text-transform: uppercase; }
  .badge-m { background: rgba(77,159,255,0.15); color: var(--lk-blue); }
  .badge-f { background: rgba(236,72,153,0.15); color: var(--lk-pink); }
  .badge-o { background: rgba(52,211,153,0.15); color: var(--lk-green); }
  .status { text-align: center; padding: 2rem; color: var(--lk-muted); font-size: 0.85rem; }
  .count { color: var(--lk-muted); font-size: 0.8rem; margin-top: 0.75rem; }
  footer { border-top: 1px solid var(--lk-border); padding: 1.5rem 2rem; text-align: center; color: var(--lk-muted); font-size: 0.75rem; }
  footer a { color: var(--lk-muted); text-decoration: none; }
  footer a:hover { color: var(--lk-accent); }
</style>
</head>
<body>
<header>
  <div class="logo">linkiir<span>grid</span></div>
  <nav>
    <a href="?all=1">All Patients</a>
    <a href="https://linkiir.com" target="_blank">linkiir.com</a>
    <button class="theme-toggle" id="themeBtn" title="Toggle dark/light mode" aria-label="Toggle theme">&#9790;</button>
  </nav>
</header>
<main>
  <h1>Patient Lookup</h1>
  <p class="subtitle">Search the patient database by last name. Data is populated by the HL7 Message Generator workflow.</p>
  <div class="search-bar">
    <input type="text" id="search" placeholder="Enter last name (e.g. Smith, Brown, Williams)" autofocus>
    <button onclick="searchPatients()">Search</button>
    <button class="btn-secondary" onclick="loadAll()">Show All</button>
    <button class="btn-danger" onclick="resetDB()">Reset DB</button>
  </div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Patient ID</th><th>First Name</th><th>Last Name</th><th>Gender</th></tr></thead>
      <tbody id="results">
        <tr><td colspan="4" class="status">Type a last name and click Search, or click Show All.</td></tr>
      </tbody>
    </table>
  </div>
  <p class="count" id="count"></p>
  <div class="warning-box">
    <strong>&#9888; Reset DB:</strong> Deletes all patient records. Stop the <em>HL7 LLP to Database</em> workflow first to avoid SQLite locking. Use with caution &mdash; this clears all demo data. Restart the <em>HL7 Message Generator</em> to repopulate.
  </div>
</main>
<footer>
  <a href="https://linkiir.com">&copy; 2026 Linkiir</a> &middot; Patient Lookup API Demo &middot; Powered by Linkiir Grid
</footer>
<script>
(function(){
  var tbody=document.getElementById('results'),countEl=document.getElementById('count'),
      input=document.getElementById('search'),themeBtn=document.getElementById('themeBtn'),
      html=document.documentElement;

  // Theme toggle
  var saved=localStorage.getItem('lk-theme');
  if(saved)html.setAttribute('data-theme',saved);
  updateIcon();
  themeBtn.addEventListener('click',function(){
    var next=html.getAttribute('data-theme')==='dark'?'light':'dark';
    html.setAttribute('data-theme',next);
    localStorage.setItem('lk-theme',next);
    updateIcon();
  });
  function updateIcon(){themeBtn.textContent=html.getAttribute('data-theme')==='dark'?'\u263D':'\u2600';}

  // Search
  input.addEventListener('keydown',function(e){if(e.key==='Enter')searchPatients()});
  window.searchPatients=function(){
    var n=input.value.trim();if(!n)return;
    tbody.innerHTML='<tr><td colspan="4" class="status">Searching...</td></tr>';
    fetch('?LastName='+encodeURIComponent(n)).then(function(r){return r.json()}).then(renderTable)
      .catch(function(){tbody.innerHTML='<tr><td colspan="4" class="status">Error.</td></tr>'});
  };
  window.loadAll=function(){
    tbody.innerHTML='<tr><td colspan="4" class="status">Loading...</td></tr>';
    fetch('?all=1').then(function(r){return r.json()}).then(renderTable)
      .catch(function(){tbody.innerHTML='<tr><td colspan="4" class="status">Error.</td></tr>'});
  };
  function esc(s){var d=document.createElement('div');d.textContent=s||'';return d.innerHTML}
  function renderTable(patients){
    if(!patients||patients.length===0){tbody.innerHTML='<tr><td colspan="4" class="status">No patients found.</td></tr>';countEl.textContent='';return}
    tbody.innerHTML=patients.map(function(p){
      var badge=p.Gender==='M'?'badge-m':p.Gender==='F'?'badge-f':'badge-o';
      var label=p.Gender==='M'?'Male':p.Gender==='F'?'Female':p.Gender||'\u2014';
      return '<tr><td>'+esc(p.Id)+'</td><td>'+esc(p.FirstName)+'</td><td>'+esc(p.LastName)+'</td><td><span class="badge '+badge+'">'+label+'</span></td></tr>';
    }).join('');
    countEl.textContent=patients.length+' patient'+(patients.length!==1?'s':'')+' found';
  }
  window.resetDB=function(){
    if(!confirm('Delete ALL patient records?\n\nMake sure "HL7 LLP to Database" workflow is stopped to avoid SQLite locking.'))return;
    tbody.innerHTML='<tr><td colspan="4" class="status">Resetting...</td></tr>';
    fetch('?reset=1').then(function(r){return r.json()}).then(function(d){
      if(d.success){countEl.textContent='Database cleared';tbody.innerHTML='<tr><td colspan="4" class="status">All records deleted. Start the HL7 Message Generator to repopulate.</td></tr>'}
      else{tbody.innerHTML='<tr><td colspan="4" class="status">Reset failed.</td></tr>'}
    }).catch(function(){tbody.innerHTML='<tr><td colspan="4" class="status">Error resetting database.</td></tr>'});
  };
  loadAll();
})();
</script>
</body>
</html>]]

return M
