-- Map HL7: parse incoming HL7, copy all fields, stamp sending application,
-- and push the result downstream to the LLP destination.

function main(Data)
   local Msg, MsgType = linkiir.data.extract{
      schema = 'adt_schema.json', data = Data, type = 'hl7'
   }

   local Out = linkiir.data.create{
      schema = 'adt_schema.json', name = MsgType, type = 'hl7'
   }
   Out:map(Msg)

   Out.MSH[3][1] = 'Linkiir Grid'
   Out.MSH[4][1] = 'Demo Facility'

   linkiir.flow.push{data = Out:text()}
end
