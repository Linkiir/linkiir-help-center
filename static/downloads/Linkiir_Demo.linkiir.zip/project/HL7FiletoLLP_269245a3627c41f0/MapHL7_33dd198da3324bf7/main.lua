-- Stamp Sender: marks each message as sent by the Linkiir Grid before it
-- goes out over LLP.

function main(Data)
   local Msg = linkiir.data.extract{schema = 'adt_schema.json', data = Data, type = 'hl7'}

   Msg.MSH[3] = 'Linkiir Grid'    -- sending application
   Msg.MSH[4] = 'Demo Facility'   -- sending facility

   linkiir.flow.push{data = Msg:text()}
end
