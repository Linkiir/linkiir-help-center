-- FHIR Profiling Tools
-- Source HTTP node serving a browser UI for FHIR resource template generation
-- and profile authoring, across the FHIR versions the node ships.

-- Grid v1.0.0 require statement
local FhirProfiling = require ('fhir_profiling'..package.config:sub(1,1)..'fhir_profiling')

local Portal = FhirProfiling.portalFromNodeConfig()
if not Portal then
   linkiir.log.error('Failed to initialise FHIR profiling portal; check Specifications Path')
end

function main(Data)
   linkiir.log.debug(Data)

   if not Portal then
      linkiir.link.web.respond{
         body        = '{"error":"FHIR profiling client not initialised"}',
         contentType = 'application/json',
         code        = 500,
      }
      return
   end

   Portal:handleRequest(Data)
end