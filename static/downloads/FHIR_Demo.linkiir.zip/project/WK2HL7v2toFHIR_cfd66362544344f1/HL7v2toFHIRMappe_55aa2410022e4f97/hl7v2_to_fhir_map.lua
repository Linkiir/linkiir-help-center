-- ===========================================================================
-- hl7v2_to_fhir_map - HL7 v2.5.1 ADT -> FHIR R4 Patient mapping
--
-- This is the MAPPING MODULE. It holds only the field-by-field translation
-- from an HL7 v2 ADT message to a FHIR Patient resource, so the mapping can be
-- reviewed and changed on its own, without touching the node's glue (main.lua).
--
-- IT IS SCHEMA-DRIVEN. The message is parsed by linkiir.data.extract against
-- hl7v251_adt_a01.json - the HL7 v2.5.1 ADT^A01 grammar sitting beside this
-- script - so the parse tree carries the real HL7 names, and the map below is
-- written in those names:
--
--    at(Msg, 'PID', 'Patient Address', 1, 'City')   not   split(PID[12], '^')[3]
--
-- The schema supplies two things this mapping relies on:
--
--   1. STRUCTURE - which field is which, how a composite splits into named
--      components, and which fields repeat. Repeats, components and
--      sub-components are separated by the delimiters the message's own MSH
--      declares, not by hard-coded '^' and '~'.
--   2. VOCABULARY - the HL7 code tables the fields are bound to (0001
--      Administrative Sex, 0190 Address Type, 0200 Name Type, 0201
--      Telecommunication Use, 0203 Identifier Type). A coded value is looked
--      up in the schema's own copy of its table, so a code HL7 does not define
--      is REPORTED rather than quietly mapped to a default.
--
-- What is left in Lua is only what a schema cannot know: the HL7 -> FHIR
-- semantic maps (Vocabulary, below) and the shape of the FHIR resource.
--
-- To change what maps where, edit Source / Vocabulary / toPatient() below. To
-- change how the message flows through the node (logging, forwarding), edit
-- main.lua instead.
-- ===========================================================================

local M = {}

-- The HL7 grammar this mapping is written against. It lives in the node
-- directory; linkiir.data resolves a relative schema path from there.
M.Schema = 'hl7v251_adt_a01.json'

-- Base for identifier.system when the assigning authority is a plain HL7
-- namespace rather than an ISO OID. Point this at the issuing system's real
-- namespace URI in a production interface.
M.IdentifierSystemBase = 'http://hospital.example.org/'

-- The namespace for PID-19. A social security number is jurisdictional and the
-- field carries no assigning authority of its own, so the namespace has to be
-- stated here; this is the US one.
M.SsnSystem = 'http://hl7.org/fhir/sid/us-ssn'

-- ---------------------------------------------------------------------------
-- The HL7 side of the map, written entirely in schema names.
--
-- Every name here is checked against the schema on the first message (see
-- checkSourceNames), so a name that HL7 v2.5.1 does not define fails loudly
-- instead of silently mapping nothing.
-- ---------------------------------------------------------------------------
local Source = {
   Segment = 'PID',

   Field = {
      IdentifierList = 'Patient Identifier List',   -- PID-3
      Name           = 'Patient Name',              -- PID-5
      BirthDateTime  = 'Date/Time of Birth',        -- PID-7
      Sex            = 'Administrative Sex',        -- PID-8
      Address        = 'Patient Address',           -- PID-11
      HomePhone      = 'Phone Number - Home',       -- PID-13
      WorkPhone      = 'Phone Number - Business',   -- PID-14
      AccountNumber  = 'Patient Account Number',    -- PID-18
      SSN            = 'SSN Number - Patient',      -- PID-19
   },

   -- Components of the composite data types those fields carry. CX-4, XPN-1
   -- and XAD-1 are composite in turn (HD, FN and SAD), and their
   -- sub-components are named here too - read whole they would come back
   -- '&'-joined, a surname arriving as 'O'BRIEN&VAN'.
   CX  = { Id = 'ID Number', Authority = 'Assigning Authority', Type = 'Identifier Type Code' },
   HD  = { Namespace = 'Namespace ID', UniversalId = 'Universal ID', UniversalIdType = 'Universal ID Type' },
   XPN = { Family = 'Family Name', Given = 'Given Name', Middle = 'Second and Further Given Names or Initials Thereof',
           Suffix = 'Suffix', Prefix = 'Prefix', Type = 'Name Type Code' },
   FN  = { Surname = 'Surname' },
   XAD = { Street = 'Street Address', Other = 'Other Designation', City = 'City',
           State = 'State or Province', Zip = 'Zip or Postal Code', Country = 'Country', Type = 'Address Type' },
   SAD = { Street = 'Street or Mailing Address' },
   XTN = { Number = 'Telephone Number', Use = 'Telecommunication Use Code',
           Equipment = 'Telecommunication Equipment Type', Email = 'Email Address' },
   TS  = { Time = 'Time' },

   -- The HL7 code tables the fields above are bound to, by table id.
   Table = {
      Sex            = '0001',   -- PID-8
      AddressType    = '0190',   -- XAD-7
      NameType       = '0200',   -- XPN-7
      TelecomUse     = '0201',   -- XTN-2
      Equipment      = '0202',   -- XTN-3
      IdentifierType = '0203',   -- CX-5
   },
}

-- ---------------------------------------------------------------------------
-- The FHIR side of the map: HL7 code -> FHIR code. Only codes HL7 defines in
-- the tables above can reach these; anything else is reported as a warning.
-- ---------------------------------------------------------------------------
local Vocabulary = {
   -- HL7 0001 -> FHIR administrative-gender.
   Gender = { F = 'female', M = 'male', O = 'other', A = 'other', N = 'other', U = 'unknown' },

   -- HL7 0200 -> FHIR name-use. Codes with no faithful FHIR equivalent are
   -- left out, which omits name.use rather than inventing one.
   NameUse = { L = 'official', C = 'official', I = 'official', D = 'usual',
               M = 'maiden', N = 'nickname', T = 'nickname', S = 'anonymous', B = 'old', P = 'old' },

   -- HL7 0190 -> FHIR address-use / address-type.
   AddressUse  = { H = 'home', P = 'home', L = 'home', BR = 'old', N = 'old', BA = 'old',
                   O = 'work', B = 'work', C = 'temp', M = 'home' },
   AddressType = { M = 'postal' },   -- everything else is a physical address too

   -- HL7 0201 -> FHIR contact-point-use. Two 0201 codes say what the contact
   -- point IS rather than where it is reached, and FHIR records that as the
   -- system; they are listed in TelecomSystemFromUse instead of here.
   TelecomUse = { PRN = 'home', ORN = 'home', WPN = 'work', VHN = 'temp' },
   TelecomSystemFromUse = { NET = 'email', BPN = 'pager' },

   -- HL7 0202 -> FHIR contact-point-system. A cell phone is a 'phone' in FHIR
   -- and its being mobile is a use, so CP appears in both maps.
   TelecomSystem = { PH = 'phone', CP = 'phone', MD = 'phone', SAT = 'phone',
                     FX = 'fax', BP = 'pager', Internet = 'email', ['X.400'] = 'email' },
   TelecomMobile = { CP = true },
}

-- The FHIR code system for HL7 v2 table 0203, used for identifier.type.
local IDENTIFIER_TYPE_SYSTEM = 'http://terminology.hl7.org/CodeSystem/v2-0203'

-- ---------------------------------------------------------------------------
-- Reading the parse tree
-- ---------------------------------------------------------------------------

-- Walk the message by schema name. A string step is a segment, field or
-- component name; a number step is a repeat or a position. Returns nil as soon
-- as a step is absent FROM THE MESSAGE, which is not an error - an HL7 sender
-- simply stops writing fields once it has nothing left to say.
local function at(Node, ...)
   for I = 1, select('#', ...) do
      if not Node then return nil end
      Node = Node:child((select(I, ...)))
   end
   return Node
end

-- The text of a node, trimmed, or nil when it is absent or blank - so an unset
-- HL7 field is omitted from the resource rather than written as "".
local function textOf(Node)
   if not Node then return nil end
   local Text = Node:text()
   if type(Text) ~= 'string' then return nil end
   Text = Text:match('^%s*(.-)%s*$')
   if Text == '' then return nil end
   return Text
end

-- Shorthand: the text at a schema path.
local function valueAt(Node, ...)
   return textOf(at(Node, ...))
end

-- Every populated repeat of a field, as a list of nodes. The schema says which
-- fields may repeat; the parser gives one child per repeat either way, so a
-- single-valued field yields a one-element list and an empty field an empty one.
local function repeatsOf(Field)
   local Out = {}
   if not Field then return Out end
   for I = 1, Field:count() do
      local Rep = Field:child(I)
      if textOf(Rep) then Out[#Out + 1] = Rep end
   end
   return Out
end

-- ---------------------------------------------------------------------------
-- Coded values, resolved against the schema's own code tables
-- ---------------------------------------------------------------------------

local CodeSets = {}

-- The schema's copy of an HL7 code table, or nil when the schema carries no
-- codes for it. Cached: the grammar itself is cached by the runtime, but this
-- saves a lookup per coded field per message.
local function codeSet(TableId)
   local Found = CodeSets[TableId]
   if Found == nil then
      Found = linkiir.data.codeset.get{ schema = M.Schema, table = TableId } or false
      CodeSets[TableId] = Found
   end
   return Found or nil
end

-- Translate one HL7 coded value to its FHIR equivalent.
--
-- Three outcomes, and they are deliberately distinct:
--   * the field is empty  ->  nil, and no warning: nothing was sent.
--   * the code is not in HL7's own table  ->  nil + a warning: the sender is
--     using a code HL7 v2.5.1 does not define.
--   * the code is valid but this map has no FHIR equivalent  ->  nil + a
--     warning naming what HL7 means by it, taken from the schema.
local function translate(Warnings, Code, TableId, Map, Label)
   if not Code then return nil end
   local Set = codeSet(TableId)
   local Desc = Set and Set:desc(Code)
   if not Desc then
      Warnings[#Warnings + 1] = string.format(
         "%s: '%s' is not a code in HL7 table %s", Label, Code, TableId)
      return nil
   end
   local Mapped = Map[Code]
   if not Mapped then
      Warnings[#Warnings + 1] = string.format(
         "%s: HL7 code '%s' (%s) has no FHIR equivalent in this mapping", Label, Code, Desc)
      return nil
   end
   return Mapped, Desc
end

-- ---------------------------------------------------------------------------
-- Checking the map against the schema
-- ---------------------------------------------------------------------------

-- Which composite data type each mapped field is declared to carry. The check
-- below asserts this, so a field whose type changes between HL7 versions is
-- caught here rather than producing an empty component read at run time.
local CarriedType = {
   IdentifierList = 'CX',
   Name           = 'XPN',
   BirthDateTime  = 'TS',
   Address        = 'XAD',
   HomePhone      = 'XTN',
   WorkPhone      = 'XTN',
   AccountNumber  = 'CX',
   -- PID-8 (Sex) and PID-19 (SSN) carry primitives - IS and ST - and are read
   -- whole, so there is no composite to assert for them.
}

local NamesChecked = false

-- Verify, once, that everything Source names really exists in the schema.
--
-- The grammar is read as JSON and the declarations are checked directly: every
-- field name against the PID segment definition, every component name against
-- the composite its field is declared to carry, every table id against the
-- schema's code tables. Without this a misspelt name would simply read nil and
-- the value would vanish from the resource with nothing said about it.
local function checkSourceNames()
   if NamesChecked then return end

   local Sep = package.config:sub(1, 1)
   local Dir = linkiir.sys.nodeDir()
   if Dir:sub(-1) ~= Sep then Dir = Dir .. Sep end

   local File = assert(io.open(Dir .. M.Schema, 'r'),
      'hl7v2_to_fhir_map: cannot open schema ' .. M.Schema)
   local Text = File:read('*a')
   File:close()

   local Grammar = linkiir.json.parse(Text)
   if type(Grammar) ~= 'table' then
      error('hl7v2_to_fhir_map: schema ' .. M.Schema .. ' is not valid JSON')
   end

   local function fail(Fmt, ...)
      error(string.format('hl7v2_to_fhir_map: ' .. Fmt, ...), 0)
   end

   -- The PID definition, found by name: the grammar keys segments by id.
   local Segment
   for _, Def in pairs(Grammar.segments or {}) do
      if Def.name == Source.Segment then
         Segment = Def
         break
      end
   end
   if not Segment then
      fail("schema '%s' defines no %s segment", M.Schema, Source.Segment)
   end

   local FieldType = {}
   for _, Field in ipairs(Segment.fields or {}) do FieldType[Field.name] = Field.type end

   for Key, FieldName in pairs(Source.Field) do
      local Type = FieldType[FieldName]
      if not Type then
         fail("%s has no field named '%s' in schema '%s' (Source.Field.%s)",
            Source.Segment, FieldName, M.Schema, Key)
      end
      if CarriedType[Key] and Type ~= CarriedType[Key] then
         fail("%s '%s' carries %s in schema '%s', but this mapping reads it as %s (Source.Field.%s)",
            Source.Segment, FieldName, Type, M.Schema, CarriedType[Key], Key)
      end
   end

   -- Component names, against the composite each one belongs to. HD is reached
   -- through CX's assigning authority, the only place this mapping reads it.
   local function componentNames(TypeName)
      local Def = (Grammar.composites or {})[TypeName]
      local Names = {}
      for _, Component in ipairs(Def and Def.components or {}) do Names[Component.name] = true end
      return Names
   end

   for _, TypeName in ipairs({ 'CX', 'HD', 'XPN', 'FN', 'XAD', 'SAD', 'XTN', 'TS' }) do
      local Names = componentNames(TypeName)
      if not next(Names) then
         fail("schema '%s' defines no components for data type %s", M.Schema, TypeName)
      end
      for Key, CompName in pairs(Source[TypeName]) do
         if not Names[CompName] then
            fail("%s has no component named '%s' in schema '%s' (Source.%s.%s)",
               TypeName, CompName, M.Schema, TypeName, Key)
         end
      end
   end

   for Key, TableId in pairs(Source.Table) do
      if not codeSet(TableId) then
         fail("schema '%s' carries no HL7 table %s (Source.Table.%s)", M.Schema, TableId, Key)
      end
   end

   NamesChecked = true
end

-- ---------------------------------------------------------------------------
-- Builders: one HL7 composite -> one FHIR element
-- ---------------------------------------------------------------------------

-- identifier.system for a CX. An assigning authority that carries an ISO OID
-- becomes a urn:oid: URI; a plain HL7 namespace is appended to
-- M.IdentifierSystemBase, because FHIR requires an absolute URI here and a
-- bare namespace like 'LINKIIR' is not one.
local function identifierSystem(Authority)
   local UniversalId   = valueAt(Authority, Source.HD.UniversalId)
   local UniversalType = valueAt(Authority, Source.HD.UniversalIdType)
   if UniversalId and UniversalType == 'ISO' then
      return 'urn:oid:' .. UniversalId
   end
   local Namespace = valueAt(Authority, Source.HD.Namespace)
   if Namespace then
      return M.IdentifierSystemBase .. Namespace:lower():gsub('%s+', '-')
   end
   return nil
end

-- An HL7 table 0203 code -> FHIR Identifier.type. HL7 table 0203 and the FHIR
-- v2-0203 code system share both their codes and their display strings, so the
-- schema's own description IS the FHIR display: this file keeps no second copy
-- of that vocabulary.
local function identifierType(Warnings, Code, Label)
   if not Code then return nil end
   local Set = codeSet(Source.Table.IdentifierType)
   local Desc = Set and Set:desc(Code)
   if not Desc then
      Warnings[#Warnings + 1] = string.format(
         "%s: '%s' is not a code in HL7 table %s", Label, Code, Source.Table.IdentifierType)
      return nil
   end
   return { coding = { { system = IDENTIFIER_TYPE_SYSTEM, code = Code, display = Desc } } }
end

-- One CX repeat -> one FHIR Identifier. TypeCode overrides CX-5 for a field
-- whose identifier type HL7 states positionally (PID-18 is an account number).
local function identifierFrom(Warnings, Cx, TypeCode, Label)
   local Value = valueAt(Cx, Source.CX.Id)
   if not Value then return nil end

   local Identifier = { value = Value }
   local System = identifierSystem(at(Cx, Source.CX.Authority))
   if System then Identifier.system = System end
   Identifier.type = identifierType(Warnings, TypeCode or valueAt(Cx, Source.CX.Type), Label)
   return Identifier
end

-- One XPN repeat -> one FHIR HumanName.
local function nameFrom(Warnings, Xpn, IsFirst)
   -- XPN-1 is an FN: its first sub-component is the surname proper.
   local Family = valueAt(Xpn, Source.XPN.Family, Source.FN.Surname)
      or valueAt(Xpn, Source.XPN.Family)
   local Given  = valueAt(Xpn, Source.XPN.Given)
   local Middle = valueAt(Xpn, Source.XPN.Middle)
   local Prefix = valueAt(Xpn, Source.XPN.Prefix)
   local Suffix = valueAt(Xpn, Source.XPN.Suffix)
   if not (Family or Given) then return nil end

   local Name = {}
   local Use = translate(Warnings, valueAt(Xpn, Source.XPN.Type), Source.Table.NameType,
      Vocabulary.NameUse, 'PID Patient Name (XPN-7)')
   -- An uncoded PID-5 is the patient's legal name, which is what the first
   -- repeat means in practice; later repeats stay unqualified.
   Name.use = Use or (IsFirst and 'official') or nil

   if Family then Name.family = Family end
   if Given or Middle then
      Name.given = {}
      if Given then Name.given[#Name.given + 1] = Given end
      if Middle then Name.given[#Name.given + 1] = Middle end
   end
   if Prefix then Name.prefix = { Prefix } end
   if Suffix then Name.suffix = { Suffix } end
   return Name
end

-- One XAD repeat -> one FHIR Address.
local function addressFrom(Warnings, Xad)
   -- XAD-1 is an SAD: its first sub-component is the street address line.
   local Street  = valueAt(Xad, Source.XAD.Street, Source.SAD.Street)
      or valueAt(Xad, Source.XAD.Street)
   local Other   = valueAt(Xad, Source.XAD.Other)
   local City    = valueAt(Xad, Source.XAD.City)
   local State   = valueAt(Xad, Source.XAD.State)
   local Zip     = valueAt(Xad, Source.XAD.Zip)
   local Country = valueAt(Xad, Source.XAD.Country)
   if not (Street or Other or City or State or Zip or Country) then return nil end

   local TypeCode = valueAt(Xad, Source.XAD.Type)
   local Address = {
      use  = translate(Warnings, TypeCode, Source.Table.AddressType,
                Vocabulary.AddressUse, 'PID Patient Address (XAD-7)') or 'home',
      type = (TypeCode and Vocabulary.AddressType[TypeCode]) or 'both',
   }
   if Street or Other then
      Address.line = {}
      if Street then Address.line[#Address.line + 1] = Street end
      if Other then Address.line[#Address.line + 1] = Other end
   end
   if City then Address.city = City end
   if State then Address.state = State end
   if Zip then Address.postalCode = Zip end
   if Country then Address.country = Country end
   return Address
end

-- One XTN repeat -> one FHIR ContactPoint. DefaultUse is the use HL7 states
-- positionally (PID-13 is the home number, PID-14 the business one) and
-- applies when XTN-2 does not say otherwise.
local function telecomFrom(Warnings, Xtn, DefaultUse, Label)
   local Email     = valueAt(Xtn, Source.XTN.Email)
   local Number    = valueAt(Xtn, Source.XTN.Number)
   local Equipment = valueAt(Xtn, Source.XTN.Equipment)

   local UseCode = valueAt(Xtn, Source.XTN.Use)
   local System = Equipment and translate(Warnings, Equipment, Source.Table.Equipment,
      Vocabulary.TelecomSystem, Label .. ' (XTN-3)')
   System = System or (UseCode and Vocabulary.TelecomSystemFromUse[UseCode])

   local Value = (System == 'email' and (Email or Number)) or Number or Email
   if not Value then return nil end
   if not System then System = Email and 'email' or 'phone' end

   -- A use code that only named the system has already been honoured above, so
   -- it is not put through the use map - it would warn about a code that did map.
   local Use = DefaultUse
   if UseCode and not Vocabulary.TelecomSystemFromUse[UseCode] then
      Use = translate(Warnings, UseCode, Source.Table.TelecomUse,
         Vocabulary.TelecomUse, Label .. ' (XTN-2)') or DefaultUse
   end
   if Equipment and Vocabulary.TelecomMobile[Equipment] then Use = 'mobile' end

   local Telecom = { system = System, value = Value }
   if Use then Telecom.use = Use end
   return Telecom
end

-- HL7 DTM/TS (YYYY[MM[DD[HHMM...]]]) -> a FHIR date. FHIR accepts a partial
-- date, so a year-only or year-month birth date maps rather than being dropped.
local function birthDateFrom(Time)
   if not Time then return nil end
   local Digits = Time:match('^(%d+)')
   if not Digits then return nil end
   if #Digits >= 8 then
      return Digits:sub(1, 4) .. '-' .. Digits:sub(5, 6) .. '-' .. Digits:sub(7, 8)
   elseif #Digits >= 6 then
      return Digits:sub(1, 4) .. '-' .. Digits:sub(5, 6)
   elseif #Digits >= 4 then
      return Digits:sub(1, 4)
   end
   return nil
end

-- The dom-6 narrative, so a validating server reports no warnings on an
-- otherwise-minimal Patient. XHTML is escaped: a patient name is data, and an
-- apostrophe or ampersand in one must not break the narrative.
local ESCAPE = { ['&'] = '&amp;', ['<'] = '&lt;', ['>'] = '&gt;', ['"'] = '&quot;' }
local function narrativeFor(Patient)
   local Parts = {}
   local Name = Patient.name and Patient.name[1]
   if Name then
      local Full = ((Name.given and table.concat(Name.given, ' ') or '')
         .. ' ' .. (Name.family or '')):match('^%s*(.-)%s*$')
      if Full ~= '' then Parts[#Parts + 1] = Full end
   end
   local Id = Patient.identifier and Patient.identifier[1]
   if Id then
      Parts[#Parts + 1] = (Id.type and Id.type.coding[1].display or 'ID') .. ' ' .. Id.value
   end
   local Text = table.concat(Parts, ', ')
   if Text == '' then Text = 'Patient' end
   return {
      status = 'generated',
      div = '<div xmlns="http://www.w3.org/1999/xhtml">'
         .. Text:gsub('[&<>"]', ESCAPE) .. '</div>',
   }
end

-- ---------------------------------------------------------------------------
-- The mapping
-- ---------------------------------------------------------------------------

-- Map one HL7 v2 ADT message to a FHIR R4 Patient table (ready to serialize).
--
-- Returns (Patient, nil, Warnings) on success, or (nil, errorMessage) when the
-- message cannot be parsed against the schema or carries no PID. Warnings is a
-- list of strings describing values that did not map - always a table, often
-- empty - for the caller to log.
function M.toPatient(Raw)
   checkSourceNames()

   -- extract raises on a message the grammar cannot parse (no MSH, say), which
   -- is a bad message rather than a bug here, so it is turned into an error
   -- return like any other mapping failure.
   local Ok, Msg, MessageType = pcall(linkiir.data.extract,
      { schema = M.Schema, data = Raw, type = 'hl7' })
   if not Ok then
      return nil, tostring(Msg)
   end
   if MessageType == '' then
      return nil, 'the message did not match any message in ' .. M.Schema
   end

   local PID = Msg:child(Source.Segment)
   if not PID then
      return nil, 'no ' .. Source.Segment .. ' segment found in the HL7 message'
   end

   local Warnings = {}
   local Patient = { resourceType = 'Patient', active = true }

   -- Identifiers: every repeat of PID-3, then the two identifiers HL7 gives a
   -- field of their own. Neither PID-18 nor PID-19 carries a CX-5, so their
   -- type comes from the field they arrived in.
   local Identifiers = {}
   for _, Cx in ipairs(repeatsOf(PID:child(Source.Field.IdentifierList))) do
      Identifiers[#Identifiers + 1] =
         identifierFrom(Warnings, Cx, nil, 'PID Patient Identifier List (CX-5)')
   end
   for _, Cx in ipairs(repeatsOf(PID:child(Source.Field.AccountNumber))) do
      Identifiers[#Identifiers + 1] =
         identifierFrom(Warnings, Cx, 'AN', 'PID ' .. Source.Field.AccountNumber)
   end
   -- PID-19 is a plain ST with no assigning authority, so it is read whole and
   -- given the namespace and type HL7 states by devoting a field to it.
   local Ssn = textOf(PID:child(Source.Field.SSN))
   if Ssn then
      Identifiers[#Identifiers + 1] = {
         value  = Ssn,
         system = M.SsnSystem,
         type   = identifierType(Warnings, 'SS', 'PID ' .. Source.Field.SSN),
      }
   end
   if #Identifiers > 0 then Patient.identifier = Identifiers end

   -- Names: every repeat of PID-5.
   local Names = {}
   for Index, Xpn in ipairs(repeatsOf(PID:child(Source.Field.Name))) do
      Names[#Names + 1] = nameFrom(Warnings, Xpn, Index == 1)
   end
   if #Names > 0 then Patient.name = Names end

   -- Administrative sex -> gender.
   Patient.gender = translate(Warnings, textOf(PID:child(Source.Field.Sex)),
      Source.Table.Sex, Vocabulary.Gender, 'PID Administrative Sex')

   -- Date of birth. PID-7 is a TS, whose first component holds the timestamp.
   Patient.birthDate = birthDateFrom(
      valueAt(PID, Source.Field.BirthDateTime, 1, Source.TS.Time)
         or textOf(PID:child(Source.Field.BirthDateTime)))

   -- Telecom: home numbers then business numbers, each field's repeats in order.
   local Telecom = {}
   for _, Entry in ipairs({
      { Field = Source.Field.HomePhone, Use = 'home' },
      { Field = Source.Field.WorkPhone, Use = 'work' },
   }) do
      for _, Xtn in ipairs(repeatsOf(PID:child(Entry.Field))) do
         Telecom[#Telecom + 1] =
            telecomFrom(Warnings, Xtn, Entry.Use, 'PID ' .. Entry.Field)
      end
   end
   if #Telecom > 0 then Patient.telecom = Telecom end

   -- Addresses: every repeat of PID-11.
   local Addresses = {}
   for _, Xad in ipairs(repeatsOf(PID:child(Source.Field.Address))) do
      Addresses[#Addresses + 1] = addressFrom(Warnings, Xad)
   end
   if #Addresses > 0 then Patient.address = Addresses end

   Patient.text = narrativeFor(Patient)

   return Patient, nil, Warnings
end

return M
