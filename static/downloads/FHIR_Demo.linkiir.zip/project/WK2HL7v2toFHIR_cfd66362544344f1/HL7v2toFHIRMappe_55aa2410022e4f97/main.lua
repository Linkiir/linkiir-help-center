-- ---------------------------------------------------------------------------
-- HL7v2 to FHIR Mapper - Transform Custom (WK2)
--
-- Receives an HL7 v2 ADT message, maps it to a FHIR R4 Patient, and forwards
-- the Patient as JSON to the FHIR Validator.
--
-- The mapping itself lives in the sibling module hl7v2_to_fhir_map.lua, driven
-- by the HL7 v2.5.1 ADT^A01 grammar in hl7v251_adt_a01.json, so it can be
-- reviewed and updated on its own. This file is only the node glue: receive,
-- call the mapper, log, forward.
-- ---------------------------------------------------------------------------

local Map = require 'hl7v2_to_fhir_map'

function main(Data)
   local Patient, Err, Warnings = Map.toPatient(Data)
   if not Patient then
      linkiir.log.error('HL7v2->FHIR: could not map the message: ' .. tostring(Err))
      return
   end

   -- Values the message carried but the mapping could not place: a code HL7
   -- does not define, or one with no FHIR equivalent. The Patient is still
   -- valid and still forwarded - these say what was left out of it.
   for _, Warning in ipairs(Warnings) do
      linkiir.log.warn('HL7v2->FHIR: ' .. Warning)
   end

   local Json = linkiir.json.serialize(Patient)

   local mrn = Patient.identifier and Patient.identifier[1] and Patient.identifier[1].value or '(none)'
   local city = Patient.address and Patient.address[1] and Patient.address[1].city or '(none)'
   linkiir.log.info('HL7v2->FHIR: mapped ADT to FHIR Patient (MRN ' .. mrn
      .. ', city ' .. city .. '), forwarding to the validator.')

   linkiir.flow.push{ data = Json }
end
