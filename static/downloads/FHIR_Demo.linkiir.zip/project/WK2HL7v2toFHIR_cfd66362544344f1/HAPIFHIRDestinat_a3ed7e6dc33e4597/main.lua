-- ---------------------------------------------------------------------------
-- HAPI FHIR Destination - Destination Custom (WK2)
--
-- Proves Linkiir can WRITE to a HAPI FHIR / Smile OmniVera server.
--
-- It receives the validated FHIR Patient from upstream, finds an existing
-- Patient on the FHIR server, applies the inbound address to that patient, and
-- PUTs it back - demonstrating a real FHIR update.
--
-- Connection and authentication are DERIVED FROM THE HAPI FHIR ADAPTER (source):
-- this node exposes the same config fields (FHIR Base URL, FHIR Version,
-- Authentication and its credential fields, Live Mode, Verify TLS) and reads
-- them with the same hapi_fhir library via HapiFhir.fromNodeConfig(). So the
-- same configuration style covers both reading from and writing to the server -
-- point it at the public HAPI test server with 'None', or at a production
-- Smile OmniVera endpoint with 'OAuth2 Backend Services', without touching this
-- script.
-- ---------------------------------------------------------------------------
local HapiFhir = require ('hapi'..package.config:sub(1,1)..'hapi_fhir')

function main(Data)
   -- The validated Patient we mapped from the HL7 message. We only need its
   -- address to demonstrate the update.
   local Incoming = linkiir.json.parse(Data)
   if type(Incoming) ~= 'table' then
      linkiir.log.error('HAPI FHIR Destination: incoming data was not a FHIR JSON object.')
      return
   end
   local NewAddress = Incoming.address

   -- Build the client from THIS node's config fields - the same fields and the
   -- same library the HAPI FHIR Adapter (source) uses. fromNodeConfig() reads
   -- FHIR Base URL, FHIR Version, Authentication and its credentials, plus
   -- Live Mode and Verify TLS.
   local Fhir, Config = HapiFhir.fromNodeConfig()
   local BaseUrl = Config['FHIR Base URL'] or '(unset)'

   -- Throttle: pause after handling each message so we never hammer the FHIR
   -- server. The public HAPI test server rate-limits and can lock out frequent
   -- writers, so the demo ships this at 60000ms (1 minute). Applied at the end
   -- of main() via sleepAfter().
   local SleepMs = tonumber(Config['Sleep (ms)']) or 60000
   local function sleepAfter()
      if SleepMs > 0 then linkiir.sys.sleep(SleepMs) end
   end

   -- Find an existing Patient to update. Take the first one the server returns.
   local Found, SearchErr = Fhir:searchAll{ resource = 'Patient', parameters = { _count = '1' }, max_pages = 1 }

   -- Live Mode off (the default) short-circuits before any real request: the
   -- search comes back marked simulated with no resources. Check this FIRST,
   -- before the empty-result check below, or an off run looks like a fetch
   -- failure. This is the default because the public HAPI server rate-limits,
   -- so writes are opt-in.
   if Found and Found.simulated then
      linkiir.log.info('HAPI FHIR Destination: Live Mode is off (default), no request was sent. '
         .. 'Turn Live Mode on to actually update a Patient.')
      sleepAfter()
      return
   end

   if not Found or not Found.resources or #Found.resources == 0 then
      linkiir.log.error('HAPI FHIR Destination: could not fetch an existing Patient to update'
         .. (SearchErr and (' [' .. tostring(SearchErr.code) .. '] ' .. tostring(SearchErr.message)) or '.'))
      sleepAfter()
      return
   end

   local Patient = Found.resources[1]
   local Id = Patient.id
   linkiir.log.info('HAPI FHIR Destination: fetched existing Patient/' .. tostring(Id)
      .. ' from ' .. BaseUrl .. ' to update.')

   -- Apply the inbound address to that patient. This is the value we change to
   -- demonstrate the write; everything else about the patient is left intact.
   if NewAddress then
      Patient.address = NewAddress
   end
   -- A narrative keeps a strict server from warning on the update.
   Patient.text = {
      status = 'generated',
      div = '<div xmlns="http://www.w3.org/1999/xhtml">Updated by Linkiir demo (WK2)</div>',
   }

   local Result, UpdErr = Fhir:update{ resource = 'Patient', id = Id, parameters = Patient }
   if not Result then
      linkiir.log.error('HAPI FHIR Destination: update of Patient/' .. tostring(Id) .. ' failed ['
         .. tostring(UpdErr and UpdErr.code) .. '] ' .. tostring(UpdErr and UpdErr.message))
      sleepAfter()
      return
   end

   local city = NewAddress and NewAddress[1] and NewAddress[1].city or '(unchanged)'
   linkiir.log.info('HAPI FHIR Destination: PUT Patient/' .. tostring(Id)
      .. ' succeeded - address city set to ' .. tostring(city)
      .. '. Linkiir wrote to ' .. BaseUrl .. '.')

   sleepAfter()
end
