-- ---------------------------------------------------------------------------
-- HAPI FHIR Destination - Destination Custom (WK2)
--
-- Proves Linkiir can WRITE to a HAPI FHIR / Smile OmniVera server.
--
-- It receives the validated FHIR Patient from upstream, finds an existing
-- Patient on the FHIR server, applies the inbound address to that patient, and
-- PUTs it back - demonstrating a real FHIR update.
--
-- Connection and authentication are DERIVED FROM THE HAPI FHIR ADAPTER (source):
-- this node exposes the same config fields (FHIR Base URL, FHIR Version,
-- Authentication and its credential fields, Live Mode, Verify TLS) and reads
-- them with the same hapi_fhir library via HapiFhir.fromNodeConfig(). So the
-- same configuration style covers both reading from and writing to the server -
-- point it at the public HAPI test server with 'None', or at a production
-- Smile OmniVera endpoint with 'OAuth2 Backend Services', without touching this
-- script.
-- ---------------------------------------------------------------------------
-- The hapi_fhir library modules live in the hapi/ subfolder. They are required
-- by their dotted module path (hapi.hapi_fhir); Lua expands the dot to the
-- platform's directory separator, so the same code works whether the OS uses
-- '/' or '\'. The runtime already puts the node dir on package.path, so no
-- package.path setup is needed.
local HapiFhir = require 'hapi.hapi_fhir'

function main(Data)
   -- The validated Patient we mapped from the HL7 message. We only need its
   -- address to demonstrate the update.
   local Incoming = linkiir.json.parse(Data)
   if type(Incoming) ~= 'table' then
      linkiir.log.error('HAPI FHIR Destination: incoming data was not a FHIR JSON object.')
      return
   end
   local NewAddress = Incoming.address

   -- Build the client from THIS node's config fields - the same fields and the
   -- same library the HAPI FHIR Adapter (source) uses. fromNodeConfig() reads
   -- FHIR Base URL, FHIR Version, Authentication and its credentials, plus
   -- Live Mode and Verify TLS.
   local Fhir, Config = HapiFhir.fromNodeConfig()
   local BaseUrl = Config['FHIR Base URL'] or '(unset)'

   -- Find an existing Patient to update. Take the first one the server returns.
   local Found, SearchErr = Fhir:searchAll{ resource = 'Patient', parameters = { _count = '1' }, max_pages = 1 }
   if not Found or not Found.resources or #Found.resources == 0 then
      linkiir.log.error('HAPI FHIR Destination: could not fetch an existing Patient to update'
         .. (SearchErr and (' [' .. tostring(SearchErr.code) .. '] ' .. tostring(SearchErr.message)) or '.'))
      return
   end

   -- With Live Mode off nothing was actually sent, so there is no patient to
   -- update - report and stop rather than pretending a write happened.
   if Found.simulated then
      linkiir.log.info('HAPI FHIR Destination: Live Mode is off, no request was sent.')
      return
   end

   local Patient = Found.resources[1]
   local Id = Patient.id
   linkiir.log.info('HAPI FHIR Destination: fetched existing Patient/' .. tostring(Id)
      .. ' from ' .. BaseUrl .. ' to update.')

   -- Apply the inbound address to that patient. This is the value we change to
   -- demonstrate the write; everything else about the patient is left intact.
   if NewAddress then
      Patient.address = NewAddress
   end
   -- A narrative keeps a strict server from warning on the update.
   Patient.text = {
      status = 'generated',
      div = '<div xmlns="http://www.w3.org/1999/xhtml">Updated by Linkiir demo (WK2)</div>',
   }

   local Result, UpdErr = Fhir:update{ resource = 'Patient', id = Id, parameters = Patient }
   if not Result then
      linkiir.log.error('HAPI FHIR Destination: update of Patient/' .. tostring(Id) .. ' failed ['
         .. tostring(UpdErr and UpdErr.code) .. '] ' .. tostring(UpdErr and UpdErr.message))
      return
   end

   local city = NewAddress and NewAddress[1] and NewAddress[1].city or '(unchanged)'
   linkiir.log.info('HAPI FHIR Destination: PUT Patient/' .. tostring(Id)
      .. ' succeeded - address city set to ' .. tostring(city)
      .. '. Linkiir wrote to ' .. BaseUrl .. '.')
end
