-- ---------------------------------------------------------------------------
-- fhir_validate.classify - one HTTP response -> one verdict
--
-- The fail-closed half of the library. Everything here answers a single
-- question: given what came back from $validate, do we have a conclusive
-- verdict on the resource, and if not, why not.
--
-- Nothing in here sends anything or knows a base URL. That belongs to
-- fhir_validate.client, which calls this with whatever linkiir.link.web
-- returned.
-- ---------------------------------------------------------------------------

local M = {}

-- FHIR issue codes that mean "the validator could not do the job", as opposed
-- to "the resource is wrong". A server reports these when the requested profile
-- is not installed or cannot be resolved. Matched on the code, not on English
-- diagnostic text, which varies by server and version.
local UNRESOLVABLE_CODES = {
   ['not-supported'] = true,
   ['not-found']     = true,
}

-- Classify a linkiir.link.web response into a verdict.
--   returns status ('valid'|'invalid'|'unknown'), outcome table or nil, reason
function M.classify(Response, WebErr)
   -- linkiir.link.web returns nil, err on transport failure. Report the reason
   -- (connection refused, DNS, TLS/certificate, timeout) rather than a bare
   -- "no response", so a server with no route to the FHIR endpoint is
   -- diagnosable from the log instead of looking like a mystery.
   if not Response then
      -- The error is a { code=, message= } table (linkiir I/O-style error), not
      -- a string, so read those fields; fall back gracefully if it is a plain
      -- string or absent.
      local Reason
      if type(WebErr) == 'table' then
         Reason = '[' .. tostring(WebErr.code) .. '] ' .. tostring(WebErr.message)
      elseif WebErr ~= nil then
         Reason = tostring(WebErr)
      else
         Reason = 'unknown transport error'
      end
      return 'unknown', nil, 'could not reach the validation server: ' .. Reason
   end
   -- live = false: nothing was sent, so there is no verdict. Not a pass.
   if Response.simulated then
      return 'unknown', nil, 'Live Mode is off, no validation request was sent'
   end
   -- A non-200 means the operation did not conclude. Never INVALID - we did not
   -- get a verdict on the resource, we failed to ask.
   if type(Response.code) ~= 'number' or Response.code ~= 200 then
      return 'unknown', nil,
         'validation did not complete (HTTP ' .. tostring(Response.code) .. ')'
   end

   local Ok, Outcome = pcall(linkiir.json.parse, Response.body)
   if not Ok or type(Outcome) ~= 'table'
      or Outcome.resourceType ~= 'OperationOutcome'
      or type(Outcome.issue) ~= 'table' or #Outcome.issue == 0 then
      return 'unknown', nil, 'the server did not return a usable OperationOutcome'
   end

   local FatalOrError = false
   for _, Issue in ipairs(Outcome.issue) do
      local Severity = tostring(Issue.severity or '')
      local Code = tostring(Issue.code or '')
      if Severity == 'fatal' or Severity == 'error' then
         -- A profile the server cannot resolve is a question it could not
         -- answer, not a resource that failed. Fail closed as UNKNOWN so a
         -- missing profile is never silently downgraded to base-R4 validation.
         if UNRESOLVABLE_CODES[Code] then
            return 'unknown', Outcome,
               'the server could not resolve the requested profile'
         end
         FatalOrError = true
      end
   end

   return FatalOrError and 'invalid' or 'valid', Outcome, nil
end

return M
