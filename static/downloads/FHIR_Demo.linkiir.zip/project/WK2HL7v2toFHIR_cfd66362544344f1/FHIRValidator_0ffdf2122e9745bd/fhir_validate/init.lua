-- ---------------------------------------------------------------------------
-- fhir_validate - remote FHIR $validate client
--
-- Validates a FHIR resource against a FHIR server's $validate operation and
-- returns a strict tri-state verdict. Nothing is validated locally: the server
-- is the authority, and a server that cannot answer yields 'unknown' rather
-- than a guess.
--
--    local Validate = require 'fhir_validate'
--    local V = Validate.new{ BaseUrl = 'https://hapi.fhir.org/baseR4' }
--
--    local Status, Outcome, Reason = V:check(FhirJsonString)
--    -- Status is 'valid' | 'invalid' | 'unknown'
--
-- Meant to be called from an adapter *before* it sends. An Epic, Cerner or HAPI
-- adapter can validate a resource it built and refuse to POST an invalid one:
--
--    if Validate.new{ BaseUrl = Base }:check(PatientJson) ~= 'valid' then
--       linkiir.log.error('refusing to send a resource that did not validate')
--       return
--    end
-- ---------------------------------------------------------------------------

local Client  = require ('fhir_validate'..package.config:sub(1,1)..'client')
local Summary = require ('fhir_validate'..package.config:sub(1,1)..'summary')
local Node    = require ('fhir_validate'..package.config:sub(1,1)..'node')

local M = {}

M.new            = Client.new
M.Client         = Client.Client
M.summarize      = Summary.summarize
M.fromNodeConfig = Node.fromNodeConfig
M.validate       = Node.validate

return M
