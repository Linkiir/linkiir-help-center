-- ---------------------------------------------------------------------------
-- fhir_validate.client - the $validate caller
--
-- Holds one server's settings (base URL, profile, auth, TLS, timeout) and
-- sends a resource to its $validate operation. The verdict itself is not
-- decided here - the response goes straight to fhir_validate.classify.
--
-- The submitted resource is never mutated: check() sends the bytes it was
-- given, so a caller that forwards on 'valid' forwards exactly what was
-- validated.
-- ---------------------------------------------------------------------------

local Classify = require ('fhir_validate'..package.config:sub(1,1)..'classify')

local M = {}

-- Internal default; not a node setting. A catalog validator does not expose a
-- timeout knob - 15s is enough for a synchronous $validate and short enough to
-- fail closed rather than hang a workflow.
local DEFAULT_TIMEOUT = 15

local Client = {}
Client.__index = Client

-- Validate one FHIR resource.
--
--   FhirJson - the resource as a JSON string, sent unchanged
--   Opts     - optional { profile=, live= } overriding the client defaults
--
-- Returns status, outcome, reason. Status is always one of 'valid', 'invalid'
-- or 'unknown'; outcome is the parsed OperationOutcome when there is one; reason
-- explains an 'unknown' or is nil.
function Client:check(FhirJson, Opts)
   Opts = Opts or {}

   if type(FhirJson) ~= 'string' or FhirJson == '' then
      return 'unknown', nil, 'no FHIR resource to validate'   -- fail closed
   end

   local Ok, Resource = pcall(linkiir.json.parse, FhirJson)
   if not Ok or type(Resource) ~= 'table'
      or type(Resource.resourceType) ~= 'string' or Resource.resourceType == '' then
      return 'unknown', nil, 'input is not a FHIR resource (no resourceType)'
   end
   local ResourceType = Resource.resourceType

   if self.allowed and not self.allowed[ResourceType] then
      return 'unknown', nil, 'resource type not allowed for validation: ' .. ResourceType
   end

   if self.base_url == '' then
      return 'unknown', nil, 'no FHIR Base URL is configured'
   end

   -- Type-level validate: POST <base>/<ResourceType>/$validate. This does not
   -- create the resource - it is the read-shaped validate operation.
   local Url = self.base_url .. ResourceType .. '/$validate'

   local Params
   local Profile = Opts.profile or self.profile
   if Profile and Profile ~= '' then
      Params = { profile = Profile }
   end

   local Live = Opts.live
   if Live == nil then Live = self.live end
   if Live == nil then Live = true end

   -- linkiir.link.web.post returns (Response) on success and (nil, err) on a
   -- transport failure - could not connect, DNS, TLS/certificate, or timeout.
   -- Capture the second value so the reason is surfaced instead of discarded:
   -- a bare nil Response otherwise becomes an opaque "no response" with no clue
   -- that, for example, the server has no outbound route to the FHIR endpoint.
   local Response, WebErr = linkiir.link.web.post{
      url       = Url,
      params    = Params,
      body      = FhirJson,     -- byte-for-byte; never re-serialised
      headers   = {
         ['Content-Type'] = 'application/fhir+json',
         ['Accept']       = 'application/fhir+json',
      },
      auth      = self.auth,
      timeout   = self.timeout,
      verifyTls = self.verify_tls,
      live      = Live,
   }

   return Classify.classify(Response, WebErr)
end

-- Build a client.
--
--   BaseUrl      - FHIR base URL, e.g. https://hapi.fhir.org/baseR4
--   Profile      - default profile canonical to validate against; empty
--                  validates against the resource's base definition
--   Auth         - linkiir.link.web auth table, e.g. { type='bearer', token= }
--   AllowedTypes - list of resource types this client will validate; others
--                  return 'unknown' rather than being sent
--   Timeout      - seconds, default 20
--   VerifyTls    - verify the server certificate, default true
--   Live         - perform real requests, default true
function M.new(T)
   T = T or {}
   local BaseUrl = T.BaseUrl or ''
   if BaseUrl ~= '' and BaseUrl:sub(-1) ~= '/' then BaseUrl = BaseUrl .. '/' end

   local Allowed
   if type(T.AllowedTypes) == 'table' and #T.AllowedTypes > 0 then
      Allowed = {}
      for _, Type in ipairs(T.AllowedTypes) do Allowed[Type] = true end
   end

   return setmetatable({
      base_url   = BaseUrl,
      profile    = T.Profile or '',
      auth       = T.Auth,
      allowed    = Allowed,
      timeout    = tonumber(T.Timeout) or DEFAULT_TIMEOUT,
      verify_tls = T.VerifyTls ~= false,
      live       = T.Live ~= false,
   }, Client)
end

M.Client = Client
return M
