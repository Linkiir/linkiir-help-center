-- ---------------------------------------------------------------------------
-- fhir_validate.node - the one-call entry points a node script uses
--
-- Everything a node actually calls, in the shape a node wants it: read the
-- config or take a base URL, get back a single pass/stop answer with a line
-- that is safe to put in a log or an error. The tri-state verdict itself is
-- still what decides - this only flattens it for the caller.
-- ---------------------------------------------------------------------------

local Client  = require ('fhir_validate'..package.config:sub(1,1)..'client')
local Summary = require ('fhir_validate'..package.config:sub(1,1)..'summary')

local M = {}

-- Build a client from the current node's own configuration fields.
--
-- The node exposes only two settings - FHIR Base URL and an optional Profile
-- Canonical. TLS verification is always on and the timeout is the internal
-- default; neither is a knob a catalog node should offer. The resource type is
-- taken from the resource itself (see Client:check), so there is no Resource
-- Type setting and no allow-list by default - the same node validates Patient,
-- Observation, Encounter, and so on.
function M.fromNodeConfig()
   local Config = linkiir.config.node()
   local Instance = Client.new{
      BaseUrl = Config['FHIR Server URL'] or Config['FHIR Base URL'],
      Profile = Config['FHIR Profile'] or Config['Profile Canonical'],
   }
   return Instance, Config
end

-- ---------------------------------------------------------------------------
-- Simple one-call entry for the FHIR Validator node.
--
--   Opts = { data = <FHIR JSON string>, baseUrl = <FHIR base URL>,
--            profile = <optional profile canonical> }
--
-- Returns a result table:
--   { valid = <boolean>, status = 'valid'|'invalid'|'unknown',
--     summary = <one-line issue summary, safe to log - no submitted PHI> }
--
-- valid is true ONLY on a conclusive pass (an OperationOutcome with no fatal
-- or error issues). Both 'invalid' and 'unknown' return valid=false, so the
-- caller stops on anything that is not a clean pass - a timeout, an HTTP
-- failure, a malformed response, or an unresolved profile all stop, never
-- forward. The summary is built from issue severity/code/details only and never
-- includes the submitted resource, so it is safe to surface in an error.
-- ---------------------------------------------------------------------------
function M.validate(Opts)
   Opts = Opts or {}
   local Instance = Client.new{ BaseUrl = Opts.baseUrl, Profile = Opts.profile }
   local Status, Outcome, Reason = Instance:check(Opts.data, { profile = Opts.profile })

   -- 'valid' and 'invalid' are both verdicts the server reached, so both carry
   -- an OperationOutcome worth summarizing. Only 'unknown' means we never got
   -- one, and then the reason for that is the most useful thing to report.
   local Summarized
   if Status == 'unknown' then
      Summarized = Reason or 'no validation verdict was obtained'
   else
      Summarized = Summary.summarize(Outcome)
   end

   return { valid = (Status == 'valid'), status = Status, summary = Summarized }
end

return M
