-- ---------------------------------------------------------------------------
-- fhir_validate.summary - an OperationOutcome as one readable line
--
-- Log/error formatting only. The one rule that matters here is that nothing it
-- returns ever contains the submitted resource, so whatever it produces is
-- safe to log or to put in an error message.
-- ---------------------------------------------------------------------------

local M = {}

-- The most output any one summary line will list, so a server that returns
-- dozens of issues does not produce an unreadable log line.
local MAX_SUMMARIZED = 5

-- Collapse an OperationOutcome's issues into one readable line, for logging a
-- verdict without dumping the whole resource. Never includes the submitted
-- resource, so it is safe to log.
--
-- Only the issues that matter to a verdict are listed: fatal, error, and
-- warning. FHIR servers (HAPI in particular) also emit 'information' issues
-- that are validator bookkeeping - line/column pointers, message ids, "Unknown
-- extension http://hl7.org/fhir/StructureDefinition/operationoutcome-issue-*" -
-- which are noise to an operator and never change whether a resource is valid.
-- Those are counted, not printed. A resource that passes with only that
-- bookkeeping therefore logs a clean "no blocking issues" rather than a wall of
-- "Unknown extension" lines.
function M.summarize(Outcome)
   if type(Outcome) ~= 'table' or type(Outcome.issue) ~= 'table' then
      return 'no issues reported'
   end

   local Notable, InfoCount = {}, 0
   for _, Issue in ipairs(Outcome.issue) do
      local Severity = tostring(Issue.severity or 'information')
      if Severity == 'fatal' or Severity == 'error' or Severity == 'warning' then
         local Text = (type(Issue.details) == 'table' and Issue.details.text)
            or Issue.diagnostics or Issue.code
         if Text then
            Notable[#Notable + 1] = Severity .. ': ' .. tostring(Text)
         end
      else
         InfoCount = InfoCount + 1
      end
   end

   if #Notable == 0 then
      if InfoCount > 0 then
         return 'no blocking issues (' .. InfoCount .. ' informational note'
            .. (InfoCount == 1 and '' or 's') .. ')'
      end
      return 'no issues'
   end

   local Shown = Notable
   local Suffix = ''
   if #Notable > MAX_SUMMARIZED then
      Shown = {}
      for i = 1, MAX_SUMMARIZED do Shown[i] = Notable[i] end
      Suffix = ' | (+' .. (#Notable - MAX_SUMMARIZED) .. ' more)'
   end
   return table.concat(Shown, ' | ') .. Suffix
end

return M
