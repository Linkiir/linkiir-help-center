-- Lists this node's data maps and the formats it converts between.
-- Change it in the Map view or by hand: the Map view rewrites this file and drops comments inside the table.
return {
  format = 'linkiir.datamap/5',
  source = { type = 'hl7v2', version = '2.5.1', schema = 'source.json' },
  destination = { type = 'fhir', version = 'R4', schema = 'destination.json' },
  maps = {
    {
      name = 'ADT_A01 → FHIR',
      file = 'mapping/maps/adt_a01_fhir.map.lua',
      messages = { 'ADT_A01' },
      when = { all = { { from = 'MSH-9', value = 'ADT', op = 'is' }, { from = 'EVN-1', value = 'A01', op = 'is' } } },
    },
  },
}
