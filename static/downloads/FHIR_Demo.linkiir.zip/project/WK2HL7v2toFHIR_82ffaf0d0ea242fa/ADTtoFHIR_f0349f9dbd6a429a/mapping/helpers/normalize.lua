-- Normalizing the values the data maps write, and writing dates in a
-- pattern of the map's own.
-- Do not edit by hand: Data Map updates replace this file.
-- checksum: 1c1ed475

local normalize = {}

local function warn(text)
  linkiir.log.warn('mapping: ' .. text)
end

-- --- Normalizing ---------------------------------------------------------------------

-- UTF-8 text a character at a time.
local CHAR = '[%z\1-\127\194-\244][\128-\191]*'

local function length(s)
  local n = 0
  for _ in s:gmatch(CHAR) do n = n + 1 end
  return n
end

-- The first `n` characters of `s`.
local function first(s, n)
  local out, i = {}, 0
  for ch in s:gmatch(CHAR) do
    i = i + 1
    if i > n then break end
    out[i] = ch
  end
  return table.concat(out)
end

-- Accented Latin letters (Latin-1 Supplement and Latin Extended-A) as the
-- plain ones: é e, ß ss, Ø O.
local PLAIN = {
  ['\195\128'] = 'A', ['\195\129'] = 'A', ['\195\130'] = 'A', ['\195\131'] = 'A', ['\195\132'] = 'A', ['\195\133'] = 'A',
  ['\195\134'] = 'AE', ['\195\135'] = 'C', ['\195\136'] = 'E', ['\195\137'] = 'E', ['\195\138'] = 'E', ['\195\139'] = 'E',
  ['\195\140'] = 'I', ['\195\141'] = 'I', ['\195\142'] = 'I', ['\195\143'] = 'I', ['\195\144'] = 'D', ['\195\145'] = 'N',
  ['\195\146'] = 'O', ['\195\147'] = 'O', ['\195\148'] = 'O', ['\195\149'] = 'O', ['\195\150'] = 'O', ['\195\152'] = 'O',
  ['\195\153'] = 'U', ['\195\154'] = 'U', ['\195\155'] = 'U', ['\195\156'] = 'U', ['\195\157'] = 'Y', ['\195\158'] = 'Th',
  ['\195\159'] = 'ss', ['\195\160'] = 'a', ['\195\161'] = 'a', ['\195\162'] = 'a', ['\195\163'] = 'a', ['\195\164'] = 'a',
  ['\195\165'] = 'a', ['\195\166'] = 'ae', ['\195\167'] = 'c', ['\195\168'] = 'e', ['\195\169'] = 'e', ['\195\170'] = 'e',
  ['\195\171'] = 'e', ['\195\172'] = 'i', ['\195\173'] = 'i', ['\195\174'] = 'i', ['\195\175'] = 'i', ['\195\176'] = 'd',
  ['\195\177'] = 'n', ['\195\178'] = 'o', ['\195\179'] = 'o', ['\195\180'] = 'o', ['\195\181'] = 'o', ['\195\182'] = 'o',
  ['\195\184'] = 'o', ['\195\185'] = 'u', ['\195\186'] = 'u', ['\195\187'] = 'u', ['\195\188'] = 'u', ['\195\189'] = 'y',
  ['\195\190'] = 'th', ['\195\191'] = 'y', ['\196\128'] = 'A', ['\196\129'] = 'a', ['\196\130'] = 'A', ['\196\131'] = 'a',
  ['\196\132'] = 'A', ['\196\133'] = 'a', ['\196\134'] = 'C', ['\196\135'] = 'c', ['\196\136'] = 'C', ['\196\137'] = 'c',
  ['\196\138'] = 'C', ['\196\139'] = 'c', ['\196\140'] = 'C', ['\196\141'] = 'c', ['\196\142'] = 'D', ['\196\143'] = 'd',
  ['\196\144'] = 'D', ['\196\145'] = 'd', ['\196\146'] = 'E', ['\196\147'] = 'e', ['\196\148'] = 'E', ['\196\149'] = 'e',
  ['\196\150'] = 'E', ['\196\151'] = 'e', ['\196\152'] = 'E', ['\196\153'] = 'e', ['\196\154'] = 'E', ['\196\155'] = 'e',
  ['\196\156'] = 'G', ['\196\157'] = 'g', ['\196\158'] = 'G', ['\196\159'] = 'g', ['\196\160'] = 'G', ['\196\161'] = 'g',
  ['\196\162'] = 'G', ['\196\163'] = 'g', ['\196\164'] = 'H', ['\196\165'] = 'h', ['\196\166'] = 'H', ['\196\167'] = 'h',
  ['\196\168'] = 'I', ['\196\169'] = 'i', ['\196\170'] = 'I', ['\196\171'] = 'i', ['\196\172'] = 'I', ['\196\173'] = 'i',
  ['\196\174'] = 'I', ['\196\175'] = 'i', ['\196\176'] = 'I', ['\196\177'] = 'i', ['\196\178'] = 'IJ', ['\196\179'] = 'ij',
  ['\196\180'] = 'J', ['\196\181'] = 'j', ['\196\182'] = 'K', ['\196\183'] = 'k', ['\196\184'] = 'k', ['\196\185'] = 'L',
  ['\196\186'] = 'l', ['\196\187'] = 'L', ['\196\188'] = 'l', ['\196\189'] = 'L', ['\196\190'] = 'l', ['\196\191'] = 'L',
  ['\197\128'] = 'l', ['\197\129'] = 'L', ['\197\130'] = 'l', ['\197\131'] = 'N', ['\197\132'] = 'n', ['\197\133'] = 'N',
  ['\197\134'] = 'n', ['\197\135'] = 'N', ['\197\136'] = 'n', ['\197\137'] = 'n', ['\197\138'] = 'N', ['\197\139'] = 'n',
  ['\197\140'] = 'O', ['\197\141'] = 'o', ['\197\142'] = 'O', ['\197\143'] = 'o', ['\197\144'] = 'O', ['\197\145'] = 'o',
  ['\197\146'] = 'OE', ['\197\147'] = 'oe', ['\197\148'] = 'R', ['\197\149'] = 'r', ['\197\150'] = 'R', ['\197\151'] = 'r',
  ['\197\152'] = 'R', ['\197\153'] = 'r', ['\197\154'] = 'S', ['\197\155'] = 's', ['\197\156'] = 'S', ['\197\157'] = 's',
  ['\197\158'] = 'S', ['\197\159'] = 's', ['\197\160'] = 'S', ['\197\161'] = 's', ['\197\162'] = 'T', ['\197\163'] = 't',
  ['\197\164'] = 'T', ['\197\165'] = 't', ['\197\166'] = 'T', ['\197\167'] = 't', ['\197\168'] = 'U', ['\197\169'] = 'u',
  ['\197\170'] = 'U', ['\197\171'] = 'u', ['\197\172'] = 'U', ['\197\173'] = 'u', ['\197\174'] = 'U', ['\197\175'] = 'u',
  ['\197\176'] = 'U', ['\197\177'] = 'u', ['\197\178'] = 'U', ['\197\179'] = 'u', ['\197\180'] = 'W', ['\197\181'] = 'w',
  ['\197\182'] = 'Y', ['\197\183'] = 'y', ['\197\184'] = 'Y', ['\197\185'] = 'Z', ['\197\186'] = 'z', ['\197\187'] = 'Z',
  ['\197\188'] = 'z', ['\197\189'] = 'Z', ['\197\190'] = 'z', ['\197\191'] = 's',
}

-- Each word with its first letter up and the rest down; a letter on its own
-- before an apostrophe starts the word after it too: O'Brien, D'Angelo.
local function title(s)
  s = s:gsub("(%a)([%w']*)", function(a, rest) return a:upper() .. rest:lower() end)
  return (s:gsub("(%f[%w]%a)'(%l)", function(a, b) return a .. "'" .. b:upper() end))
end

-- The steps, in the order they run whatever order a rule lists them in. `n`
-- is a step's number (Cut to length, Pad with zeros: 'maxlen:20').
local STEPS = {
  { 'noctrl', function(s)
    s = s:gsub('[\t\r\n]+', ' '):gsub('\194\160', ' ')              -- line breaks, tabs, no-break spaces: a space
    return (s:gsub('%c', ''):gsub('\226\128[\139-\141]', ''):gsub('\239\187\191', ''))  -- zero-width ones go
  end },
  { 'noaccents', function(s) return (s:gsub('[\195-\197][\128-\191]', PLAIN)) end },
  { 'nopunct', function(s) return (s:gsub('%p', '')) end },
  { 'digits', function(s) return (s:gsub('%D', '')) end },
  { 'letters', function(s) return (s:gsub('[^%a%s\128-\255]', '')) end },
  { 'nospace', function(s) return (s:gsub('%s', '')) end },
  { 'collapse', function(s) return (s:gsub('%s+', ' ')) end },
  { 'trim', function(s) return (s:gsub('^%s+', ''):gsub('%s+$', '')) end },
  { 'nozeros', function(s) return (s:gsub('^0+(.)', '%1')) end },
  { 'pad', function(s, n)
    if type(n) ~= 'number' then return s end   -- no length: nothing to pad to
    local short = n - length(s)
    return short > 0 and s ~= '' and string.rep('0', short) .. s or s
  end },
  { 'lower', function(s) return s:lower() end },
  { 'upper', function(s) return s:upper() end },
  { 'title', title },
  { 'maxlen', function(s, n) return type(n) == 'number' and first(s, n) or s end },
}

local function text(s, on)
  for _, step in ipairs(STEPS) do
    local n = on[step[1]]
    if n then s = step[2](s, n) end
  end
  if type(on.custom) == 'function' then
    -- The rule's own step (a function in custom.lua), after the others.
    s = on.custom(s)
    s = s == nil and '' or tostring(s)
  end
  return s
end

-- What names a code system, a URL or an ID's root rather than holding data:
-- left as it is.
local KEEP = {
  system = true, url = true, reference = true, profile = true,
  ['@root'] = true, ['@codeSystem'] = true, ['@codeSystemName'] = true, ['@codeSystemVersion'] = true,
  ['@xsi:type'] = true, ['@nullFlavor'] = true, ['@classCode'] = true, ['@moodCode'] = true,
  ['@typeCode'] = true, ['@use'] = true, ['@unit'] = true, ['@mediaType'] = true, ['@representation'] = true,
}

local HL7, X12 = 101, 102   -- node:protocol() of an HL7 v2 or X12 message

local function normalized(v, on, cda)
  if type(v) == 'string' then
    v = text(v, on)
    if v == '' then return nil end
    return v
  end
  if type(v) == 'userdata' and v.protocol and (v:protocol() == HL7 or v:protocol() == X12) then
    -- A part of the message: its text, or a list of its parts' texts (a
    -- component's only subcomponent: its text).
    if v:count() == 1 and v:child(1):count() == 0 then return normalized(v:child(1), on) end
    if v:count() == 0 then
      local s = v:value()
      if v:protocol() == HL7 then s = (s == '""') and '' or linkiir.data.unescape(s, v) end
      return normalized(s, on)
    end
    local list = {}
    for i = 1, v:count() do list[i] = normalized(v:child(i), on) or '' end
    return list
  end
  if type(v) ~= 'table' then return v end
  local out = {}
  for k, x in pairs(v) do
    if type(k) == 'string' then
      out[k] = KEEP[k] and x or normalized(x, on, cda)
    elseif type(k) == 'number' and cda and type(x) == 'table' then
      out[k] = { x[1], normalized(x[2], on, cda) }   -- a CDA structure's child element: { name, value }
    elseif type(k) == 'number' then
      out[k] = normalized(x, on, cda) or ''
    else
      out[k] = x   -- what a helper keeps beside the value (fhir.obj's field order)
    end
  end
  return setmetatable(out, getmetatable(v))
end

-- `v` normalized by `steps` ({ 'trim', 'upper', 'maxlen:20' }, and a
-- function - the rule's own step, given each text and returning it
-- normalized): its text, or the text in a list, a FHIR value or a CDA
-- structure (`cda`) - code systems, URLs and roots left as they are. nil for
-- text that normalizes to nothing.
function normalize.value(v, steps, cda)
  if v == nil then return nil end
  local on = {}
  for _, s in ipairs(steps or {}) do
    if type(s) == 'function' then
      on.custom = s
    else
      local name, n = tostring(s):match('^(%a+):?(%d*)$')
      if name then on[name] = tonumber(n) or true end
    end
  end
  return normalized(v, on, cda)
end

-- --- Date formats ----------------------------------------------------------------------

local MONTHS = { 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October',
                 'November', 'December' }

-- A zone as +HH:MM, or Z.
local function zone_of(z)
  if z == nil or z == '' then return nil end
  if z == 'Z' then return 'Z' end
  local sign, h, m = z:match('^([+-])(%d%d):?(%d%d)$')
  return sign and (sign .. h .. ':' .. m) or nil
end

-- The parts of a date, date and time, or time (`time`): HL7, X12 and CDA's
-- digits (20240115103000-0500) or ISO's (2024-01-15T10:30:00Z), with what
-- it doesn't have nil.
local function parts_of(s, time)
  local t = {}
  if time then
    local h, mi, sec, frac, z = s:match('^(%d%d):?(%d%d):?(%d?%d?)(%.?%d*)(.-)$')
    if not h then return nil end
    t.h, t.mi, t.s, t.frac, t.zone = h, mi, sec, frac, z
  else
    local y, mo, d, rest = s:match('^(%d%d%d%d)%-(%d%d)%-?(%d?%d?)(.*)$')
    if y then
      local h, mi, sec, frac, z = rest:match('^[T ](%d%d):(%d%d):?(%d?%d?)(%.?%d*)(.-)$')
      if not h and rest ~= '' then return nil end
      t.y, t.mo, t.d, t.h, t.mi, t.s, t.frac, t.zone = y, mo, d, h, mi, sec, frac, z
    else
      local body, z = s:match('^([%d%.]+)(.-)$')
      if not body then return nil end
      y, mo, d = body:match('^(%d%d%d%d)(%d?%d?)(%d?%d?)')
      if not y then return nil end
      local h, mi, sec, frac = body:match('^%d%d%d%d%d%d%d%d(%d?%d?)(%d?%d?)(%d?%d?)(%.?%d*)$')
      if not h and #body > 8 then return nil end
      t.y, t.mo, t.d, t.h, t.mi, t.s, t.frac, t.zone = y, mo, d, h, mi, sec, frac, z
    end
  end
  for _, k in ipairs({ 'y', 'mo', 'd', 'h', 'mi', 's', 'frac' }) do
    if t[k] == '' or t[k] == '.' then t[k] = nil end
  end
  if t.zone ~= nil and t.zone ~= '' then
    t.zone = zone_of(t.zone)
    if not t.zone then return nil end
  else
    t.zone = nil
  end
  return t
end

local function hour12(h)
  local n = tonumber(h) % 12
  return n == 0 and 12 or n
end

-- What each part of a pattern writes, and the part of the date it needs.
local TOKENS = {
  { 'YYYY', 'y', function(t) return t.y end },
  { 'MMMM', 'mo', function(t) return MONTHS[tonumber(t.mo)] end },
  { 'MMM', 'mo', function(t) return MONTHS[tonumber(t.mo)]:sub(1, 3) end },
  { 'SSS', 's', function(t) return ((t.frac or ''):sub(2) .. '000'):sub(1, 3) end },
  { 'YY', 'y', function(t) return t.y:sub(3, 4) end },
  { 'MM', 'mo', function(t) return t.mo end },
  { 'DD', 'd', function(t) return t.d end },
  { 'HH', 'h', function(t) return t.h end },
  { 'hh', 'h', function(t) return string.format('%02d', hour12(t.h)) end },
  { 'mm', 'mi', function(t) return t.mi end },
  { 'ss', 's', function(t) return t.s end },
  { 'ZZ', nil, function(t) return t.zone and (t.zone == 'Z' and '+0000' or (t.zone:gsub(':', ''))) or '' end },
  { 'M', 'mo', function(t) return tostring(tonumber(t.mo)) end },
  { 'D', 'd', function(t) return tostring(tonumber(t.d)) end },
  { 'H', 'h', function(t) return tostring(tonumber(t.h)) end },
  { 'h', 'h', function(t) return tostring(hour12(t.h)) end },
  { 'A', 'h', function(t) return tonumber(t.h) < 12 and 'AM' or 'PM' end },
  { 'a', 'h', function(t) return tonumber(t.h) < 12 and 'am' or 'pm' end },
  { 'Z', nil, function(t) return t.zone or '' end },
}

-- The date, date and time, or time (`time`) `v` written in `pattern`:
-- 'MM/DD/YYYY', 'YYYY-MM-DD HH:mm', text in [brackets] as it is. nil, with a
-- warning, for a value that isn't one or lacks a part the pattern writes.
function normalize.date(v, pattern, time)
  if v == nil or v == '' or pattern == nil or pattern == '' then return v end
  local s = tostring(v)
  local t = parts_of(s, time)
  if not t then return warn('not a date to write as ' .. pattern .. ': ' .. s) end
  local out, i = {}, 1
  while i <= #pattern do
    local literal = pattern:match('^%[([^%]]*)%]', i)
    if literal then
      out[#out + 1] = literal
      i = i + #literal + 2
    else
      local hit
      for _, tok in ipairs(TOKENS) do
        if pattern:sub(i, i + #tok[1] - 1) == tok[1] then
          hit = tok
          break
        end
      end
      if hit then
        if hit[2] and not t[hit[2]] then
          return warn(s .. ' has no ' .. ({ y = 'year', mo = 'month', d = 'day', h = 'hour', mi = 'minutes',
                                            s = 'seconds' })[hit[2]] .. ' to write as ' .. pattern)
        end
        out[#out + 1] = hit[3](t)
        i = i + #hit[1]
      else
        out[#out + 1] = pattern:sub(i, i)
        i = i + 1
      end
    end
  end
  return table.concat(out)
end

return normalize
