-- Functions the data maps use to build FHIR output.
-- Do not edit by hand: Data Map updates replace this file.
-- checksum: 21c5d6ee

local fhir = {}

local ORDER = {} -- where fhir.obj keeps the order its fields were given in

-- Nothing to write: nil, '', or a table holding nothing but empty values.
local function is_empty(v)
  if v == nil or v == '' then return true end
  if type(v) ~= 'table' then return false end
  for k, child in pairs(v) do
    if k ~= ORDER and not is_empty(child) then return false end
  end
  return true
end

-- A FHIR object whose fields are written in the order given; fields with no
-- value are left out, and nil comes back when none has one.
function fhir.obj(...)
  local o, order = {}, {}
  for i = 1, select('#', ...), 2 do
    local k, v = select(i, ...)
    if not is_empty(v) then
      o[k] = v
      order[#order + 1] = k
    end
  end
  if #order == 0 then return nil end
  o[ORDER] = order
  return o
end

local function text(v)
  if type(v) == 'boolean' then return v and 'true' or 'false' end
  if type(v) == 'number' and v == math.floor(v) and v > -1e15 and v < 1e15 then
    return string.format('%d', v)
  end
  return tostring(v)
end

local function keys_of(t)
  if t[ORDER] then return t[ORDER] end
  local keys = {}
  for k in pairs(t) do
    if type(k) == 'string' then keys[#keys + 1] = k end
  end
  table.sort(keys)
  return keys
end

-- Values go in as text so destination.json decides their JSON type: "true" for a
-- boolean element is written true, "2" for an integer 2.
local function write(node, name, value, append)
  if type(value) == 'table' and not value[ORDER] and value[1] ~= nil then
    for _, item in ipairs(value) do
      if not is_empty(item) then write(node, name, item, true) end
    end
    return
  end
  local child = (not append and node:el(name)) or node:add(name)
  if type(value) == 'table' then
    for _, k in ipairs(keys_of(value)) do
      if not is_empty(value[k]) then write(child, k, value[k], false) end
    end
  else
    child:set(text(value))
  end
end

-- 'name[].given[]' -> { { name = 'name', array = true }, { name = 'given', array = true } }
local function steps_of(path)
  local steps = {}
  for name, brackets in path:gmatch('([%w_]+)(%[?%]?)') do
    steps[#steps + 1] = { name = name, array = brackets == '[]' }
  end
  return steps
end

-- Writes `value` at `path` under `node`, creating what the path needs on the
-- way. Each `name[]` step is a list: the last one is appended to, the first
-- one above it takes item `r` (the source repetition), deeper ones item 1.
-- Returns whether anything was written - an empty value writes nothing.
function fhir.put(node, path, value, r)
  if is_empty(value) then return false end
  local steps = steps_of(path)
  local indexed = false
  for i = 1, #steps - 1 do
    local st = steps[i]
    if st.array then
      local idx = indexed and 1 or (r or 1)
      indexed = true
      local items = node:all(st.name)
      for i = #items + 1, idx do items[i] = node:add(st.name) end
      node = items[idx]
    else
      node = node:el(st.name) or node:add(st.name)
    end
  end
  local last = steps[#steps]
  write(node, last.name, value, last.array)
  return true
end

-- A new item of the list at `path` under `node` ('contact[]'), made with what
-- the path needs on the way (the last item of a list above it): a list the
-- map makes per item fills one, with fhir.put(itemOut, 'name', ...).
function fhir.item(node, path)
  local steps = steps_of(path)
  for i = 1, #steps - 1 do
    local st = steps[i]
    local items = st.array and node:all(st.name) or nil
    node = (items and items[#items]) or (not st.array and node:el(st.name)) or node:add(st.name)
  end
  return node:add(steps[#steps].name)
end

-- A random RFC 4122 (version 4) UUID.
function fhir.uuid()
  local hex = linkiir.sys.guid(128):sub(1, 32):lower()
  local variant = string.format('%x', 8 + tonumber(hex:sub(17, 17), 16) % 4)
  return hex:sub(1, 8) .. '-' .. hex:sub(9, 12) .. '-4' .. hex:sub(14, 16) .. '-'
    .. variant .. hex:sub(18, 20) .. '-' .. hex:sub(21, 32)
end

-- Adds a Bundle entry for a new resource. Returns { resource = <node>,
-- url = <its fullUrl>, segment = <the segment it is made from, if any> }.
function fhir.entry(bundle, resourceType, kind, segment)
  local entry = bundle:add('entry')
  local url = 'urn:uuid:' .. fhir.uuid()
  entry.fullUrl = url
  local resource = entry:add('resource')
  resource.resourceType = resourceType
  if kind == 'transaction' or kind == 'batch' then
    local request = entry:add('request')
    request.method = 'POST'
    request.url = resourceType
  end
  return { resource = resource, url = url, segment = segment }
end

-- --- Resources made inside others ---------------------------------------------
-- A map can make a resource per item inside another's (`under`): a
-- DiagnosticReport per OBR, an Observation per OBX of that OBR. Each entry
-- then knows the one it was made under, so references pair them: the
-- report refers to its own Observations, each Observation to its own report.

-- Puts entry `e` (fhir.entry's) in the map's tree as `name`, under entry
-- `parent` (nil at the top); `all` holds every entry by name. Returns `e`.
function fhir.nest(e, name, parent, all)
  e.name, e.parent, e.kids, e.all = name, parent, {}, all
  if parent then parent.kids[#parent.kids + 1] = e end
  all[name] = all[name] or {}
  table.insert(all[name], e)
  return e
end

-- The fullUrls of `e`'s entries made as `name`, at any depth, in order.
local function made_under(e, name, out)
  for _, kid in ipairs(e.kids or {}) do
    if kid.name == name then out[#out + 1] = kid.url end
    made_under(kid, name, out)
  end
  return out
end

-- The fullUrls entry `e` refers to as `name`: the one it was made under;
-- else those made under it; else those made under the nearest entry around
-- it that has some (a sibling's); else the first made anywhere.
function fhir.refs(e, name)
  local up = e.parent
  while up do
    if up.name == name then return { up.url } end
    up = up.parent
  end
  local list = made_under(e, name, {})
  up = e.parent
  while #list == 0 and up do
    list = made_under(up, name, {})
    up = up.parent
  end
  if #list == 0 and e.all and e.all[name] and e.all[name][1] then list = { e.all[name][1].url } end
  return list
end

-- Writes at `path` of `node` a reference to each entry `e` refers to as
-- `name` (fhir.refs) - into a list (result[]) all of them, else the first -
-- unless the map's rules have written there. Says whether it wrote any.
function fhir.refer(node, path, e, name)
  if node:el(path:match('^([%w_]+)')) then return false end
  local urls = fhir.refs(e, name)
  local list = path:sub(-2) == '[]'
  for _, url in ipairs(urls) do
    fhir.put(node, path, fhir.obj('reference', url))
    if not list then break end
  end
  return #urls > 0
end

-- Rejects the message when a required rule wrote nothing (a 'Message
-- rejected:' error, which On Error can skip).
function fhir.required(wrote, from, to)
  if not wrote then error('Message rejected: ' .. from .. ' gave no value for ' .. to .. ', which requires one', 0) end
end

-- How long each unit of a shift is ('-1d', '+2h', '+30min'); months and
-- years (mo, y) move the calendar instead, as their length varies.
local SHIFT_UNITS = { s = 1, min = 60, h = 3600, d = 86400, w = 604800 }

-- The time now, moved by `shift`: '-1d', '+2h', '+30min', '+1mo', '-1y'.
local function shifted(shift)
  local t = os.time()
  if shift == nil or shift == '' then return t end
  local sign, n, unit = tostring(shift):gsub('%s', ''):lower():match('^([+-]?)(%d+)(%a+)$')
  n = tonumber(n)
  if n and sign == '-' then n = -n end
  if n and (unit == 'mo' or unit == 'y') then
    local d = os.date('*t', t)
    if unit == 'y' then d.year = d.year + n else d.month = d.month + n end
    return os.time(d)
  end
  if not (n and SHIFT_UNITS[unit]) then
    error("can't shift the time by '" .. tostring(shift) .. "' - write it as -1d, +2h, +30min, +1mo or -1y", 0)
  end
  return t + n * SHIFT_UNITS[unit]
end

-- The local zone's offset from UTC at time t: +HHMM, or +HH:MM with sep ':'.
local function zone(t, sep)
  local here, utc = os.date('*t', t), os.date('!*t', t)
  utc.isdst = here.isdst
  local offset = os.difftime(os.time(here), os.time(utc))
  local sign = offset < 0 and '-' or '+'
  offset = math.abs(offset)
  return string.format('%s%02d%s%02d', sign, math.floor(offset / 3600), sep or '', math.floor(offset % 3600 / 60))
end

local NOW = { date = '%Y-%m-%d', time = '%H:%M:%S' }

-- The time the message is mapped, moved by options.shift: a dateTime with
-- its zone (2024-01-15T10:30:00-05:00), or as options.format says, a date or
-- a time.
function fhir.now(options)
  options = options or {}
  local t = shifted(options.shift)
  if NOW[options.format] then return os.date(NOW[options.format], t) end
  return os.date('%Y-%m-%dT%H:%M:%S', t) .. zone(t, ':')
end

-- A new random RFC 4122 (version 4) UUID.
function fhir.uuid()
  local hex = linkiir.sys.guid(128):sub(1, 32):lower()
  local variant = string.format('%x', 8 + tonumber(hex:sub(17, 17), 16) % 4)
  return hex:sub(1, 8) .. '-' .. hex:sub(9, 12) .. '-4' .. hex:sub(14, 16) .. '-'
    .. variant .. hex:sub(18, 20) .. '-' .. hex:sub(21, 32)
end

-- --- Narrative -------------------------------------------------------------------
-- A resource's text sums up what the map wrote into it, so a reader that
-- doesn't know the resource's structure can still show it to a person.

-- Left out unless named: what identifies and manages the resource rather
-- than describing it.
local NOT_SHOWN = {
  resourceType = true, id = true, meta = true, implicitRules = true, language = true, text = true,
  contained = true, extension = true, modifierExtension = true,
}

local function escaped(s)
  return (s:gsub('&', '&amp;'):gsub('<', '&lt;'):gsub('>', '&gt;'))
end

-- The types a choice element is named with ('deceasedBoolean' is
-- deceased[x]) that no other element's name ends in: 'Date' or 'Period'
-- would cut birthDate or billablePeriod.
local CHOICE_TYPES = {
  Boolean = true, Integer = true, Decimal = true, String = true, DateTime = true, Quantity = true,
  CodeableConcept = true,
}

-- 'birthDate' -> 'Birth date', 'deceasedBoolean' -> 'Deceased'
local function label(name)
  for t in pairs(CHOICE_TYPES) do
    if #name > #t and name:sub(-#t) == t and name:sub(-#t - 1, -#t - 1):match('%l') then
      name = name:sub(1, -#t - 1)
      break
    end
  end
  local words = name:gsub('(%l)(%u)', function(a, b) return a .. ' ' .. b:lower() end)
  return words:sub(1, 1):upper() .. words:sub(2)
end

-- The names of `node`'s elements, in order.
local function names(node)
  local out, seen = {}, {}
  for i = 1, #node do
    local name = node:child(i):name()
    if not seen[name] then
      seen[name] = true
      out[#out + 1] = name
    end
  end
  return out
end

-- The values given, the empty ones left out.
local function present(...)
  local out = {}
  for i = 1, select('#', ...) do
    local v = select(i, ...)
    if v and v ~= '' then out[#out + 1] = v end
  end
  return out
end

local function joined(list, sep)
  if #list == 0 then return nil end
  return table.concat(list, sep)
end

local summary

-- Each item of `node`'s `name` (one, when it doesn't repeat) in words.
local function values(node, name)
  local out = {}
  for _, item in ipairs(node:all(name)) do
    local s = summary(item)
    if s and s ~= '' then out[#out + 1] = s end
  end
  return out
end

local function one(node, name)
  return values(node, name)[1]
end

-- An element's value in words, read by the shape of its data type - a
-- name, an address, a coded concept, an identifier... - else its parts in
-- turn.
summary = function(node)
  if #node == 0 then
    local v = node:value()
    return v ~= '' and v or nil
  end
  local function has(name) return node:el(name) ~= nil end
  if has('text') then return one(node, 'text') end -- HumanName, Address, CodeableConcept, Annotation
  if has('family') or has('given') then -- HumanName
    local parts = {}
    for _, name in ipairs({ 'prefix', 'given', 'family', 'suffix' }) do
      for _, v in ipairs(values(node, name)) do parts[#parts + 1] = v end
    end
    return joined(parts, ' ')
  end
  if has('line') or has('city') or has('postalCode') then -- Address
    local parts = values(node, 'line')
    local place = joined(present(one(node, 'city'), joined(present(one(node, 'state'), one(node, 'postalCode')), ' ')), ', ')
    for _, v in ipairs(present(place, one(node, 'country'))) do parts[#parts + 1] = v end
    return joined(parts, ', ')
  end
  if has('coding') then return one(node, 'coding') end -- CodeableConcept
  if has('url') then -- Extension: its value, or its extensions'; Attachment: its title
    for _, name in ipairs(names(node)) do
      if name:match('^value%u') then return one(node, name) end
    end
    return joined(values(node, 'extension'), ', ') or one(node, 'title') or one(node, 'url')
  end
  if has('reference') or has('display') then -- Reference, Coding
    local ref = one(node, 'reference')
    -- An entry's urn:uuid says nothing to a reader.
    return one(node, 'display') or (ref and not ref:match('^urn:uuid:') and ref) or one(node, 'code')
  end
  if has('start') or has('end') then -- Period
    return joined(present(one(node, 'start'), one(node, 'end')), ' to ')
  end
  if has('unit') or has('comparator') then -- Quantity
    return joined(present((one(node, 'comparator') or '') .. (one(node, 'value') or ''), one(node, 'unit')), ' ')
  end
  if has('value') then -- Identifier, ContactPoint
    local v = one(node, 'value')
    local kind = one(node, 'type') or one(node, 'use')
    return v and kind and (v .. ' (' .. kind .. ')') or v
  end
  if has('code') then return one(node, 'code') end -- Coding without a display
  local parts = {}
  for _, name in ipairs(names(node)) do
    for _, v in ipairs(values(node, name)) do parts[#parts + 1] = v end
  end
  return joined(parts, ', ')
end

-- `resource`'s text: each of `elements` (its names, in order; nil for every
-- element the resource has, but those NOT_SHOWN) on a line of its own, in
-- the XHTML div FHIR asks for. The status says the text is generated from
-- the resource's elements - 'extensions' when it shows an extension. nil
-- when none of them has a value.
function fhir.narrative(resource, elements)
  local lines, extensions = {}, false
  for _, name in ipairs(elements or names(resource)) do
    if elements or not NOT_SHOWN[name] then
      local shown = values(resource, name)
      if #shown > 0 then
        for i, v in ipairs(shown) do shown[i] = escaped(v) end
        lines[#lines + 1] = '<p><b>' .. escaped(label(name)) .. '</b>: ' .. table.concat(shown, '; ') .. '</p>'
        extensions = extensions or name == 'extension' or name == 'modifierExtension'
      end
    end
  end
  if #lines == 0 then return nil end
  return fhir.obj('status', extensions and 'extensions' or 'generated',
    'div', '<div xmlns="http://www.w3.org/1999/xhtml">' .. table.concat(lines) .. '</div>')
end

return fhir
