-- Sends each message to the data map that handles it.
-- Do not edit by hand: the graphical map rewrites this file.
-- Your own code goes in premap.lua, postmap.lua and custom.lua.
-- generated-from: mapping/datamap.lua
-- checksum: d77e9211
local hl7 = require 'mapping.helpers.hl7v2'
local adtA01Fhir = require 'mapping.maps.adt_a01_fhir'
require 'custom' -- the functions the maps call
require 'premap' -- PreMap
require 'postmap' -- PostMap

local mapper = {}

-- A message the node can't take fails as 'Message rejected: ...': one that
-- can't be read, that no data map takes, or that lacks a value a map
-- requires. Under On Error = Skip the message, main.lua skips these; any
-- other error, such as one in your own code, stops the node.
local function reject(text)
  error('Message rejected: ' .. text, 0)
end

-- A message that can't be read is rejected - unless the schema itself can't
-- be loaded, which is the node's problem, not the message's.
local function unreadable(err)
  err = tostring(err)
  if err:find("schema '", 1, true) or err:find(' schema;', 1, true) then error(err, 0) end
  reject(err)
end

-- A message read as source.json describes it, and its type.
function mapper.read(data)
  local ok, msgIn, msgType = pcall(linkiir.data.extract, { schema = 'source.json', data = data })
  if not ok then unreadable(msgIn) end
  return msgIn, msgType
end

-- ADT_A01 → FHIR takes the ADT_A01 that meets all of these:
local function adtA01FhirWhen(msgIn, msgType)
  -- MSH-9 is ADT
  do
    local met = hl7.text(hl7.get(msgIn.MSH, '9')) == 'ADT'
    if not met then return false end
  end
  -- EVN-1 is A01
  do
    local met = hl7.text(hl7.get(msgIn.EVN, '1')) == 'A01'
    if not met then return false end
  end
  return true
end

-- The maps for each message in source.json, in the order they are tried:
-- a message goes to the first whose condition it meets (a map without
-- one takes any).
local maps = {
  ADT_A01 = { { map = adtA01Fhir, when = adtA01FhirWhen } },
}

-- The map msgIn goes to: the first of those for its type whose condition it
-- meets.
local function pick(msgIn, msgType)
  for _, choice in ipairs(maps[msgType] or {}) do
    if not choice.when or choice.when(msgIn, msgType) then return choice.map end
  end
end

-- Whether a data map handles msgType - given msgIn, whether one takes it.
function mapper.takes(msgType, msgIn)
  if msgIn == nil then return maps[msgType] ~= nil end
  return pick(msgIn, msgType) ~= nil
end

-- One message in, whatever its map builds out (nil when it builds nothing),
-- between the user's PreMap and PostMap.
function mapper.map(msgIn, msgType)
  if msgType == 'unknown' then
    reject(hl7.messageType(msgIn) .. ' matches none of the messages in the source schema')
  end
  if not maps[msgType] then
    reject(msgType .. ' is in the source schema, but no data map takes it')
  end
  local map = pick(msgIn, msgType)
  if not map then
    reject(msgType .. ' meets the condition of none of the data maps that take it')
  end
  msgIn = PreMap(msgIn, msgType) or msgIn
  local msgOut = map.map(msgIn, msgType)
  return PostMap(msgOut, msgIn, msgType) or msgOut
end

return mapper
