-- The rules for one data map.
-- Change it in the Map view or by hand: the Map view rewrites this file and drops comments inside the table.
return {
  bundle = 'none',
  resources = {},
  rules = {},
}
