-- The code for the ADT_A01 → FHIR data map.
-- Do not edit by hand: the graphical map rewrites this file.
-- generated-from: mapping/maps/adt_a01_fhir.map.lua
-- part-of: mapping/datamap.lua
-- checksum: 295ba355
local mapper = {}

-- One message in, one FHIR resource out (the first in the map); nil when
-- the map has nothing for this message.
function mapper.map(msgIn, msgType)
  return nil
end

return mapper
