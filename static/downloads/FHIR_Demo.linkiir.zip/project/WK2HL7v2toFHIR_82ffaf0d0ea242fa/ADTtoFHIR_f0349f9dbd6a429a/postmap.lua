-- Your own code after mapping: mapping/init.lua calls PostMap on what the data
-- map built. The Map view never changes this file. To share something with
-- PreMap, keep it in custom.lua.

-- MsgOut is what the map built (nil when it built nothing), from MsgIn, of type
-- MsgType. Change MsgOut here, or return another message to send in its place.
function PostMap(MsgOut, MsgIn, MsgType)
end
