-- Converts each message this node receives, using the node's data maps.
local mapper = require 'mapping'

-- The message to send for Data: what the maps build from it, or nil to send nothing.
local function convert(Data, config)
    -- Read the incoming message as source.json describes it (HL7 v2, FHIR, X12, CDA,
    -- database rows - a JSON object of rows by table - or a plain JSON or XML document).
    local MsgIn, MsgType = mapper.read(Data)

    -- A message no data map handles follows the Unknown Messages setting.
    -- (A FHIR Bundle is matched by the event its MessageHeader names too.)
    if not mapper.takes(MsgType, MsgIn) then
        local unknown = config['Unknown Messages']
        if unknown == 'Skip the message' then
            linkiir.log.info('Skipped ' .. MsgType .. ': no map takes it')
            return nil
        elseif unknown == 'Pass it through unchanged' then
            return Data
        end
    end

    -- Build the output message. It can be adjusted here before it is sent.
    local MsgOut = mapper.map(MsgIn, MsgType)
    return MsgOut and MsgOut:S()
end

-- Whether err is about the message rather than the node: one it can't read,
-- that no map takes, or that lacks a value a map requires.
local function rejected(err)
    return type(err) == 'string' and err:sub(1, 18) == 'Message rejected: '
end

function main(Data)
    local config = linkiir.config.node()
    local ok, result = pcall(convert, Data, config)
    if not ok then
        -- A rejected message follows the On Error setting. Any other error - in
        -- your own code, say - stops the node, so it can't drop every message.
        if config['On Error'] == 'Skip the message' and rejected(result) then
            linkiir.log.error('Skipped a message: ' .. result)
            return
        end
        error(result, 0)
    end
    -- Sent outside the pcall: a message that can't be sent always stops the node.
    if result then
        linkiir.flow.push{ data = result }
    end
end
