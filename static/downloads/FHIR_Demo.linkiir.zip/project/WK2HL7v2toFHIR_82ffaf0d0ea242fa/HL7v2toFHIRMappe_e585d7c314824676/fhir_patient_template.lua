-- Blank FHIR R4 Patient template.
--
-- This is the JSON the FHIR Profiler Designer generates for an R4 Patient,
-- pasted in as-is. The mapper turns it into a Lua table with
-- linkiir.json.parse, fills in the fields it has, and prunes the rest.
--
--     local fhir = linkiir.json.parse(require 'fhir_patient_template')

local jsonStr = [==[
{
  "resourceType": "Patient",
  "active": null,
  "identifier": [
    {
      "use": null,
      "system": null,
      "value": null,
      "type": {
        "text": null,
        "coding": [
          {
            "system": null,
            "code": null,
            "display": null,
            "version": null,
            "userSelected": null
          }
        ]
      }
    }
  ],
  "name": [
    {
      "use": null,
      "text": null,
      "family": null,
      "given": [
        null
      ],
      "prefix": [
        null
      ],
      "suffix": [
        null
      ]
    }
  ],
  "gender": null,
  "birthDate": null,
  "telecom": [
    {
      "system": null,
      "value": null,
      "use": null,
      "rank": null
    }
  ],
  "address": [
    {
      "use": null,
      "type": null,
      "line": [
        null
      ],
      "city": null,
      "state": null,
      "postalCode": null,
      "country": null
    }
  ],
  "text": {
    "status": null,
    "div": null
  }
}
]==]

return jsonStr
