-- HL7v2 to FHIR Mapper: maps an HL7 v2 ADT message to a FHIR R4 Patient
-- and forwards it as JSON to the FHIR Validator.

local Map = require 'hl7v2_to_fhir_map'

function main(Data)
   local Patient = Map.toPatient(Data)
   linkiir.flow.push{ data = linkiir.json.serialize(Patient) }
end
