-- HL7 v2 ADT  ->  FHIR R4 Patient (demo mapper)
--
--   1. Parse the HL7 message
--   2. Parse the blank FHIR Patient template (JSON from the FHIR Profiler)
--   3. Copy values from the PID segment into the template

local GENDER = { F = 'female', M = 'male', O = 'other', U = 'unknown' }

-- Remove template fields that were never filled (still null or empty).
local NULL = linkiir.json.null
local function prune(V)
   if V == NULL or V == '' then return nil end
   if type(V) ~= 'table' then return V end
   local Out, IsArray = {}, V[1] ~= nil
   for K, Item in pairs(V) do
      local Kept = prune(Item)
      if Kept ~= nil then
         if IsArray then Out[#Out + 1] = Kept else Out[K] = Kept end
      end
   end
   if next(Out) == nil then return nil end
   return Out
end

local function mapPatientDemographics(fhir, Msg)
   -- PID-3: medical record number
   fhir.identifier[1].value  = Msg.PID[3][1][1]:value()
   fhir.identifier[1].system = 'http://hospital.example.org/' .. Msg.PID[3][1][4][1]:value():lower()
   fhir.identifier[1].type.coding[1].system  = 'http://terminology.hl7.org/CodeSystem/v2-0203'
   fhir.identifier[1].type.coding[1].code    = 'MR'
   fhir.identifier[1].type.coding[1].display = 'Medical record number'

   -- PID-5: patient name
   fhir.name[1].use      = 'official'
   fhir.name[1].family   = Msg.PID[5][1][1][1]:value()
   fhir.name[1].given[1] = Msg.PID[5][1][2]:value()
   if Msg.PID[5][1][3] then
      fhir.name[1].given[2] = Msg.PID[5][1][3]:value()
   end

   -- PID-7: date of birth (YYYYMMDD -> YYYY-MM-DD)
   if Msg.PID[7] then
      local Dob = Msg.PID[7][1][1]:value()
      if #Dob >= 8 then
         fhir.birthDate = Dob:sub(1, 4) .. '-' .. Dob:sub(5, 6) .. '-' .. Dob:sub(7, 8)
      end
   end

   -- PID-8: gender
   if Msg.PID[8] then
      fhir.gender = GENDER[Msg.PID[8]:value()]
   end

   -- PID-11: address
   if Msg.PID[11] then
      fhir.address[1].use        = 'home'
      fhir.address[1].type       = 'both'
      fhir.address[1].line[1]    = Msg.PID[11][1][1][1]:value()
      fhir.address[1].city       = Msg.PID[11][1][3]:value()
      fhir.address[1].state      = Msg.PID[11][1][4]:value()
      fhir.address[1].postalCode = Msg.PID[11][1][5]:value()
      fhir.address[1].country    = Msg.PID[11][1][6]:value()
   end

   -- PID-13: home phone
   if Msg.PID[13] then
      fhir.telecom[1].system = 'phone'
      fhir.telecom[1].use    = 'home'
      fhir.telecom[1].value  = Msg.PID[13][1][1]:value()
   end

   -- Human-readable summary
   fhir.text.status = 'generated'
   fhir.text.div = '<div xmlns="http://www.w3.org/1999/xhtml">'
      .. table.concat(fhir.name[1].given, ' ') .. ' ' .. fhir.name[1].family .. '</div>'
end

local M = {}

function M.toPatient(Raw)
   local Msg  = linkiir.data.extract{ schema = 'hl7v251_adt_a01.json', data = Raw, type = 'hl7' }
   local fhir = linkiir.json.parse(require 'fhir_patient_template')
   mapPatientDemographics(fhir, Msg)
   return prune(fhir)
end

return M
