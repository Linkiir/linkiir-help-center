-- The code for the ADT_A01 → FHIR data map.
-- Do not edit by hand: the graphical map rewrites this file.
-- generated-from: mapping/maps/adt_a01_fhir.map.lua
-- part-of: mapping/datamap.lua
-- checksum: d0fb54ef
local hl7 = require 'mapping.helpers.hl7v2'
local convert = require 'mapping.helpers.convert'
local fhir = require 'mapping.helpers.fhir'

local mapper = {}

function mapper.mapPatient(msgIn, patient)
  local PID = hl7.first_segment(msgIn, 'PID') or {}
  for _, rep in hl7.each(PID[3]) do
    fhir.put(patient, 'identifier[]', convert.identifier(rep))
  end

  for _, rep in hl7.each(PID[5]) do
    fhir.put(patient, 'name[]', convert.human_name(rep))
  end

  for _, rep in hl7.each(PID[13]) do
    fhir.put(patient, 'telecom[]', convert.telecom(rep))
  end

  for _, rep in hl7.each(PID[14]) do
    fhir.put(patient, 'telecom[]', convert.telecom(rep))
  end

  fhir.put(patient, 'gender', convert.gender(hl7.first(PID[8])))
  fhir.put(patient, 'birthDate', convert.date(hl7.first(PID[7])))
  fhir.put(patient, 'deceasedBoolean', convert.boolean(hl7.first(PID[30])))
  fhir.put(patient, 'deceasedDateTime', convert.datetime(hl7.first(PID[29])))

  for _, rep in hl7.each(PID[11]) do
    fhir.put(patient, 'address[]', convert.address(rep))
  end

  fhir.put(patient, 'maritalStatus', convert.codeable_concept(hl7.first(PID[16])))
  fhir.put(patient, 'multipleBirthBoolean', convert.boolean(hl7.first(PID[24])))
  fhir.put(patient, 'multipleBirthInteger', convert.number(hl7.first(PID[25])))

  for r, rep in hl7.each(PID[15]) do
    fhir.put(patient, 'communication[].language', convert.codeable_concept(rep), r)
  end

  fhir.put(patient, 'text', fhir.narrative(patient))
end

-- One message in, one FHIR resource out (the first in the map); nil when
-- the map has nothing for this message.
function mapper.map(msgIn, msgType)
  local msgOut = linkiir.data.create{ schema = 'destination.json', name = 'Patient', type = 'fhir' }
  mapper.mapPatient(msgIn, msgOut)
  return msgOut
end

return mapper
