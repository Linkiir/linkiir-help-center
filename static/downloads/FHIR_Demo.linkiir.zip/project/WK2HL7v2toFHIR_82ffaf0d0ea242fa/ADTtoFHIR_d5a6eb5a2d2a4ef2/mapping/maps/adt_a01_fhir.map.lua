-- The rules for one data map.
-- Change it in the Map view or by hand: the Map view rewrites this file and drops comments inside the table.
return {
  bundle = 'none',
  resources = {
    { name = 'Patient', type = 'Patient' },
  },
  rules = {
    { from = 'PID-3', to = 'Patient.identifier[]', fn = 'identifier' },
    { from = 'PID-5', to = 'Patient.name[]', fn = 'human_name' },
    { from = 'PID-7', to = 'Patient.birthDate', fn = 'date' },
    { from = 'PID-8', to = 'Patient.gender', fn = 'gender' },
    { from = 'PID-11', to = 'Patient.address[]', fn = 'address' },
    { from = 'PID-13', to = 'Patient.telecom[]', fn = 'telecom' },
    { from = 'PID-14', to = 'Patient.telecom[]', fn = 'telecom' },
    { from = 'PID-15', to = 'Patient.communication[].language', fn = 'codeable_concept' },
    { from = 'PID-16', to = 'Patient.maritalStatus', fn = 'codeable_concept' },
    { from = 'PID-24', to = 'Patient.multipleBirthBoolean', fn = 'boolean' },
    { from = 'PID-25', to = 'Patient.multipleBirthInteger', fn = 'number' },
    { from = 'PID-29', to = 'Patient.deceasedDateTime', fn = 'datetime' },
    { from = 'PID-30', to = 'Patient.deceasedBoolean', fn = 'boolean' },
    { to = 'Patient.text', fn = 'narrative' },
  },
}
