-- HAPI FHIR Destination: send a validated FHIR Patient to the FHIR server.
-- The Patient was already validated upstream, so this node just POSTs it.

local HapiFhir = require ('hapi'..package.config:sub(1,1)..'hapi_fhir')

function main(Data)
   local Patient = linkiir.json.parse(Data)
   if type(Patient) ~= 'table' or Patient.resourceType ~= 'Patient' then
      linkiir.log.error('HAPI FHIR Destination: expected a FHIR Patient JSON object.')
      return
   end

   local Fhir, Config = HapiFhir.fromNodeConfig()

   local Result, Err = Fhir:create{ resource = 'Patient', parameters = Patient }
   if not Result then
      linkiir.log.error('HAPI FHIR Destination: POST failed ['
         .. tostring(Err and Err.code) .. '] ' .. tostring(Err and Err.message))
      return
   end

   -- Live Mode off (default): the library prepares the request but sends nothing.
   if Result.simulated then
      linkiir.log.info('HAPI FHIR Destination: Live Mode is off, nothing sent. '
         .. 'Turn Live Mode on to POST to ' .. tostring(Config['FHIR Base URL']) .. '.')
      return
   end

   linkiir.log.info('HAPI FHIR Destination: POSTed Patient to '
      .. tostring(Config['FHIR Base URL']) .. '.')
end
