-- HAPI FHIR Source: on each interval, search the FHIR server for the configured
-- resource and push every match downstream as JSON.

local HapiFhir = require ('hapi'..package.config:sub(1,1)..'hapi_fhir')

-- "family=Smith&_count=20" -> { family = 'Smith', _count = '20' }
local function parseSearchQuery(Query)
   local Params = {}
   for Pair in tostring(Query or ''):gmatch('[^&]+') do
      local Key, Value = Pair:match('^%s*([^=]+)=(.*)$')
      if Key then Params[Key:gsub('%s+$', '')] = Value end
   end
   return Params
end

function main()
   local Fhir, Config = HapiFhir.fromNodeConfig()
   local Resource = Config['Resource Type']
   if Resource == nil or Resource == '' then Resource = 'Patient' end

   -- Max Pages 0 means "no limit".
   local MaxPages = tonumber(Config['Max Pages']) or 1
   if MaxPages <= 0 then MaxPages = 10000 end

   local Result, Err = Fhir:searchAll{
      resource   = Resource,
      parameters = parseSearchQuery(Config['Search Query']),
      max_pages  = MaxPages,
   }
   if not Result then
      linkiir.log.error(string.format('HAPI FHIR Source: %s search failed [%s] %s',
         Resource, tostring(Err.code), tostring(Err.message)))
      return
   end
   if Result.simulated then
      linkiir.log.info('HAPI FHIR Source: Live Mode is off, no request was sent.')
      return
   end

   for _, FhirResource in ipairs(Result.resources) do
      linkiir.flow.push{
         data = linkiir.json.serialize(FhirResource),
         metadata = {
            fhir_resource_type = FhirResource.resourceType or Resource,
            fhir_id            = FhirResource.id,
            fhir_version       = Fhir.version,
         },
      }
   end

   linkiir.log.info(string.format('HAPI FHIR Source: pushed %d %s resource(s).',
      #Result.resources, Resource))
end
