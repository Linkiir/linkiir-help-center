-- FHIR R4 Patient  ->  HL7 v2 ADT^A08 (demo mapper)
--
--   1. Read the fields off the FHIR Patient
--   2. Build an empty HL7 ADT with linkiir.data.create
--   3. Write each field into its HL7 position
--   4. Serialize to HL7 wire text

local SCHEMA = 'hl7v251_adt_a01.json'

local SEX = { male = 'M', female = 'F', other = 'O', unknown = 'U' }

-- Value as a string, or '' when absent.
local function s(Value)
   return Value == nil and '' or tostring(Value)
end

-- Join HL7 components with '^', e.g. cmp('SMITH', 'JAMES') -> 'SMITH^JAMES'.
local function cmp(...)
   return table.concat({ ... }, '^')
end

local function mapToHL7(Patient)
   local name    = (Patient.name       or {})[1] or {}
   local given   = (name.given         or {})[1]
   local address = (Patient.address    or {})[1] or {}
   local line    = (address.line       or {})[1]
   local phone   = (Patient.telecom    or {})[1] or {}
   local id      = (Patient.identifier or {})[1] or {}

   local stamp = os.date('%Y%m%d%H%M%S')
   local ctrl  = stamp .. string.format('%05d', math.random(0, 99999))

   local Out = linkiir.data.create{ schema = SCHEMA, name = 'ADT_A01', type = 'hl7' }

   -- MSH: message header
   Out.MSH[3][1]  = 'LINKIIR'
   Out.MSH[4][1]  = 'LINKIIR GRID'
   Out.MSH[5][1]  = 'RECEIVER'
   Out.MSH[6][1]  = 'FACILITY'
   Out.MSH[7][1]  = stamp
   Out.MSH[9]     = 'ADT^A08^ADT_A01'
   Out.MSH[10]    = ctrl
   Out.MSH[11][1] = 'P'
   Out.MSH[12][1] = '2.5.1'

   -- EVN: event type
   Out.EVN[1]    = 'A08'
   Out.EVN[2][1] = stamp

   -- PID: identity and demographics. Each field is written whole, its
   -- components joined with '^' by cmp(). (Per-component writes like
   -- Out.PID[5][1][2] need a newer runtime; this form works everywhere.)
   Out.PID[1]     = '1'
   Out.PID[3][1]  = cmp(s(id.value), '', '', 'LINKIIR', 'MR')                 -- PID-3 MRN
   Out.PID[5][1]  = cmp(s(name.family), s(given))                            -- PID-5 name
   Out.PID[7][1]  = s(Patient.birthDate):gsub('%-', '')                      -- PID-7 DOB
   Out.PID[8]     = SEX[s(Patient.gender)] or 'U'                            -- PID-8 sex
   Out.PID[11][1] = cmp(s(line), '', s(address.city), s(address.state),       -- PID-11 address
                        s(address.postalCode), 'USA')
   Out.PID[13][1] = s(phone.value)                                          -- PID-13 phone

   return linkiir.data.serialize{ data = Out }
end

local M = {}

function M.toADT(Patient)
   return mapToHL7(Patient)
end

return M
