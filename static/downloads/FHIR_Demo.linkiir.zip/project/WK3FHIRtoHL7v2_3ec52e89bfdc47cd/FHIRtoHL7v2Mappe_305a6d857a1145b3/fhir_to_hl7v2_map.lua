-- FHIR R4 Patient  ->  HL7 v2 ADT^A08 (demo mapper)
--
--   1. Read the fields off the FHIR Patient
--   2. Build an empty HL7 ADT with linkiir.data.create
--   3. Write each value into its HL7 position
--   4. Serialize to HL7 wire text
--
-- Positions follow the schema: a field that doesn't repeat holds its
-- components directly (MSH[9][2] is the trigger event), and a field that
-- repeats is addressed by repetition, then component (PID[5][1][2] is the
-- first name's given name).

local SCHEMA = 'hl7v251_adt_a01.json'

local SEX = { male = 'M', female = 'F', other = 'O', unknown = 'U' }

-- Value as a string, or '' when absent.
local function s(Value)
   return Value == nil and '' or tostring(Value)
end

local function mapToHL7(Patient)
   local name    = (Patient.name       or {})[1] or {}
   local given   = (name.given         or {})[1]
   local address = (Patient.address    or {})[1] or {}
   local line    = (address.line       or {})[1]
   local phone   = (Patient.telecom    or {})[1] or {}
   local id      = (Patient.identifier or {})[1] or {}

   local stamp = os.date('%Y%m%d%H%M%S')
   local ctrl  = stamp .. string.format('%05d', math.random(0, 99999))

   local Out = linkiir.data.create{ schema = SCHEMA, name = 'ADT_A01', type = 'hl7' }

   -- MSH: message header
   Out.MSH[3][1]  = 'LINKIIR'                 -- MSH-3.1 sending application
   Out.MSH[4][1]  = 'LINKIIR GRID'            -- MSH-4.1 sending facility
   Out.MSH[5][1]  = 'RECEIVER'                -- MSH-5.1 receiving application
   Out.MSH[6][1]  = 'FACILITY'                -- MSH-6.1 receiving facility
   Out.MSH[7][1]  = stamp                     -- MSH-7.1 date/time of message
   Out.MSH[9][1]  = 'ADT'                     -- MSH-9 message type
   Out.MSH[9][2]  = 'A08'
   Out.MSH[9][3]  = 'ADT_A01'
   Out.MSH[10]    = ctrl                      -- MSH-10 control ID
   Out.MSH[11][1] = 'P'                       -- MSH-11.1 processing ID
   Out.MSH[12][1] = '2.5.1'                   -- MSH-12.1 version

   -- EVN: event type
   Out.EVN[1]    = 'A08'
   Out.EVN[2][1] = stamp                      -- EVN-2.1 recorded date/time

   -- PID: identity and demographics
   Out.PID[1]        = '1'
   Out.PID[3][1][1]  = s(id.value)            -- PID-3 MRN
   Out.PID[3][1][4]  = 'LINKIIR'              --   assigning authority
   Out.PID[3][1][5]  = 'MR'                   --   identifier type
   Out.PID[5][1][1]  = s(name.family)         -- PID-5 name
   Out.PID[5][1][2]  = s(given)
   Out.PID[7][1]     = (s(Patient.birthDate):gsub('%-', ''))   -- PID-7.1 DOB
   Out.PID[8]        = SEX[s(Patient.gender)] or 'U'           -- PID-8 sex
   Out.PID[11][1][1] = s(line)                -- PID-11 address
   Out.PID[11][1][3] = s(address.city)
   Out.PID[11][1][4] = s(address.state)
   Out.PID[11][1][5] = s(address.postalCode)
   Out.PID[11][1][6] = 'USA'
   Out.PID[13][1][1] = s(phone.value)         -- PID-13 phone

   return linkiir.data.serialize{ data = Out }
end

local M = {}

function M.toADT(Patient)
   return mapToHL7(Patient)
end

return M
