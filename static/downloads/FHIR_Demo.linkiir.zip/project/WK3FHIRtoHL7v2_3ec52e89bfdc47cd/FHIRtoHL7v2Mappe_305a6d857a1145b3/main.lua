-- FHIR to HL7v2 Mapper: parses a FHIR R4 Patient (JSON), maps it to an HL7 v2
-- ADT^A08 message, and forwards the HL7 text to the print destination.

local Map = require 'fhir_to_hl7v2_map'

function main(Data)
   local Patient = linkiir.json.parse(Data)
   if type(Patient) ~= 'table' or Patient.resourceType ~= 'Patient' then
      linkiir.log.warn('FHIR->HL7v2: skipping a resource that is not a Patient.')
      return
   end

   linkiir.flow.push{ data = Map.toADT(Patient) }
end
