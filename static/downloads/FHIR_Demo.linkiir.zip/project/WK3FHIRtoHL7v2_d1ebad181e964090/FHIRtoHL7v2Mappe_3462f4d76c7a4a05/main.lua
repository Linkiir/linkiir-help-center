-- ---------------------------------------------------------------------------
-- FHIR to HL7v2 Mapper - Transform Custom (WK3)
--
-- Receives a FHIR R4 Patient (as JSON, from the HAPI FHIR source), maps it to
-- an HL7 v2 ADT^A08 message, and forwards the HL7 text to the print
-- destination.
--
-- The mapping itself lives in the sibling module fhir_to_hl7v2_map.lua, so it
-- can be reviewed and updated on its own. This file is only the node glue.
-- ---------------------------------------------------------------------------
local Map = require 'fhir_to_hl7v2_map'

function main(Data)
   local Patient = linkiir.json.parse(Data)
   if type(Patient) ~= 'table' or Patient.resourceType ~= 'Patient' then
      linkiir.log.warn('FHIR->HL7v2: skipping a resource that is not a Patient.')
      return
   end

   local Hl7 = Map.toADT(Patient)

   local id = Patient.id or '(no id)'
   linkiir.log.info('FHIR->HL7v2: mapped Patient/' .. tostring(id)
      .. ' to an HL7 v2 ADT^A08, forwarding to the printer.')

   linkiir.flow.push{ data = Hl7 }
end
